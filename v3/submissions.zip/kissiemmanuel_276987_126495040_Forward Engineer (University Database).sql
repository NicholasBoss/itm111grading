-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema university
-- -----------------------------------------------------
DROP SCHEMA IF EXISTS `university` ;

-- -----------------------------------------------------
-- Schema university
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `university` DEFAULT CHARACTER SET utf8 ;
USE `university` ;

-- -----------------------------------------------------
-- Table `university`.`department`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`department` ;

CREATE TABLE IF NOT EXISTS `university`.`department` (
  `department_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `department_name` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`department_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`degree`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`degree` ;

CREATE TABLE IF NOT EXISTS `university`.`degree` (
  `degree_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `department_name` VARCHAR(45) NOT NULL,
  `department_id` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`degree_id`),
  INDEX `fk_degree_department1_idx` (`department_id` ASC) VISIBLE,
  CONSTRAINT `fk_degree_department1`
    FOREIGN KEY (`department_id`)
    REFERENCES `university`.`department` (`department_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`course`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`course` ;

CREATE TABLE IF NOT EXISTS `university`.`course` (
  `course_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `course_code` INT NOT NULL,
  `course_title` VARCHAR(45) NOT NULL,
  `credit` INT NOT NULL,
  `course_number` VARCHAR(10) NOT NULL,
  `degree_id` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`course_id`),
  INDEX `fk_courses_degree1_idx` (`degree_id` ASC) VISIBLE,
  CONSTRAINT `fk_courses_degree1`
    FOREIGN KEY (`degree_id`)
    REFERENCES `university`.`degree` (`degree_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`semester`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`semester` ;

CREATE TABLE IF NOT EXISTS `university`.`semester` (
  `semester_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `year` YEAR NOT NULL,
  `term` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`semester_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`section`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`section` ;

CREATE TABLE IF NOT EXISTS `university`.`section` (
  `section_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `section_number` INT NOT NULL,
  `capacity` INT NOT NULL,
  `course_id` INT UNSIGNED NOT NULL,
  `semester_id` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`section_id`),
  INDEX `fk_section_course1_idx` (`course_id` ASC) VISIBLE,
  INDEX `fk_section_semester1_idx` (`semester_id` ASC) VISIBLE,
  CONSTRAINT `fk_section_course1`
    FOREIGN KEY (`course_id`)
    REFERENCES `university`.`course` (`course_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_section_semester1`
    FOREIGN KEY (`semester_id`)
    REFERENCES `university`.`semester` (`semester_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`person`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`person` ;

CREATE TABLE IF NOT EXISTS `university`.`person` (
  `person_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `first_name` VARCHAR(45) NOT NULL,
  `last_name` VARCHAR(45) NOT NULL,
  `gender` CHAR(1) NULL,
  `city` VARCHAR(45) NULL,
  `state` VARCHAR(45) NULL,
  `birth_date` DATE NULL,
  PRIMARY KEY (`person_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`role`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`role` ;

CREATE TABLE IF NOT EXISTS `university`.`role` (
  `role_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `person_type` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`role_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`enrollment`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`enrollment` ;

CREATE TABLE IF NOT EXISTS `university`.`enrollment` (
  `enrollment_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `person_id` INT UNSIGNED NOT NULL,
  `section_id` INT UNSIGNED NOT NULL,
  `role_id` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`enrollment_id`),
  INDEX `fk_enrollment_person1_idx` (`person_id` ASC) VISIBLE,
  INDEX `fk_enrollment_section1_idx` (`section_id` ASC) VISIBLE,
  INDEX `fk_enrollment_role1_idx` (`role_id` ASC) VISIBLE,
  CONSTRAINT `fk_enrollment_person1`
    FOREIGN KEY (`person_id`)
    REFERENCES `university`.`person` (`person_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_enrollment_section1`
    FOREIGN KEY (`section_id`)
    REFERENCES `university`.`section` (`section_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_enrollment_role1`
    FOREIGN KEY (`role_id`)
    REFERENCES `university`.`role` (`role_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;


USE university;

-- Table 1
-- Inserting Department Name

INSERT INTO department (department_name) 
VALUES
('Computer Science and Engineering'),
('Mathematics'),
('Music');

-- Table 2
-- Inserting Degrees

INSERT INTO degree (department_name, department_id) 
VALUES
('Computer Science', 1),
('Web Design and Development', 1),
('Data Science', 2),
('Organ Performance', 3);

-- Table 3
-- Inserting Courses

INSERT INTO course (course_code, course_title, credit, course_number, degree_id) 
VALUES
(251, 'Parallelism and Concurrency', 3, 'CSE 251', 1),
(231, 'Web Frontend Development I', 2, 'WDD 231', 2),
(113, 'Calculus II', 3, 'MATH 113', 3),
(213, 'Musicianship 4', 3, 'MUSIC 213', 4);

-- Table 4
-- Inserting Semesters

INSERT INTO semester (year, term)
 VALUES
(2024, 'Fall'),
(2025, 'Winter');

-- Table 5
-- Inserting Sections

INSERT INTO section (section_number, capacity, course_id, semester_id) 
VALUES
(1, 35, 1, 1),
(1, 30, 2, 1), 
(2, 30, 2, 1), 
(1, 45, 3, 1), 
(1, 25, 4, 1), 
(2, 35, 1, 2), 
(3, 35, 1, 2), 
(1, 30, 2, 2), 
(2, 40, 2, 2), 
(1, 25, 4, 2); 


-- Table 6
-- Inserting Persons

INSERT INTO person (first_name, last_name, gender, city, state, birth_date)
VALUES
('Marshall', 'Spence', 'M', 'Garland', 'TX', '2000-06-23'),
('Maria', 'Clark', 'F', 'Akron', 'OH', '2002-01-25'),
('Tracy', 'Woodward', 'F', 'Newark', 'NJ', '2002-10-04'),
('Erick', 'Woodward', 'M', 'Newark', 'NJ', '1998-08-05'),
('Lillie', 'Summers', 'F', 'Reno', 'NV', '1999-11-05'),
('Nellie', 'Marquez', 'F', 'Atlanta', 'GA', '2001-06-25'),
('Allen', 'Stokes', 'M', 'Bozeman', 'MT', '2004-09-16'),
('Josh', 'Rollins', 'M', 'Decatur', 'TN', '1998-11-28'),
('Isabel', 'Meyers', 'F', 'Rexburg', 'ID', '2003-05-15'),
('Kerri', 'Shah', 'F', 'Mesa', 'AZ', '2003-04-05'),
('Brady', 'Meyer', 'M', 'City', 'State', '1980-01-15'),
('Andy', 'Kipner', 'M', 'City', 'State', '1975-02-20'),
('Lucy', 'Fuller', 'F', 'City', 'State', '1982-03-25'),
('Adam', 'Woods', 'M', 'City', 'State', '1978-04-30'),
('Bryan', 'Drew', 'M', 'City', 'State', '1985-05-05');

-- Table 7
-- Inserting Role

INSERT INTO role (person_type) 
VALUES
('Student'),
('Teacher'),
('TA');


-- Table 8
-- Inserting Enrollment

INSERT INTO enrollment (person_id, section_id, role_id) 
VALUES
-- Teachers
(1, 1, 1), 
(1, 5, 1), 
(2, 2, 1), 
(2, 3, 1), 
(2, 7, 1), 
(2, 8, 1), 
(3, 4, 1), 
(4, 6, 1), 
(4, 9, 1), 
(5, 6, 1), 

-- Students and TAs 

(10, 1, 2), 
(10, 3, 2), 
(11, 4, 2), 
(12, 4, 2), 
(13, 6, 2), 
(14, 4, 2), 
(15, 6, 3), 
(16, 6, 2), 
(17, 5, 2), 
(17, 7, 3), 
(17, 9, 2), 
(18, 8, 2), 
(19, 8, 2), 
(20, 5, 2); 


