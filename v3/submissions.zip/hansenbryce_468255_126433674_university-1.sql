-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema university
-- -----------------------------------------------------
DROP SCHEMA IF EXISTS `university` ;

-- -----------------------------------------------------
-- Schema university
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `university` ;
USE `university` ;

-- -----------------------------------------------------
-- Table `university`.`department`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`department` ;

CREATE TABLE IF NOT EXISTS `university`.`department` (
  `department_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `department_name` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`department_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`degree`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`degree` ;

CREATE TABLE IF NOT EXISTS `university`.`degree` (
  `degree_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `degree_name` VARCHAR(45) NOT NULL,
  `department_id` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`degree_id`),
  INDEX `fk_degree_department_idx` (`department_id` ASC) VISIBLE,
  CONSTRAINT `fk_degree_department`
    FOREIGN KEY (`department_id`)
    REFERENCES `university`.`department` (`department_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`course`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`course` ;

CREATE TABLE IF NOT EXISTS `university`.`course` (
  `course_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` VARCHAR(45) NOT NULL,
  `course_num` INT NOT NULL,
  `credit` INT NOT NULL,
  `course_code` VARCHAR(5) NOT NULL,
  `degree_id` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`course_id`),
  INDEX `fk_course_degree1_idx` (`degree_id` ASC) VISIBLE,
  CONSTRAINT `fk_course_degree1`
    FOREIGN KEY (`degree_id`)
    REFERENCES `university`.`degree` (`degree_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`person`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`person` ;

CREATE TABLE IF NOT EXISTS `university`.`person` (
  `person_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `fname` VARCHAR(45) NOT NULL,
  `lname` VARCHAR(45) NOT NULL,
  `dob` DATE NULL,
  `gender` CHAR NULL,
  `city` VARCHAR(45) NULL,
  `state` VARCHAR(45) NULL,
  PRIMARY KEY (`person_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`semester`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`semester` ;

CREATE TABLE IF NOT EXISTS `university`.`semester` (
  `semester_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `term` VARCHAR(45) NOT NULL,
  `year` YEAR NOT NULL,
  PRIMARY KEY (`semester_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`section`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`section` ;

CREATE TABLE IF NOT EXISTS `university`.`section` (
  `section_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `section_num` INT NOT NULL,
  `capacity` INT NOT NULL,
  `course_id` INT UNSIGNED NOT NULL,
  `semester_id` INT UNSIGNED NOT NULL,
  INDEX `fk_semester_course_student_course1_idx` (`course_id` ASC) VISIBLE,
  PRIMARY KEY (`section_id`),
  INDEX `fk_section_semester1_idx` (`semester_id` ASC) VISIBLE,
  CONSTRAINT `fk_semester_course_student_course1`
    FOREIGN KEY (`course_id`)
    REFERENCES `university`.`course` (`course_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_section_semester1`
    FOREIGN KEY (`semester_id`)
    REFERENCES `university`.`semester` (`semester_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`role`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`role` ;

CREATE TABLE IF NOT EXISTS `university`.`role` (
  `role_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `role_name` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`role_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`enrollment`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`enrollment` ;

CREATE TABLE IF NOT EXISTS `university`.`enrollment` (
  `enrollment_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `person_id` INT UNSIGNED NOT NULL,
  `section_id` INT UNSIGNED NOT NULL,
  `role_id` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`enrollment_id`),
  INDEX `fk_enrollment_person1_idx` (`person_id` ASC) VISIBLE,
  INDEX `fk_enrollment_section1_idx` (`section_id` ASC) VISIBLE,
  INDEX `fk_enrollment_role1_idx` (`role_id` ASC) VISIBLE,
  CONSTRAINT `fk_enrollment_person1`
    FOREIGN KEY (`person_id`)
    REFERENCES `university`.`person` (`person_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_enrollment_section1`
    FOREIGN KEY (`section_id`)
    REFERENCES `university`.`section` (`section_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_enrollment_role1`
    FOREIGN KEY (`role_id`)
    REFERENCES `university`.`role` (`role_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
-- INSERTS
-- Insert departments
INSERT INTO university.department (department_name) VALUES 
('Computer Science and Engineering'),
('Mathematics'),
('Music');

-- Insert degrees
INSERT INTO university.degree (degree_name, department_id) VALUES 
('Computer Science', 1),
('Data Science', 2),
('Organ Performance', 3);

-- Insert courses
INSERT INTO university.course (title, course_num, credit, course_code, degree_id) VALUES 
('Parallelism and Concurrency', 251, 3, 'CSE', 1),
('Web Frontend Development I', 231, 2, 'WDD', 1),
('Calculus II', 113, 3, 'MATH', 2),
('Musicianship', 213, 4, 'MUSIC', 3);

-- Insert semesters
INSERT INTO university.semester (term, year) VALUES 
('Fall', 2024),
('Winter', 2025);

-- Insert persons 
INSERT INTO university.person (fname, lname, dob, gender, city, state) VALUES 
('Brady', 'Meyer', '1980-05-15', 'M', 'City', 'State'),
('Andy', 'Kipner', '1985-08-20', 'M', 'City', 'State'),
('Lucy', 'Fuller', '1983-10-10', 'F', 'City', 'State'),
('Adam', 'Woods', '1976-03-25', 'M', 'City', 'State'),
('Marshall', 'Spence', '2000-06-23', 'M', 'Garland', 'TX'),
('Maria', 'Clark', '2002-01-25', 'F', 'Akron', 'OH'),
('Tracy', 'Woodward', '2002-10-04', 'F', 'Newark', 'NJ'),
('Erick', 'Woodward', '1998-08-05', 'M', 'Newark', 'NJ'),
('Lillie', 'Summers', '1999-11-05', 'F', 'Reno', 'NV'),
('Nellie', 'Marquez', '2001-06-25', 'F', 'Atlanta', 'GA'),
('Allen', 'Stokes', '2004-09-16', 'M', 'Bozeman', 'MT'),
('Josh', 'Rollins', '1998-11-28', 'M', 'Decatur', 'TN'),
('Isabel', 'Meyers', '2003-05-15', 'F', 'Rexburg', 'ID'),
('Kerri', 'Shah', '2003-04-05', 'F', 'Mesa', 'AZ');

USE university;
-- Insert roles
INSERT INTO university.role (role_name) VALUES 
('Teacher'),
('Student'),
('TA');

-- Insert sections
INSERT INTO university.section (section_num, capacity, course_id, semester_id) VALUES 
(1, 35, 1, 1),
(1, 30, 2, 1),
(2, 30, 2, 1),
(1, 45, 3, 1),
(1, 25, 4, 1),
(2, 35, 1, 2),
(3, 35, 1, 2),
(1, 30, 2, 2),
(2, 40, 2, 2),
(1, 25, 4, 2);

-- Insert enrollments
INSERT INTO university.enrollment (person_id, section_id, role_id) VALUES 
-- Teachers
(1, 1, 1), -- Brady as Teacher for CSE 251 Fall 2024 Section 1
(1, 6, 1), -- Brady as Teacher for CSE 251 Winter 2025 Section 2
(2, 2, 1), -- Andy as Teacher for WDD 231 Fall 2024 Section 1
(2, 7, 1), -- Andy as Teacher for WDD 231 Winter 2025 Section 1
(2, 8, 1), -- Andy as Teacher for WDD 231 Winter 2025 Section 2
(2, 3, 1), -- Andy as Teacher for WDD 231 Fall 2024 Section 2
(3, 9, 1), -- Lucy as Teacher for MATH 113 Fall 2024 Section 1
(4, 5, 1), -- Adam as Teacher for MUSIC 213 Fall 2024 Section 1
(4, 10, 1), -- Adam as Teacher for MUSIC 213 Winter 2025 Section 1
(3, 11, 1), -- Bryan as Teacher for CSE 251 Winter 2025 Section 3
-- Students
(5, 1, 2), -- Marshall as Student for CSE 251 Fall 2024 Section 1
(5, 7, 2), -- Marshall as Student for CSE 251 Winter 2025 Section 3
(6, 4, 2), -- Maria as Student for MATH 113 Fall 2024 Section 1
(7, 4, 2), -- Tracy as Student for MATH 113 Fall 2024 Section 1
(8, 5, 2), -- Erick as Student for MUSIC 213 Fall 2024 Section 1
(9, 4, 2), -- Lillie as Student for MATH 113 Fall 2024 Section 1
(9, 5, 3), -- Lillie as TA for MUSIC 213 Fall 2024 Section 1
(10, 6, 2), -- Nellie as Student for CSE 251 Winter 2025 Section 3
(11, 8, 2), -- Allen as Student for CSE 251 Winter 2025 Section 2
(11, 10, 3), -- Allen as TA for WDD 231 Winter 2025 Section 1
(11, 10, 2), -- Allen as Student for MUSIC 213 Winter 2025 Section 1
(12, 7, 2), -- Josh as Student for WDD 231 Winter 2025 Section 1
(13, 8, 2), -- Isabel as Student for WDD 231 Winter 2025 Section 2
(14, 8, 2); -- Kerri as Student for CSE 251 Winter 2025 Section 2

-- Used AI to assist with the inserts
SELECT * FROM course;
SELECT * FROM degree;
SELECT * FROM department;
SELECT * FROM enrollment;
SELECT * FROM person;
SELECT * FROM role;
SELECT * FROM section;
SELECT * FROM semester;

SELECT fname, lname, role_name, course_code, course_num, section_num, term, year
FROM person p
INNER JOIN enrollment e ON e.person_id = p.person_id
INNER JOIN role r ON e.role_id = r.role_id
INNER JOIN section s ON e.section_id = s.section_id
INNER JOIN course c ON s.course_id = c.course_id
INNER JOIN semester sem ON s.semester_id = sem.semester_id
WHERE fname = 'Allen';

