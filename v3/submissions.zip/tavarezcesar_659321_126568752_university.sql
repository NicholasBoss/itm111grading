-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema university
-- -----------------------------------------------------
DROP SCHEMA IF EXISTS `university` ;

-- -----------------------------------------------------
-- Schema university
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `university` DEFAULT CHARACTER SET utf8 ;
USE `university` ;

-- -----------------------------------------------------
-- Table `university`.`person`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`person` ;

CREATE TABLE IF NOT EXISTS `university`.`person` (
  `person_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `first_name` VARCHAR(20) NOT NULL,
  `last_name` VARCHAR(20) NULL,
  `gender` ENUM('M', 'F') NULL,
  `birthdate` DATE NULL,
  `state` CHAR(2) NULL,
  `city` VARCHAR(45) NULL,
  PRIMARY KEY (`person_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`department`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`department` ;

CREATE TABLE IF NOT EXISTS `university`.`department` (
  `department_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `department_name` VARCHAR(35) NOT NULL,
  PRIMARY KEY (`department_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`degree`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`degree` ;

CREATE TABLE IF NOT EXISTS `university`.`degree` (
  `degree_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `degree_title` VARCHAR(30) NOT NULL,
  `department_id` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`degree_id`),
  INDEX `fk_degree_department1_idx` (`department_id` ASC) VISIBLE,
  CONSTRAINT `fk_degree_department1`
    FOREIGN KEY (`department_id`)
    REFERENCES `university`.`department` (`department_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`course`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`course` ;

CREATE TABLE IF NOT EXISTS `university`.`course` (
  `course_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `course_code` VARCHAR(10) NOT NULL,
  `course_num` INT UNSIGNED NOT NULL,
  `course_title` VARCHAR(35) NOT NULL,
  `credits` TINYINT(7) UNSIGNED NOT NULL,
  `degree_id` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`course_id`),
  INDEX `fk_course_degree1_idx` (`degree_id` ASC) VISIBLE,
  CONSTRAINT `fk_course_degree1`
    FOREIGN KEY (`degree_id`)
    REFERENCES `university`.`degree` (`degree_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`role`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`role` ;

CREATE TABLE IF NOT EXISTS `university`.`role` (
  `role_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `person_type` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`role_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`term`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`term` ;

CREATE TABLE IF NOT EXISTS `university`.`term` (
  `term_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `term_name` VARCHAR(45) NOT NULL,
  `term_year` INT NOT NULL,
  PRIMARY KEY (`term_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`section`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`section` ;

CREATE TABLE IF NOT EXISTS `university`.`section` (
  `section_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `section_number` TINYINT(5) UNSIGNED NOT NULL,
  `capacity` TINYINT(50) UNSIGNED NULL,
  `course_id` INT UNSIGNED NOT NULL,
  `term_id` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`section_id`),
  INDEX `fk_section_course1_idx` (`course_id` ASC) VISIBLE,
  INDEX `fk_section_term1_idx` (`term_id` ASC) VISIBLE,
  CONSTRAINT `fk_section_course1`
    FOREIGN KEY (`course_id`)
    REFERENCES `university`.`course` (`course_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_section_term1`
    FOREIGN KEY (`term_id`)
    REFERENCES `university`.`term` (`term_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`enrollment`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`enrollment` ;

CREATE TABLE IF NOT EXISTS `university`.`enrollment` (
  `enrollment_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `person_id` INT UNSIGNED NOT NULL,
  `section_id` INT UNSIGNED NOT NULL,
  `role_id` INT UNSIGNED NOT NULL,
  INDEX `fk_person_section_section1_idx` (`section_id` ASC) VISIBLE,
  INDEX `fk_person_section_person1_idx` (`person_id` ASC) VISIBLE,
  INDEX `fk_person_section_role1_idx` (`role_id` ASC) VISIBLE,
  PRIMARY KEY (`enrollment_id`),
  CONSTRAINT `fk_person_section_person1`
    FOREIGN KEY (`person_id`)
    REFERENCES `university`.`person` (`person_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_person_section_section1`
    FOREIGN KEY (`section_id`)
    REFERENCES `university`.`section` (`section_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_person_section_role1`
    FOREIGN KEY (`role_id`)
    REFERENCES `university`.`role` (`role_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;




INSERT INTO person (first_name, last_name, gender, city, state, birthdate) VALUES
('Marshall', 'Spence', 'M', 'Garland', 'TX',  '2000-06-23'),
('Maria', 'Clark', 'F', 'Akron', 'OH', '2002-01-25'),
('Tracy', 'Woodward', 'F', 'Newark', 'NJ', '2002-10-04'),
('Erick', 'Woodward', 'M', 'Newark', 'NJ', '1998-08-05'),
('Lillie', 'Bummers', 'F', 'Reno', 'NV', '1999-11-05'),
('Nellie', 'Marquez', 'F', 'Atlanta', 'GA', '2001-06-25'),
('Allen', 'Stokes', 'M', 'Bozeman', 'MT', '2004-09-16'),
('Josh', 'Rollins', 'M', 'Decatur', 'TN', '1998-11-28'),
('Isabel', 'Meyers', 'F', 'Reburg', 'ID', '2003-05-15'),
('Kerri', 'Shah', 'F', 'Mesa', 'AZ', '2003-04-05');

INSERT INTO person (first_name) VALUES
('Brady'),
('Andy'),
('Lucy'),
('Adam'),
('Bryan');

INSERT INTO role (person_type)Values
('Teacher'),
('Student'),
('TA');

INSERT INTO department(department_name) VALUES
('Computer Science and Engineering'),
('Mathmatics'),
('Music');

-- select * from department;
INSERT INTO degree(degree_title, department_id) VALUES
('Computer Science', 1),
('Web Design and Development', 1),
('Data Science', 2),
('Organ Preformance', 3);

-- select * from degree;
INSERT INTO course (course_code, course_num, course_title, credits, degree_id) VALUES
('CSE', 251, 'Parallelism and Concurrency', 3, 1),
('WDD', 231, 'Web Fronted Development', 1, 2),
('MATH', 113, 'Calculus 2', 3, 3),
('MUSIC', 213, 'Musicianship 4', 3, 4);

INSERT INTO term(term_name, term_year) VALUES
('Fall', '2024'),
('Winter', '2025');

INSERT INTO section (section_number, course_id, term_id, capacity) VALUES
(1, 1, 1, 35),
(2, 1, 2, 35),
(1, 2, 1, 30),
(2, 2, 1, 30),
(1, 2, 1, NULL),
(2, 2, 2, 40),
(1, 3, 1, 45),
(1, 4, 1, 25),
(1, 4, 2, 25),
(3, 1, 2, 35),
(1, 2, 2, 30),
(2, 2, 2, NULL);


INSERT INTO enrollment(person_id, section_id, role_id) VALUES
(11, 1, 1), --
(11, 2, 1), --
(12, 3, 1), --
(12, 4, 1), --
(12, 11, 1), --
(12, 12, 1), --
(13, 7, 1), --
(14, 8, 1), --
(14, 9, 1), --
(15, 10, 1), --
(1, 1, 2), --
(1, 4, 2), --
(2, 7, 2), --
(3, 7, 2), --
(4, 8, 2), --
(5, 7, 2),  --
(5, 8, 3), --
(6, 10, 2), --
(7, 2, 2), --
(7, 11, 3), --
(7, 9, 2), --
(8, 6, 2), --
(9, 6, 2), --
(10, 2, 2);

SELECT first_name, last_name, person_type, CONCAT(course_code, course_num ) AS course, section_number, term_name, term_year
FROM person p
INNER JOIN enrollment e ON p.person_id = e.person_id
INNER JOIN role r ON e.role_id = r.role_id
INNER JOIN section s ON s.section_id = e.section_id
INNER JOIN term t ON t.term_id = s.term_id
INNER JOIN course c ON c.course_id = s.course_id
INNER JOIN degree d ON d.degree_id = c.degree_id
INNER JOIN department dep ON dep.department_id = d.department_id
WHERE first_name = 'Allen';
