-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema university
-- -----------------------------------------------------
DROP SCHEMA IF EXISTS `university` ;

-- -----------------------------------------------------
-- Schema university
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `university` DEFAULT CHARACTER SET utf8 ;
USE `university` ;

-- -----------------------------------------------------
-- Table `university`.`department`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`department` ;

CREATE TABLE IF NOT EXISTS `university`.`department` (
  `department_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `department_name` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`department_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`person`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`person` ;

CREATE TABLE IF NOT EXISTS `university`.`person` (
  `person_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `first_name` VARCHAR(45) NOT NULL,
  `middle_name` VARCHAR(45) NULL,
  `last_name` VARCHAR(45) NOT NULL,
  `gender` CHAR(1) NULL,
  `state_abv` CHAR(2) NULL,
  `city_name` VARCHAR(45) NULL,
  `birthday` DATE NULL,
  PRIMARY KEY (`person_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`course_code`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`course_code` ;

CREATE TABLE IF NOT EXISTS `university`.`course_code` (
  `course_code_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `course_code` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`course_code_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`degree`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`degree` ;

CREATE TABLE IF NOT EXISTS `university`.`degree` (
  `degree_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `department_id` INT UNSIGNED NOT NULL,
  `degree_name` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`degree_id`),
  INDEX `fk_degree_department1_idx` (`department_id` ASC) VISIBLE,
  CONSTRAINT `fk_degree_department1`
    FOREIGN KEY (`department_id`)
    REFERENCES `university`.`department` (`department_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`course`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`course` ;

CREATE TABLE IF NOT EXISTS `university`.`course` (
  `course_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `degree_id` INT UNSIGNED NOT NULL,
  `course_code_id` INT UNSIGNED NOT NULL,
  `course_num` INT UNSIGNED NOT NULL,
  `course_name` VARCHAR(45) NOT NULL,
  `credit` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`course_id`),
  INDEX `fk_course_course_code1_idx` (`course_code_id` ASC) VISIBLE,
  INDEX `fk_course_degree1_idx` (`degree_id` ASC) VISIBLE,
  CONSTRAINT `fk_course_course_code1`
    FOREIGN KEY (`course_code_id`)
    REFERENCES `university`.`course_code` (`course_code_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_course_degree1`
    FOREIGN KEY (`degree_id`)
    REFERENCES `university`.`degree` (`degree_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`term`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`term` ;

CREATE TABLE IF NOT EXISTS `university`.`term` (
  `term_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `term_name` VARCHAR(45) NOT NULL,
  `year` YEAR NOT NULL,
  PRIMARY KEY (`term_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`role`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`role` ;

CREATE TABLE IF NOT EXISTS `university`.`role` (
  `role_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `role_name` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`role_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`section`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`section` ;

CREATE TABLE IF NOT EXISTS `university`.`section` (
  `section_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `course_id` INT UNSIGNED NOT NULL,
  `section_num` INT UNSIGNED NOT NULL,
  `term_id` INT UNSIGNED NOT NULL,
  `capacity` INT UNSIGNED NOT NULL,
  `last_updated` TIMESTAMP NOT NULL,
  PRIMARY KEY (`section_id`),
  INDEX `fk_course_has_section_course1_idx` (`course_id` ASC) VISIBLE,
  INDEX `fk_course_has_section_term1_idx` (`term_id` ASC) VISIBLE,
  CONSTRAINT `fk_course_has_section_course1`
    FOREIGN KEY (`course_id`)
    REFERENCES `university`.`course` (`course_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_course_has_section_term1`
    FOREIGN KEY (`term_id`)
    REFERENCES `university`.`term` (`term_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`enrollment`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`enrollment` ;

CREATE TABLE IF NOT EXISTS `university`.`enrollment` (
  `enrollment_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `person_id` INT UNSIGNED NOT NULL,
  `role_id` INT UNSIGNED NOT NULL,
  `section_id` INT UNSIGNED NOT NULL,
  INDEX `fk_person_has_role_role1_idx` (`role_id` ASC) VISIBLE,
  INDEX `fk_person_has_role_person1_idx` (`person_id` ASC) VISIBLE,
  PRIMARY KEY (`enrollment_id`),
  INDEX `fk_person_has_role_course_has_section1_idx` (`section_id` ASC) VISIBLE,
  CONSTRAINT `fk_person_has_role_person1`
    FOREIGN KEY (`person_id`)
    REFERENCES `university`.`person` (`person_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_person_has_role_role1`
    FOREIGN KEY (`role_id`)
    REFERENCES `university`.`role` (`role_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_person_has_role_course_has_section1`
    FOREIGN KEY (`section_id`)
    REFERENCES `university`.`section` (`section_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;



use university;

-- ROLE INSERT
INSERT INTO role (role_name) VALUES ('Teacher'), ('Student'), ('TA');

/*-- ROLE SELECT
SELECT * FROM role;*/

-- DEPARTMENT INSERT
INSERT INTO department (department_name) VALUES ('Computer Science and Engineering'), ('Mathematics'), ('Music');

/*-- DEPARTMENT SELECT
SELECT * FROM department;*/

-- DEGREE INSERT
INSERT INTO degree (degree_name, department_id) VALUES ('Computer Science', (SELECT department_id FROM department WHERE department_name = 'Computer Science and Engineering')), ('Web Design and Development', (SELECT department_id FROM department WHERE department_name = 'Computer Science and Engineering')), ('Data Science', (SELECT department_id FROM department WHERE department_name = 'Mathematics')), ('Organ Performance', (SELECT department_id FROM department WHERE department_name = 'Music'));

/*-- DEGREE SELECT
SELECT * FROM degree;*/

-- TERM INSERT
INSERT INTO term (term_name, year) VALUES ('Fall', 2024), ('Fall', 2025), ('Winter', 2024), ('Winter', 2025), ('Spring', 2024), ('Spring', 2025), ('Summer', 2024), ('Summer', 2024);

/*-- TERM SELECT
SELECT * FROM term;*/

-- COURSE_CODE INSERT
INSERT INTO course_code (course_code) VALUES ('CSE'), ('WDD'), ('MATH'), ('MUSIC');

/*-- COURSE_CODE SELECT
SELECT * FROM course_code;*/

-- PERSON INSERT
INSERT INTO person (first_name, middle_name, last_name, gender, state_abv, city_name, birthday) VALUES
('Marshall', NULL, 'Spence',  'M', 'TX', 'Garland', '2000-06-23')
, ('Maria', NULL, 'Clark',  'F', 'OH', 'Akron', '2002-01-25')
, ('Tracy', NULL, 'Woodward',  'F', 'NJ', 'Newark', '2002-10-04')
, ('Erick', NULL, 'Woodward',  'M', 'NJ', 'Newark', '1998-08-05')
, ('Lillie', NULL, 'Summers',  'F', 'NV', 'Reno', '1999-11-05')
, ('Nellie', NULL, 'Marquez',  'F', 'GA', 'Atlanta', '2001-06-25')
, ('Allen', NULL, 'Stokes',  'M', 'MT', 'Bozeman', '2004-09-16')
, ('Josh', NULL, 'Rollins',  'M', 'TN', 'Decatur', '1998-11-28')
, ('Isabel', NULL, 'Meyers',  'F', 'ID', 'Rexburg', '2003-05-15')
, ('Kerri', NULL, 'Shah', 'F', 'AZ', 'Mesa', '2003-04-05')
, ('Brady', NULL, 'Meyer',  NULL, NULL, NULL, NULL)
, ('Andy', NULL, 'Kipner',  NULL, NULL, NULL, NULL)
, ('Lucy', NULL, 'Fuller',  NULL, NULL, NULL, NULL)
, ('Adam', NULL, 'Woods',  NULL, NULL, NULL, NULL)
, ('Bryan', NULL, 'Drew',  NULL, NULL, NULL, NULL);

/*-- PERSON SELECT
SELECT * FROM person;*/

-- COURSE INSERT
INSERT INTO course (degree_id, course_code_id, course_num, course_name, credit) VALUES
((SELECT degree_id FROM degree WHERE degree_name = 'Computer Science'), (SELECT course_code_id FROM course_code WHERE course_code = 'CSE'), 251, 'Parallelism and Concurrency', 3)
, ((SELECT degree_id FROM degree WHERE degree_name = 'Web Design and Development'), (SELECT course_code_id FROM course_code WHERE course_code = 'WDD'), 231, 'Web Frontend Development I', 2)
, ((SELECT degree_id FROM degree WHERE degree_name = 'Data Science'), (SELECT course_code_id FROM course_code WHERE course_code = 'MATH'), 113, 'Calculus II', 3)
, ((SELECT degree_id FROM degree WHERE degree_name = 'Organ Performance'), (SELECT course_code_id FROM course_code WHERE course_code = 'MUSIC'), 213, 'Musicianship 4', 3);

/*-- COURSE SELECT
SELECT * FROM course;*/

-- section INSERT
INSERT INTO section (course_id, section_num, term_id, capacity, last_updated) VALUES
((SELECT course_id FROM course WHERE course_num = 251), 1, (SELECT term_id FROM term WHERE CONCAT(term_name, ' ', year) = 'Fall 2024'), 35, now())
, ((SELECT course_id FROM course WHERE course_num = 251), 2, (SELECT term_id FROM term WHERE CONCAT(term_name, ' ', year) = 'Winter 2025'), 35, now())
, ((SELECT course_id FROM course WHERE course_num = 251), 3, (SELECT term_id FROM term WHERE CONCAT(term_name, ' ', year) = 'Winter 2025'), 35, now())
, ((SELECT course_id FROM course WHERE course_num = 231), 1, (SELECT term_id FROM term WHERE CONCAT(term_name, ' ', year) = 'Fall 2024'), 30, now())
, ((SELECT course_id FROM course WHERE course_num = 231), 2, (SELECT term_id FROM term WHERE CONCAT(term_name, ' ', year) = 'Fall 2024'), 30, now())
, ((SELECT course_id FROM course WHERE course_num = 231), 1, (SELECT term_id FROM term WHERE CONCAT(term_name, ' ', year) = 'Winter 2025'), 30, now())
, ((SELECT course_id FROM course WHERE course_num = 231), 2, (SELECT term_id FROM term WHERE CONCAT(term_name, ' ', year) = 'Winter 2025'), 40, now())
, ((SELECT course_id FROM course WHERE course_num = 113), 1, (SELECT term_id FROM term WHERE CONCAT(term_name, ' ', year) = 'Fall 2024'), 45, now())
, ((SELECT course_id FROM course WHERE course_num = 213), 1, (SELECT term_id FROM term WHERE CONCAT(term_name, ' ', year) = 'Fall 2024'), 25, now())
, ((SELECT course_id FROM course WHERE course_num = 213), 1, (SELECT term_id FROM term WHERE CONCAT(term_name, ' ', year) = 'Winter 2025'), 25, now());

/*-- section SELECT
SELECT CONCAT(course_code, ' ', course_num) AS course, section_num, CONCAT(term_name, ' ', year) AS term FROM section s 
INNER JOIN course c ON c.course_id = s.course_id 
INNER JOIN term t ON t.term_id = s.term_id 
INNER JOIN course_code cc ON cc.course_code_id = c.course_code_id;*/

-- enrollment INSERT
INSERT INTO enrollment (person_id, role_id, section_id) VALUES 
((SELECT person_id FROM person WHERE first_name = 'Brady'), (SELECT role_id FROM role WHERE role_name = 'Teacher'), (SELECT section_id FROM section cs INNER JOIN course c ON c.course_id = cs.course_id INNER JOIN term t ON t.term_id = cs.term_id INNER JOIN course_code cc ON cc.course_code_id = c.course_code_id WHERE CONCAT(course_num, ' ', section_num, ' ', term_name, ' ', year) = '251 1 Fall 2024'))
, ((SELECT person_id FROM person WHERE first_name = 'Brady'), (SELECT role_id FROM role WHERE role_name = 'Teacher'), (SELECT section_id FROM section cs INNER JOIN course c ON c.course_id = cs.course_id INNER JOIN term t ON t.term_id = cs.term_id INNER JOIN course_code cc ON cc.course_code_id = c.course_code_id WHERE CONCAT(course_num, ' ', section_num, ' ', term_name, ' ', year) = '251 2 Winter 2025'))
, ((SELECT person_id FROM person WHERE first_name = 'Andy'), (SELECT role_id FROM role WHERE role_name = 'Teacher'), (SELECT section_id FROM section cs INNER JOIN course c ON c.course_id = cs.course_id INNER JOIN term t ON t.term_id = cs.term_id INNER JOIN course_code cc ON cc.course_code_id = c.course_code_id WHERE CONCAT(course_num, ' ', section_num, ' ', term_name, ' ', year) = '231 1 Fall 2024'))
, ((SELECT person_id FROM person WHERE first_name = 'Andy'), (SELECT role_id FROM role WHERE role_name = 'Teacher'), (SELECT section_id FROM section cs INNER JOIN course c ON c.course_id = cs.course_id INNER JOIN term t ON t.term_id = cs.term_id INNER JOIN course_code cc ON cc.course_code_id = c.course_code_id WHERE CONCAT(course_num, ' ', section_num, ' ', term_name, ' ', year) = '231 2 Fall 2024'))
, ((SELECT person_id FROM person WHERE first_name = 'Andy'), (SELECT role_id FROM role WHERE role_name = 'Teacher'), (SELECT section_id FROM section cs INNER JOIN course c ON c.course_id = cs.course_id INNER JOIN term t ON t.term_id = cs.term_id INNER JOIN course_code cc ON cc.course_code_id = c.course_code_id WHERE CONCAT(course_num, ' ', section_num, ' ', term_name, ' ', year) = '231 1 Winter 2025'))
, ((SELECT person_id FROM person WHERE first_name = 'Andy'), (SELECT role_id FROM role WHERE role_name = 'Teacher'), (SELECT section_id FROM section cs INNER JOIN course c ON c.course_id = cs.course_id INNER JOIN term t ON t.term_id = cs.term_id INNER JOIN course_code cc ON cc.course_code_id = c.course_code_id WHERE CONCAT(course_num, ' ', section_num, ' ', term_name, ' ', year) = '231 2 Winter 2025'))
, ((SELECT person_id FROM person WHERE first_name = 'Lucy'), (SELECT role_id FROM role WHERE role_name = 'Teacher'), (SELECT section_id FROM section cs INNER JOIN course c ON c.course_id = cs.course_id INNER JOIN term t ON t.term_id = cs.term_id INNER JOIN course_code cc ON cc.course_code_id = c.course_code_id WHERE CONCAT(course_num, ' ', section_num, ' ', term_name, ' ', year) = '113 1 Fall 2024'))
, ((SELECT person_id FROM person WHERE first_name = 'Adam'), (SELECT role_id FROM role WHERE role_name = 'Teacher'), (SELECT section_id FROM section cs INNER JOIN course c ON c.course_id = cs.course_id INNER JOIN term t ON t.term_id = cs.term_id INNER JOIN course_code cc ON cc.course_code_id = c.course_code_id WHERE CONCAT(course_num, ' ', section_num, ' ', term_name, ' ', year) = '213 1 Fall 2024'))
, ((SELECT person_id FROM person WHERE first_name = 'Adam'), (SELECT role_id FROM role WHERE role_name = 'Teacher'), (SELECT section_id FROM section cs INNER JOIN course c ON c.course_id = cs.course_id INNER JOIN term t ON t.term_id = cs.term_id INNER JOIN course_code cc ON cc.course_code_id = c.course_code_id WHERE CONCAT(course_num, ' ', section_num, ' ', term_name, ' ', year) = '213 1 Winter 2025'))
, ((SELECT person_id FROM person WHERE first_name = 'Bryan'), (SELECT role_id FROM role WHERE role_name = 'Teacher'), (SELECT section_id FROM section cs INNER JOIN course c ON c.course_id = cs.course_id INNER JOIN term t ON t.term_id = cs.term_id INNER JOIN course_code cc ON cc.course_code_id = c.course_code_id WHERE CONCAT(course_num, ' ', section_num, ' ', term_name, ' ', year) = '251 3 Winter 2025'))
, ((SELECT person_id FROM person WHERE first_name = 'Marshall'), (SELECT role_id FROM role WHERE role_name = 'Student'), (SELECT section_id FROM section cs INNER JOIN course c ON c.course_id = cs.course_id INNER JOIN term t ON t.term_id = cs.term_id INNER JOIN course_code cc ON cc.course_code_id = c.course_code_id WHERE CONCAT(course_num, ' ', section_num, ' ', term_name, ' ', year) = '251 1 Fall 2024'))
, ((SELECT person_id FROM person WHERE first_name = 'Marshall'), (SELECT role_id FROM role WHERE role_name = 'Student'), (SELECT section_id FROM section cs INNER JOIN course c ON c.course_id = cs.course_id INNER JOIN term t ON t.term_id = cs.term_id INNER JOIN course_code cc ON cc.course_code_id = c.course_code_id WHERE CONCAT(course_num, ' ', section_num, ' ', term_name, ' ', year) = '231 2 Fall 2024'))
, ((SELECT person_id FROM person WHERE first_name = 'Maria'), (SELECT role_id FROM role WHERE role_name = 'Student'), (SELECT section_id FROM section cs INNER JOIN course c ON c.course_id = cs.course_id INNER JOIN term t ON t.term_id = cs.term_id INNER JOIN course_code cc ON cc.course_code_id = c.course_code_id WHERE CONCAT(course_num, ' ', section_num, ' ', term_name, ' ', year) = '113 1 Fall 2024'))
, ((SELECT person_id FROM person WHERE first_name = 'Tracy'), (SELECT role_id FROM role WHERE role_name = 'Student'), (SELECT section_id FROM section cs INNER JOIN course c ON c.course_id = cs.course_id INNER JOIN term t ON t.term_id = cs.term_id INNER JOIN course_code cc ON cc.course_code_id = c.course_code_id WHERE CONCAT(course_num, ' ', section_num, ' ', term_name, ' ', year) = '113 1 Fall 2024'))
, ((SELECT person_id FROM person WHERE first_name = 'Erick'), (SELECT role_id FROM role WHERE role_name = 'Student'), (SELECT section_id FROM section cs INNER JOIN course c ON c.course_id = cs.course_id INNER JOIN term t ON t.term_id = cs.term_id INNER JOIN course_code cc ON cc.course_code_id = c.course_code_id WHERE CONCAT(course_num, ' ', section_num, ' ', term_name, ' ', year) = '213 1 Fall 2024'))
, ((SELECT person_id FROM person WHERE first_name = 'Lillie'), (SELECT role_id FROM role WHERE role_name = 'Student'), (SELECT section_id FROM section cs INNER JOIN course c ON c.course_id = cs.course_id INNER JOIN term t ON t.term_id = cs.term_id INNER JOIN course_code cc ON cc.course_code_id = c.course_code_id WHERE CONCAT(course_num, ' ', section_num, ' ', term_name, ' ', year) = '113 1 Fall 2024'))
, ((SELECT person_id FROM person WHERE first_name = 'Lillie'), (SELECT role_id FROM role WHERE role_name = 'TA'), (SELECT section_id FROM section cs INNER JOIN course c ON c.course_id = cs.course_id INNER JOIN term t ON t.term_id = cs.term_id INNER JOIN course_code cc ON cc.course_code_id = c.course_code_id WHERE CONCAT(course_num, ' ', section_num, ' ', term_name, ' ', year) = '213 1 Fall 2024'))
, ((SELECT person_id FROM person WHERE first_name = 'Nellie'), (SELECT role_id FROM role WHERE role_name = 'Student'), (SELECT section_id FROM section cs INNER JOIN course c ON c.course_id = cs.course_id INNER JOIN term t ON t.term_id = cs.term_id INNER JOIN course_code cc ON cc.course_code_id = c.course_code_id WHERE CONCAT(course_num, ' ', section_num, ' ', term_name, ' ', year) = '251 3 Winter 2025'))
, ((SELECT person_id FROM person WHERE first_name = 'Allen'), (SELECT role_id FROM role WHERE role_name = 'Student'), (SELECT section_id FROM section cs INNER JOIN course c ON c.course_id = cs.course_id INNER JOIN term t ON t.term_id = cs.term_id INNER JOIN course_code cc ON cc.course_code_id = c.course_code_id WHERE CONCAT(course_num, ' ', section_num, ' ', term_name, ' ', year) = '251 2 Winter 2025'))
, ((SELECT person_id FROM person WHERE first_name = 'Allen'), (SELECT role_id FROM role WHERE role_name = 'Student'), (SELECT section_id FROM section cs INNER JOIN course c ON c.course_id = cs.course_id INNER JOIN term t ON t.term_id = cs.term_id INNER JOIN course_code cc ON cc.course_code_id = c.course_code_id WHERE CONCAT(course_num, ' ', section_num, ' ', term_name, ' ', year) = '213 1 Winter 2025'))
, ((SELECT person_id FROM person WHERE first_name = 'Allen'), (SELECT role_id FROM role WHERE role_name = 'TA'), (SELECT section_id FROM section cs INNER JOIN course c ON c.course_id = cs.course_id INNER JOIN term t ON t.term_id = cs.term_id INNER JOIN course_code cc ON cc.course_code_id = c.course_code_id WHERE CONCAT(course_num, ' ', section_num, ' ', term_name, ' ', year) = '231 1 Winter 2025'))
, ((SELECT person_id FROM person WHERE first_name = 'Josh'), (SELECT role_id FROM role WHERE role_name = 'Student'), (SELECT section_id FROM section cs INNER JOIN course c ON c.course_id = cs.course_id INNER JOIN term t ON t.term_id = cs.term_id INNER JOIN course_code cc ON cc.course_code_id = c.course_code_id WHERE CONCAT(course_num, ' ', section_num, ' ', term_name, ' ', year) = '231 2 Winter 2025'))
, ((SELECT person_id FROM person WHERE first_name = 'Isabel'), (SELECT role_id FROM role WHERE role_name = 'Student'), (SELECT section_id FROM section cs INNER JOIN course c ON c.course_id = cs.course_id INNER JOIN term t ON t.term_id = cs.term_id INNER JOIN course_code cc ON cc.course_code_id = c.course_code_id WHERE CONCAT(course_num, ' ', section_num, ' ', term_name, ' ', year) = '231 2 Winter 2025'))
, ((SELECT person_id FROM person WHERE first_name = 'Kerri'), (SELECT role_id FROM role WHERE role_name = 'Student'), (SELECT section_id FROM section cs INNER JOIN course c ON c.course_id = cs.course_id INNER JOIN term t ON t.term_id = cs.term_id INNER JOIN course_code cc ON cc.course_code_id = c.course_code_id WHERE CONCAT(course_num, ' ', section_num, ' ', term_name, ' ', year) = '251 2 Winter 2025'));

/*
-- Catalog View
SELECT department_name, degree_name, course_code, course_num, course_name, credit FROM course c 
INNER JOIN course_code cc ON c.course_code_id = cc.course_code_id
INNER JOIN degree d ON d.degree_id = c.degree_id
INNER JOIN department de ON de.department_id = d.department_id;


-- Section View
SELECT year, term_name, CONCAT(course_code, ' ', course_num) AS course, CONCAT('Section ', section_num) AS section, first_name, last_name, capacity FROM enrollment e 
INNER JOIN person p ON p.person_id = e.person_id 
INNER JOIN role r ON r.role_id = e.role_id 
INNER JOIN section s ON s.section_id = e.section_id 
INNER JOIN course c ON c.course_id = s.course_id 
INNER JOIN course_code cc ON cc.course_code_id = c.course_code_id
INNER JOIN term t ON t.term_id = s.term_id
WHERE role_name = 'Teacher';


-- Student View
SELECT first_name, last_name, gender, city_name, state_abv, birthday FROM person p
INNER JOIN enrollment e ON e.person_id = p.person_id
INNER JOIN role r ON r.role_id = e.role_id
WHERE role_name = 'Student';

-- Enrollment View
SELECT first_name, role_name, CONCAT(course_code, ' ', course_num) AS course, CONCAT(term_name, ' ', year) AS term, CONCAT('Section ', section_num) AS section FROM enrollment e 
INNER JOIN person p ON p.person_id = e.person_id 
INNER JOIN role r ON r.role_id = e.role_id 
INNER JOIN section s ON s.section_id = e.section_id 
INNER JOIN course c ON c.course_id = s.course_id 
INNER JOIN course_code cc ON cc.course_code_id = c.course_code_id
INNER JOIN term t ON t.term_id = s.term_id;
*/