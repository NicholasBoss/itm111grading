-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema university
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema university
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `university` DEFAULT CHARACTER SET utf8 ;
USE `university` ;

-- -----------------------------------------------------
-- Table `university`.`department`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`department` ;

CREATE TABLE IF NOT EXISTS `university`.`department` (
  `department_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `department_name` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`department_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`degree`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`degree` ;

CREATE TABLE IF NOT EXISTS `university`.`degree` (
  `degree_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `degree_name` VARCHAR(45) NOT NULL,
  `department_id` INT UNSIGNED NOT NULL,
  `course_code` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`degree_id`),
  INDEX `fk_degree_department1_idx` (`department_id` ASC) VISIBLE,
  CONSTRAINT `fk_degree_department1`
    FOREIGN KEY (`department_id`)
    REFERENCES `university`.`department` (`department_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`course`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`course` ;

CREATE TABLE IF NOT EXISTS `university`.`course` (
  `course_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `course_title` VARCHAR(45) NOT NULL,
  `course_num` INT NOT NULL,
  `credits` INT NOT NULL,
  `degree_id` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`course_id`),
  INDEX `fk_course_degree_idx` (`degree_id` ASC) VISIBLE,
  CONSTRAINT `fk_course_degree`
    FOREIGN KEY (`degree_id`)
    REFERENCES `university`.`degree` (`degree_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`term`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`term` ;

CREATE TABLE IF NOT EXISTS `university`.`term` (
  `term_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `term_name` VARCHAR(45) NOT NULL,
  `year` INT NOT NULL,
  PRIMARY KEY (`term_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`section`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`section` ;

CREATE TABLE IF NOT EXISTS `university`.`section` (
  `section_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `section_num` INT NOT NULL,
  `capacity` INT NOT NULL,
  `course_id` INT UNSIGNED NOT NULL,
  `term_id` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`section_id`),
  INDEX `fk_section_course1_idx` (`course_id` ASC) VISIBLE,
  INDEX `fk_section_terms1_idx` (`term_id` ASC) VISIBLE,
  CONSTRAINT `fk_section_course1`
    FOREIGN KEY (`course_id`)
    REFERENCES `university`.`course` (`course_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_section_terms1`
    FOREIGN KEY (`term_id`)
    REFERENCES `university`.`term` (`term_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`person`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`person` ;

CREATE TABLE IF NOT EXISTS `university`.`person` (
  `person_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `f_name` VARCHAR(45) NOT NULL,
  `l_name` VARCHAR(45) NOT NULL,
  `gender` VARCHAR(45) NULL,
  `city` VARCHAR(45) NULL,
  `state` VARCHAR(45) NULL,
  `birthdate` DATE NULL,
  PRIMARY KEY (`person_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`role`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`role` ;

CREATE TABLE IF NOT EXISTS `university`.`role` (
  `role_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `role` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`role_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`enrollment`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`enrollment` ;

CREATE TABLE IF NOT EXISTS `university`.`enrollment` (
  `enrollmentl_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `section_id` INT UNSIGNED NOT NULL,
  `person_id` INT UNSIGNED NOT NULL,
  `role_id` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`enrollmentl_id`),
  INDEX `fk_section_person_person1_idx` (`person_id` ASC) VISIBLE,
  INDEX `fk_section_person_section1_idx` (`section_id` ASC) VISIBLE,
  INDEX `fk_enrollment_enrollment_type1_idx` (`role_id` ASC) VISIBLE,
  CONSTRAINT `fk_section_person_section1`
    FOREIGN KEY (`section_id`)
    REFERENCES `university`.`section` (`section_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_section_person_person1`
    FOREIGN KEY (`person_id`)
    REFERENCES `university`.`person` (`person_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_enrollment_enrollment_type1`
    FOREIGN KEY (`role_id`)
    REFERENCES `university`.`role` (`role_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;


-- ----------------------------------------------------------- --
-- ----------------------------------------------------------- --
-- ----------------------------------------------------------- --

USE university;

INSERT INTO department (department_name) VALUES
	('Computer Science and Engineering'),
    ('Mathematics'),
    ('Music');

INSERT INTO term (term_name, year) VALUES
	('Fall', 2024),
    ('Winter', 2025);
    
INSERT INTO role (role) VALUES
	('Teacher'),
    ('Student'),
    ('TA');
    
INSERT INTO person (f_name, l_name, gender, city, state, birthdate) VALUES
	('Brady', 'Meyer', NULL, NULL, NULL, NULL),
	('Andy', 'Kipner', NULL, NULL, NULL, NULL),
	('Lucy', 'Fuller', NULL, NULL, NULL, NULL),
	('Adam', 'Woods', NULL, NULL, NULL, NULL),
	('Bryan', 'Drew', NULL, NULL, NULL, NULL),
	('Marshall', 'Spence', 'M', 'Garland', 'TX', '2000-06-23'),
    ('Maria', 'Clark', 'F', 'Akron', 'OH', '2002-01-25'),
    ('Tracy', 'Woodward', 'F', 'Newark', 'NJ', '2002-10-04'),
    ('Erick', 'Woodward', 'M', 'Newark', 'NV', '1998-08-25'), 
	('Lillie', 'Summer', 'F', 'Reno', 'NV', '1999-11-05'),
    ('Nellie', 'Marquez', 'F', 'Atlanta', 'GA', '2001-06-25'),
    ('Allen', 'Stokes', 'M', 'Bozeman', 'MT', '2004-09-16'),
    ('Josh', 'Rollins', 'M', 'Decatur', 'TN', '1996-11-28'),
    ('Isabel', 'Meyers', 'F', 'Rexburg', 'ID', '2002-05-15'),
    ('Kerri', 'Shah', 'F', 'Mesa', 'AZ', '2003-04-05');
    
INSERT INTO degree (degree_name, department_id, course_code) VALUES
	('Computer Science', (SELECT department_id FROM department WHERE department_name = 'Computer Science and Engineering'), 'CSE'),
	('Web Design and Development', (SELECT department_id FROM department WHERE department_name = 'Computer Science and Engineering'), 'WDD'),
    ('Data Science', (SELECT department_id FROM department WHERE department_name = 'Mathematics'), 'MATH'),
    ('Organ Performance', (SELECT department_id FROM department WHERE department_name = 'Music'), 'MUSIC');

INSERT INTO course (course_title, course_num, credits, degree_id) VALUES
	('Parallelism and Concurrency', 251, 3, (SELECT degree_id FROM degree WHERE course_code = 'CSE')),
    ('Web Frontend Development I', 231, 2, (SELECT degree_id FROM degree WHERE course_code = 'WDD')),
    ('Calculus II', 113, 3, (SELECT degree_id FROM degree WHERE course_code = 'MATH')),
    ('Musicianship 4', 213, 3, (SELECT degree_id FROM degree WHERE course_code = 'MUSIC'));
    
INSERT INTO section (section_num, capacity, course_id, term_id) VALUES
	(1, 35, (SELECT course_id FROM course WHERE course_num = 251), (SELECT term_id FROM term WHERE term_name = 'Fall')),
    (1, 30, (SELECT course_id FROM course WHERE course_num = 231), (SELECT term_id FROM term WHERE term_name = 'Fall')),
    (2, 30, (SELECT course_id FROM course WHERE course_num = 231), (SELECT term_id FROM term WHERE term_name = 'Fall')),
    (1, 45, (SELECT course_id FROM course WHERE course_num = 113), (SELECT term_id FROM term WHERE term_name = 'Fall')),
    (1, 25, (SELECT course_id FROM course WHERE course_num = 213), (SELECT term_id FROM term WHERE term_name = 'Fall')),
    (2, 35, (SELECT course_id FROM course WHERE course_num = 251), (SELECT term_id FROM term WHERE term_name = 'Winter')),
    (3, 35, (SELECT course_id FROM course WHERE course_num = 251), (SELECT term_id FROM term WHERE term_name = 'Winter')),
    (1, 30, (SELECT course_id FROM course WHERE course_num = 231), (SELECT term_id FROM term WHERE term_name = 'Winter')),
    (2, 40, (SELECT course_id FROM course WHERE course_num = 231), (SELECT term_id FROM term WHERE term_name = 'Winter')),
    (1, 25, (SELECT course_id FROM course WHERE course_num = 213), (SELECT term_id FROM term WHERE term_name = 'Winter'));
    
INSERT INTO enrollment (section_id, person_id, role_id) VALUES
	((SELECT section_id FROM section WHERE section_num = 1 AND course_id = 
		(SELECT course_id FROM course WHERE course_num = 251) AND term_id = 
        (SELECT term_id FROM term WHERE term_name = 'Fall')),
	 (SELECT person_id FROM person WHERE f_name = 'Brady' AND l_name = 'Meyer'),
     (SELECT role_id FROM role WHERE role = 'Teacher')),
     
	((SELECT section_id FROM section WHERE section_num = 1 AND course_id = 
		(SELECT course_id FROM course WHERE course_num = 231) AND term_id = 
        (SELECT term_id FROM term WHERE term_name = 'Fall')),
	 (SELECT person_id FROM person WHERE f_name = 'Andy' AND l_name = 'Kipner'),
     (SELECT role_id FROM role WHERE role = 'Teacher')),
     
     ((SELECT section_id FROM section WHERE section_num = 2 AND course_id = 
		(SELECT course_id FROM course WHERE course_num = 231) AND term_id = 
        (SELECT term_id FROM term WHERE term_name = 'Fall')),
	 (SELECT person_id FROM person WHERE f_name = 'Andy' AND l_name = 'Kipner'),
     (SELECT role_id FROM role WHERE role = 'Teacher')),
     
     ((SELECT section_id FROM section WHERE section_num = 1 AND course_id = 
		(SELECT course_id FROM course WHERE course_num = 113) AND term_id = 
        (SELECT term_id FROM term WHERE term_name = 'Fall')),
	 (SELECT person_id FROM person WHERE f_name = 'Lucy' AND l_name = 'Fuller'),
     (SELECT role_id FROM role WHERE role = 'Teacher')),
     
     ((SELECT section_id FROM section WHERE section_num = 1 AND course_id = 
		(SELECT course_id FROM course WHERE course_num = 213) AND term_id = 
        (SELECT term_id FROM term WHERE term_name = 'Fall')),
	 (SELECT person_id FROM person WHERE f_name = 'Adam' AND l_name = 'Woods'),
     (SELECT role_id FROM role WHERE role = 'Teacher')),
     
     ((SELECT section_id FROM section WHERE section_num = 2 AND course_id = 
		(SELECT course_id FROM course WHERE course_num = 251) AND term_id = 
        (SELECT term_id FROM term WHERE term_name = 'Winter')),
	 (SELECT person_id FROM person WHERE f_name = 'Brady' AND l_name = 'Meyer'),
     (SELECT role_id FROM role WHERE role = 'Teacher')),
     
     ((SELECT section_id FROM section WHERE section_num = 3 AND course_id = 
		(SELECT course_id FROM course WHERE course_num = 251)AND term_id = 
        (SELECT term_id FROM term WHERE term_name = 'Winter')),
	 (SELECT person_id FROM person WHERE f_name = 'Bryan' AND l_name = 'Drew'),
     (SELECT role_id FROM role WHERE role = 'Teacher')),
     
     ((SELECT section_id FROM section WHERE section_num = 1 AND course_id = 
		(SELECT course_id FROM course WHERE course_num = 231)AND term_id = 
        (SELECT term_id FROM term WHERE term_name = 'Winter')),
	 (SELECT person_id FROM person WHERE f_name = 'Andy' AND l_name = 'Kipner'),
     (SELECT role_id FROM role WHERE role = 'Teacher')),
     
     ((SELECT section_id FROM section WHERE section_num = 2 AND course_id = 
		(SELECT course_id FROM course WHERE course_num = 231)AND term_id = 
        (SELECT term_id FROM term WHERE term_name = 'Winter')),
	 (SELECT person_id FROM person WHERE f_name = 'Andy' AND l_name = 'Kipner'),
     (SELECT role_id FROM role WHERE role = 'Teacher')),
     
     ((SELECT section_id FROM section WHERE section_num = 1 AND course_id = 
		(SELECT course_id FROM course WHERE course_num = 213)AND term_id = 
        (SELECT term_id FROM term WHERE term_name = 'Winter')),
	 (SELECT person_id FROM person WHERE f_name = 'Adam' AND l_name = 'Woods'),
     (SELECT role_id FROM role WHERE role = 'Teacher'));