-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema university
-- -----------------------------------------------------
DROP SCHEMA IF EXISTS `university` ;

-- -----------------------------------------------------
-- Schema university
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `university` DEFAULT CHARACTER SET utf8 ;
USE `university` ;

-- -----------------------------------------------------
-- Table `university`.`department`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`department` ;

CREATE TABLE IF NOT EXISTS `university`.`department` (
  `department_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `department_name` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`department_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`degree`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`degree` ;

CREATE TABLE IF NOT EXISTS `university`.`degree` (
  `degree_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `degree_name` VARCHAR(45) NOT NULL,
  `department_id` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`degree_id`),
  INDEX `fk_degree_department1_idx` (`department_id` ASC) VISIBLE,
  CONSTRAINT `fk_degree_department1`
    FOREIGN KEY (`department_id`)
    REFERENCES `university`.`department` (`department_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`course`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`course` ;

CREATE TABLE IF NOT EXISTS `university`.`course` (
  `course_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `course_title` VARCHAR(45) NOT NULL,
  `credit_amount` INT NOT NULL,
  `course_num` INT NOT NULL,
  `course_code` VARCHAR(10) NOT NULL,
  `degree_id` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`course_id`),
  INDEX `fk_course_degree1_idx` (`degree_id` ASC) VISIBLE,
  CONSTRAINT `fk_course_degree1`
    FOREIGN KEY (`degree_id`)
    REFERENCES `university`.`degree` (`degree_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`person`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`person` ;

CREATE TABLE IF NOT EXISTS `university`.`person` (
  `person_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `first_name` VARCHAR(45) NOT NULL,
  `last_name` VARCHAR(45) NOT NULL,
  `gender` VARCHAR(1) NULL,
  `city` VARCHAR(45) NULL,
  `state` CHAR(2) NULL,
  `date` DATE NULL,
  PRIMARY KEY (`person_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`term`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`term` ;

CREATE TABLE IF NOT EXISTS `university`.`term` (
  `term_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `term_season` VARCHAR(45) NOT NULL,
  `year` INT NOT NULL,
  PRIMARY KEY (`term_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`section`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`section` ;

CREATE TABLE IF NOT EXISTS `university`.`section` (
  `section_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `section_num` INT NOT NULL,
  `capacity` INT NOT NULL,
  `term_id` INT UNSIGNED NOT NULL,
  `course_id` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`section_id`),
  INDEX `fk_section_term1_idx` (`term_id` ASC) VISIBLE,
  INDEX `fk_section_course1_idx` (`course_id` ASC) VISIBLE,
  CONSTRAINT `fk_section_term1`
    FOREIGN KEY (`term_id`)
    REFERENCES `university`.`term` (`term_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_section_course1`
    FOREIGN KEY (`course_id`)
    REFERENCES `university`.`course` (`course_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`role`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`role` ;

CREATE TABLE IF NOT EXISTS `university`.`role` (
  `role_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `role_type` VARCHAR(45) NULL,
  PRIMARY KEY (`role_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`enrollment`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`enrollment` ;

CREATE TABLE IF NOT EXISTS `university`.`enrollment` (
  `section_id` INT UNSIGNED NOT NULL,
  `person_id` INT UNSIGNED NOT NULL,
  `role_id` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`section_id`, `person_id`),
  INDEX `fk_section_person_person1_idx` (`person_id` ASC) VISIBLE,
  INDEX `fk_section_person_section1_idx` (`section_id` ASC) VISIBLE,
  INDEX `fk_section_person_role1_idx` (`role_id` ASC) VISIBLE,
  CONSTRAINT `fk_section_person_section1`
    FOREIGN KEY (`section_id`)
    REFERENCES `university`.`section` (`section_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_section_person_person1`
    FOREIGN KEY (`person_id`)
    REFERENCES `university`.`person` (`person_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_section_person_role1`
    FOREIGN KEY (`role_id`)
    REFERENCES `university`.`role` (`role_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;

USE university;

INSERT INTO person (first_name, last_name, gender, city, state, date) VALUE 
('Marshal', 'Spence', 'M', 'Garland', 'TX', '2000-06-23'), ('Maria', 'Clark', 'F', 'Akron', 'OH', '2002-01-25'),
('Tracy', 'Woodward', 'F', 'Newark', 'NJ', '2002-10-04'), ('Erick', 'Woodward', 'M', 'Newark', 'NJ', '1998-08-05'),
('Lillie', 'Summers', 'F', 'Reno', 'NV', '1999-11-05'), ('Nellie', 'Marquez', 'F', 'Atlanta', 'GA', '2001-06-25'),
('Allen', 'Stokes', 'M', 'Bozemen', 'MT', '2004-09-16'), ('Josh', 'Rollins', 'M', 'Decatur', 'TN', '1998-11-28'),
('Isabel', 'Meyers', 'F', 'Rexburg', 'ID', '2003-05-15'), ('Kerri', 'Shah', 'F', 'Mesa', 'AZ', '2003-04-05');

INSERT INTO person (first_name, last_name) VALUE 
('Brady', 'Meyer'), ('Andy', 'Kipner'), ('Lucy', 'Fuller'), ('Adam', 'Woods'), 
('Bryan', 'Drew');

INSERT INTO role (role_type) VALUE 
('Teacher'), ('Teacher Aide'), ('Student');

INSERT INTO department (department_name) VALUE
('Computer Science and Engineering'), ('Mathematics'), ('Music');

INSERT INTO term (term_season, year) VALUE 
('Fall', '2024'), ('Winter', '2025');

INSERT INTO degree (degree_name, department_id) VALUE
('Computer Science', 1), ('Web Design and Development', 1), ('Data Science', 2), ('Organ Performance', 3);

INSERT INTO course (course_title, credit_amount, course_num, course_code, degree_id) VALUE 
('Parallelism and Concurrency', 3, 251, 'CSE', 1), 
('Web Frontend Development I', 2, 231, 'WDD', 2),
('Calculus II', 3, 113, 'MATH', 3),
('Musicianship 4', 3, 213, 'MUSIC', 4);

INSERT INTO section (section_num, capacity, term_id, course_id) VALUE
(1, 35, 1, 1), (1, 30, 1, 2), (2, 30, 1, 2), (1, 45, 1, 3), (1, 25, 1, 4), (2, 35, 2, 1),
(3, 35, 2, 1), (1, 30, 2, 2), (2, 40, 2, 2), (1, 25, 2, 4);

INSERT INTO enrollment (section_id, person_id, role_id) VALUE 
(1, 11, 1), (6, 11, 1), (2,12, 1), (3, 12,1), (8, 12, 1), (9, 12, 1), (4, 13, 1), (5, 14, 1), (10, 14, 1), (7, 15, 1),
(1, 1, 3), (3, 1, 3), (4, 2, 3), (4, 3, 3), (5, 4, 3), (4, 5, 3), (5, 5, 2), (7, 6, 3), (6, 7, 3),
(9, 7, 2), (10, 7, 3), (9, 8, 3), (9, 9, 3), (6, 10, 3);













