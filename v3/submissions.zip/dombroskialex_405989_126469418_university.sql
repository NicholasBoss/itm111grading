-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema university
-- -----------------------------------------------------
DROP SCHEMA IF EXISTS `university` ;

-- -----------------------------------------------------
-- Schema university
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `university` DEFAULT CHARACTER SET utf8 ;
USE `university` ;

-- -----------------------------------------------------
-- Table `university`.`city`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`city` ;

CREATE TABLE IF NOT EXISTS `university`.`city` (
  `city_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `city_name` VARCHAR(35) NOT NULL,
  `state_abbr` CHAR(2) NOT NULL,
  PRIMARY KEY (`city_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`person`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`person` ;

CREATE TABLE IF NOT EXISTS `university`.`person` (
  `person_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `fname` VARCHAR(25) NOT NULL,
  `lname` VARCHAR(25) NOT NULL,
  `gender` CHAR(1),
  `birthdate` DATE,
  `city_id` INT UNSIGNED,
  PRIMARY KEY (`person_id`),
  INDEX `fk_person_City_idx` (`city_id` ASC) VISIBLE,
  CONSTRAINT `fk_person_City`
    FOREIGN KEY (`city_id`)
    REFERENCES `university`.`city` (`city_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`department`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`department` ;

CREATE TABLE IF NOT EXISTS `university`.`department` (
  `department_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `department_name` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`department_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`degree`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`degree` ;

CREATE TABLE IF NOT EXISTS `university`.`degree` (
  `degree_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `degree_name` VARCHAR(45) NOT NULL,
  `department_id` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`degree_id`),
  INDEX `fk_degree_department1_idx` (`department_id` ASC) VISIBLE,
  CONSTRAINT `fk_degree_department1`
    FOREIGN KEY (`department_id`)
    REFERENCES `university`.`department` (`department_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`course`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`course` ;

CREATE TABLE IF NOT EXISTS `university`.`course` (
  `course_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `course_name` VARCHAR(45) NOT NULL,
  `credits` TINYINT NOT NULL,
  `course_num` SMALLINT NOT NULL,
  `course_code` VARCHAR(6) NOT NULL,
  `degree_id` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`course_id`),
  INDEX `fk_course_degree1_idx` (`degree_id` ASC) VISIBLE,
  CONSTRAINT `fk_course_degree1`
    FOREIGN KEY (`degree_id`)
    REFERENCES `university`.`degree` (`degree_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`term`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`term` ;

CREATE TABLE IF NOT EXISTS `university`.`term` (
  `term_id` TINYINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `term_name` VARCHAR(8) NOT NULL,
  `term_year` YEAR NOT NULL,
  PRIMARY KEY (`term_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`section`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`section` ;

CREATE TABLE IF NOT EXISTS `university`.`section` (
  `section_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `course_id` INT UNSIGNED NOT NULL,
  `section_number` TINYINT NOT NULL,
  `term_id` TINYINT UNSIGNED NOT NULL,
  `capacity` TINYINT NOT NULL,
  PRIMARY KEY (`section_id`),
  INDEX `fk_section_course1_idx` (`course_id` ASC) VISIBLE,
  INDEX `fk_section_term1_idx` (`term_id` ASC) VISIBLE,
  CONSTRAINT `fk_section_course1`
    FOREIGN KEY (`course_id`)
    REFERENCES `university`.`course` (`course_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_section_term1`
    FOREIGN KEY (`term_id`)
    REFERENCES `university`.`term` (`term_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`role`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`role` ;

CREATE TABLE IF NOT EXISTS `university`.`role` (
  `role_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `role_title` VARCHAR(10) NOT NULL,
  PRIMARY KEY (`role_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`section_person`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`section_person` ;

CREATE TABLE IF NOT EXISTS `university`.`section_person` (
  `person_id` INT UNSIGNED NOT NULL,
  `section_id` INT UNSIGNED NOT NULL,
  `role_id` INT UNSIGNED NOT NULL,
  INDEX `fk_person_has_Roll_Roll1_idx` (`role_id` ASC) VISIBLE,
  INDEX `fk_person_has_Roll_person1_idx` (`person_id` ASC) VISIBLE,
  PRIMARY KEY (`person_id`, `section_id`),
  INDEX `fk_section_person_section1_idx` (`section_id` ASC) VISIBLE,
  CONSTRAINT `fk_person_has_Roll_person1`
    FOREIGN KEY (`person_id`)
    REFERENCES `university`.`person` (`person_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_person_has_Roll_Roll1`
    FOREIGN KEY (`role_id`)
    REFERENCES `university`.`role` (`role_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_section_person_section1`
    FOREIGN KEY (`section_id`)
    REFERENCES `university`.`section` (`section_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;


-- -----------------------------------------------------
-- Inserts
-- -----------------------------------------------------

USE university;

INSERT INTO city (city_name, state_abbr) VALUES
	('Garland', 'TX'),
    ('Akron', 'OH'),
    ('Newark', 'NJ'),
    ('Reno', 'NV'),
    ('Atlanta', 'GA'),
    ('Bozeman', 'MT'),
    ('Decatur', 'TN'),
    ('Rexburg', 'ID'),
    ('Mesa', 'AZ');

INSERT INTO person (fname, lname, gender, birthdate, city_id) VALUES
	('Marshall', 'Spence', 'M', '2000-06-23', 1),
	('Maria', 'Clark', 'F', '2002-01-25', 2),
	('Tracy', 'Woodward', 'F', '2002-10-04', 3),
	('Erick', 'Woodward', 'M', '1998-08-05', 3),
	('Lillie', 'Summers', 'F', '1999-11-05', 4),
	('Nellie', 'Marquez', 'F', '2001-06-25', 5),
	('Allen', 'Stokes', 'M', '2004-09-16', 6),
	('Josh', 'Rollins', 'M', '1998-11-28', 7),
	('Isabel', 'Meyers', 'F', '2003-05-15', 8),
	('Kerri', 'Shah', 'F', '2003-04-05', 9);
    
INSERT INTO person (fname, lname) VALUES
	('Brady', 'Meyer'),
	('Andy', 'Kipner'),
	('Lucy', 'Fuller'),
	('Adam', 'Woods'),
	('Bryan', 'Drew');

INSERT INTO department (department_name) VALUES
	('Computer Science and Engineering'),
	('Mathematics'),
	('Music');

INSERT INTO degree (degree_name, department_id) VALUES
	('Computer Science', 1),
	('Web Design and Development', 1),
	('Data Science', 2),
	('Organ Performance', 3);
    
INSERT INTO course (course_name, degree_id, course_code, course_num, credits) VALUES
	('Parallelism and Concurrency', 1, 'CSE', 251, 3),
	('Web Frontend Development I', 2, 'WDD', 231, 2),
	('Calculus II', 3, 'MATH', 113, 3),
	('Musicianship 4', 3, 'MUSIC', 213, 3);

INSERT INTO role (role_title) VALUES
	('TA'),
	('Teacher'),
	('Student');
    
INSERT INTO term (term_name, term_year) VALUES
	('Fall', 2024),
	('Winter', 2025);
    
INSERT INTO section (course_id, section_number, term_id, capacity) VALUES
	(1, 1, 1, 35),
    (2, 1, 1, 30),
    (2, 2, 1, 30),
    (3, 1, 1, 45),
    (4, 1, 1, 25),
    (1, 2, 2, 35),
    (1, 3, 2, 35),
    (2, 1, 2, 30),
    (2, 2, 2, 40),
    (4, 1, 2, 25);

-- Insert Teachers into Sections
INSERT INTO section_person (person_id, section_id, role_id) VALUES
	(11, 1, 2),
	(11, 6, 2),
	(12, 2, 2),
	(12, 3, 2),
	(12, 8, 2),
	(12, 9, 2),
	(13, 4, 2),
	(14, 5, 2),
	(14, 10, 2),
	(15, 7, 2);

-- Insert Students and TAs into sections
INSERT INTO section_person (person_id, section_id, role_id) VALUES
	(1, 1, 3),
	(1, 2, 3),
	(2, 4, 3),
	(3, 4, 3),
	(4, 5, 3),
	(5, 4, 3),
	(5, 5, 1),
	(6, 7, 3),
	(7, 6, 3),
	(7, 8, 1),
	(7, 10, 3),
	(8, 9, 3),
	(9, 9, 3),
	(10, 6, 3);

-- -----------------------------------------------------
-- Test Queries
-- -----------------------------------------------------

-- Allen Stokes's Classes
SELECT p.fname, p.lname, r.role_title, CONCAT(c.course_code, ' ', c.course_num) AS course, s.section_number, t.term_name, t.term_year 
FROM person AS p
JOIN section_person AS sp ON sp.person_id = p.person_id
JOIN role AS r ON sp.role_id = r.role_id
JOIN section AS s ON s.section_id = sp.section_id
JOIN course AS c ON s.course_id = c.course_id
JOIN term AS t ON t.term_id = s.term_id
WHERE p.fname = 'Allen' AND p.lname = 'Stokes'
ORDER BY r.role_title ASC;

-- Students taking CSE 251
SELECT p.lname, p.fname, c.course_name, s.section_number, t.term_name, t.term_year 
FROM person AS p
JOIN section_person AS sp ON sp.person_id = p.person_id
JOIN role AS r ON sp.role_id = r.role_id
JOIN section AS s ON s.section_id = sp.section_id
JOIN course AS c ON s.course_id = c.course_id
JOIN term AS t ON t.term_id = s.term_id
WHERE c.course_name = 'Parallelism and Concurrency' AND r.role_title = 'student'
ORDER BY t.term_name ASC, s.section_number DESC;

-- Number of Students in Musicianship 4 in Winter or Fall
SELECT COUNT(*) AS 'Students taking Musicianship 4'
FROM role AS r
JOIN section_person AS sp ON r.role_id = sp.role_id
JOIN section AS s ON sp.section_id = s.section_id
JOIN course AS c ON s.course_id = c.course_id
WHERE c.course_name = 'Musicianship 4' AND r.role_title = 'student';