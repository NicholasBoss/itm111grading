-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema university
-- -----------------------------------------------------
DROP SCHEMA IF EXISTS `university` ;

-- -----------------------------------------------------
-- Schema university
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `university` DEFAULT CHARACTER SET utf8 ;
USE `university` ;

-- -----------------------------------------------------
-- Table `university`.`dept`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`dept` ;

CREATE TABLE IF NOT EXISTS `university`.`dept` (
  `dept_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `dept_name` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`dept_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`degree`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`degree` ;

CREATE TABLE IF NOT EXISTS `university`.`degree` (
  `degree_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `degree` VARCHAR(45) NOT NULL,
  `course_code` VARCHAR(45) NOT NULL,
  `dept_id` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`degree_id`),
  INDEX `fk_degree_dept1_idx` (`dept_id` ASC) VISIBLE,
  CONSTRAINT `fk_degree_dept1`
    FOREIGN KEY (`dept_id`)
    REFERENCES `university`.`dept` (`dept_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`location`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`location` ;

CREATE TABLE IF NOT EXISTS `university`.`location` (
  `location_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `state` VARCHAR(45) NOT NULL,
  `city` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`location_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`person`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`person` ;

CREATE TABLE IF NOT EXISTS `university`.`person` (
  `person_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `first_name` VARCHAR(45) NOT NULL,
  `last_name` VARCHAR(45) NOT NULL,
  `gender` VARCHAR(1) NULL,
  `dob` DATE NULL,
  `location_id` INT UNSIGNED NULL,
  PRIMARY KEY (`person_id`),
  INDEX `fk_person_location_idx` (`location_id` ASC) VISIBLE,
  CONSTRAINT `fk_person_location`
    FOREIGN KEY (`location_id`)
    REFERENCES `university`.`location` (`location_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`course`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`course` ;

CREATE TABLE IF NOT EXISTS `university`.`course` (
  `course_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `course_title` VARCHAR(45) NOT NULL,
  `course_num` VARCHAR(45) NOT NULL,
  `credits` INT UNSIGNED NOT NULL,
  `degree_id` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`course_id`),
  INDEX `fk_course_degree1_idx` (`degree_id` ASC) VISIBLE,
  CONSTRAINT `fk_course_degree1`
    FOREIGN KEY (`degree_id`)
    REFERENCES `university`.`degree` (`degree_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`semester`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`semester` ;

CREATE TABLE IF NOT EXISTS `university`.`semester` (
  `semester_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `term` VARCHAR(45) NOT NULL,
  `year` YEAR NOT NULL,
  PRIMARY KEY (`semester_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`section`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`section` ;

CREATE TABLE IF NOT EXISTS `university`.`section` (
  `section_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `section` INT UNSIGNED NOT NULL,
  `course_id` INT UNSIGNED NOT NULL,
  `capacity` INT UNSIGNED NOT NULL,
  `semester_id` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`section_id`),
  INDEX `fk_section_course1_idx` (`course_id` ASC) VISIBLE,
  INDEX `fk_section_semester1_idx` (`semester_id` ASC) VISIBLE,
  CONSTRAINT `fk_section_course1`
    FOREIGN KEY (`course_id`)
    REFERENCES `university`.`course` (`course_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_section_semester1`
    FOREIGN KEY (`semester_id`)
    REFERENCES `university`.`semester` (`semester_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`enrollment`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`enrollment` ;

CREATE TABLE IF NOT EXISTS `university`.`enrollment` (
  `enrollment_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `person_id` INT UNSIGNED NOT NULL,
  `section_id` INT UNSIGNED NOT NULL,
  `role` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`enrollment_id`),
  INDEX `fk_person_section_section1_idx` (`section_id` ASC) VISIBLE,
  INDEX `fk_person_section_person1_idx` (`person_id` ASC) VISIBLE,
  CONSTRAINT `fk_person_section_person1`
    FOREIGN KEY (`person_id`)
    REFERENCES `university`.`person` (`person_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_person_section_section1`
    FOREIGN KEY (`section_id`)
    REFERENCES `university`.`section` (`section_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;

USE university;

INSERT INTO location (city, state) VALUES
	('Garland', 'TX'), -- id 1
    ('Akron', 'OH'), -- id 2
    ('Newark', 'NJ'), -- id 3
    ('Reno', 'NV'), -- id 4
    ('Atlanta', 'GA'), -- id 5
    ('Bozeman', 'MT'), -- id 6
    ('Decatur', 'TN'), -- id 7
    ('Rexburg', 'ID'), -- id 8
    ('Mesa', 'AZ'); -- id 9
SELECT * FROM location;

INSERT INTO person (first_name, last_name, gender, dob, location_id) VALUES
	('Marshall', 'Spence', 'M', '2000-06-23', 1), -- Garland TX (id 1)
    ('Maria', 'Clark', 'F', '2002-01-25', 2), -- Akron OH (id 2)
    ('Tracy', 'Woodward', 'F', '2002-10-04', 3), -- Newark NJ (id 3)
	('Erick', 'Woodward', 'W', '1998-08-05', 3), -- Newark NJ (id 3)
    ('Lillie', 'Summers', 'F', '1999-11-05', 4), -- Reno NC (id 4)
	('Nellie', 'Marquez', 'F', '2001-06-25', 5), -- Atlanta GA (id 5)
    ('Allen', 'Stokes', 'M', '2004-09-16', 6), -- Bozeman MT (id 6)
    ('Josh', 'Rollins', 'M', '1998-11-28', 7), -- Decatur TN (id 7)
    ('Isabel', 'Meyers', 'F', '2003-05-15', 8), -- Rexburg ID (id 8)
    ('Kerri', 'Shah', 'F', '2003-04-05', 9), -- Mesa AZ (id 9)
    ('Brady', 'Meyer', Null, Null, Null),
    ('Andy', 'Kipner', Null, Null, Null),
    ('Lucy', 'Fuller', Null, Null, Null),
    ('Adam', 'Woods', Null, Null, Null),
    ('Bryan', 'Drew', Null, Null, Null);
SELECT * FROM person;

INSERT INTO dept (dept_name) VALUES
	('Computer Science and Engineering'), -- id 1
    ('Mathematics'), -- id 2
    ('Music'); -- id 3
SELECT * FROM dept;

INSERT INTO degree (degree, course_code, dept_id) VALUES
	('Computer Science', 'CSE', 1), -- Computer Science (id 1)
    ('Web Design and Development', 'WDD', 1), -- Computer Science (id 1)
    ('Data Science', 'MATH', 2), -- Mathematics (id 2)
    ('Organ Performance', 'MUSIC', 3); -- Music (id 3)
SELECT * FROM degree;

INSERT INTO course (course_title, course_num, credits, degree_id) VALUES
	('Parallelism and Concurrency', 251, 3, 1), -- Computer Science (id 1)
    ('Web Frontend Development l', 231, 2, 1), -- Computer Science (id 1)
    ('Calculus ll', 113, 3, 2), -- Mathematics (id 2)
    ('Musicianship 4', 213, 3, 3); -- Organ Performance (id 3)
SELECT * FROM course;

INSERT INTO semester (year, term) VALUE
	(2024, 'Fall'), -- id 1
    (2025, 'Winter'); -- id 2
SELECT * FROM semester;

INSERT INTO section (semester_id, section, capacity, course_id) VALUES
	(1, 1, 35, 1), -- Fall 24 (id 1), Parallelism CSE (id 1)		1
    (1, 1, 30, 2), -- Fall 24 (id 1), Web Frontend WDD (id 2)		2
    (1, 2, 30, 2), -- Fall 24 (id 1), Web Frontend WDD (id 2)		3
    (1, 1, 45, 3), -- Fall 24 (id 1), Calculus MATH (id 3)			4
    (1, 1, 25, 4), -- Fall 24 (id 1), Musicianship MUSIC 213(id 4)	5
    (2, 2, 35, 1), -- Winter 25 (id 2), Parallelism CSE (id 1)		6
    (2, 3, 35, 1), -- Winter 25 (id 2), Parallelism CSE (id 1)		7
    (2, 1, 30, 2), -- Winter 25 (id 2), Web Frontend WDD (id 2)		8
    (2, 2, 30, 2), -- Winter 25 (id 2), Web Frontend WDD (id 2)		9
    (2, 1, 25, 4); -- Winter 25 (id 2), Musicianship MUSIC (id 4)	10
SELECT * FROM section;

INSERT INTO enrollment (person_id, section_id, role) VALUES
	(11, 1, 'Teacher'), -- Brady(id 11), F24 CSE section 1 (id 1)
    (11, 6, 'Teacher'), -- Brady(id 11), W25 CSE section 2 (id 6)
    (12, 2, 'Teacher'), -- Andy(id 12), F24 WDD section 1 (id 2)
    (12, 3, 'Teacher'), -- Andy(id 12), F24 WDD section 2 (id 3)
    (12, 8, 'Teacher'), -- Andy(id 12), W25 WDD section 1 (id 8)
	(12, 9, 'Teacher'), -- Andy(id 12), W25 WDD section 2 (id 9)
    (13, 4, 'Teacher'), -- Lucy(id 13), F24 MATH section 1 (id 4)
    (14, 5, 'Teacher'), -- Adam(id 14), F24 MUSIC section 1 (id 5)
    (14, 10, 'Teacher'), -- Adam(id 14), W24 MUSIC section 1 (id 10)
    (15, 7, 'Teacher'), -- Bryan(id 15), W25 CSE section 3 (id 7)
    (1, 1, 'Student'), -- Marshall(id 1), F24 CSE section 1 (id 1)
    (1, 9, 'Student'), -- Marshall(id 1), W25 WDD section 2 (id 9)
    (2, 4, 'Student'), -- Maria(id 2), F24 MATH section 1 (id 4)
    (3, 4, 'Student'), -- Tracy(id 3), F24 MATH section 1 (id 4)
    (4, 5, 'Student'), -- Erick(id 4), F24 MUSIC section 1 (id 5)
    (5, 4, 'Student'), -- Lillie(id 5), F24 MATH section 1 (id 4)
    (5, 5, 'TA'), -- Lillie(id 5), F24 MUSIC section 1 (id 5)
    (6, 7, 'Student'), -- Nellie(id 6), W25 CSE section 3 (id 7)
    (7, 6, 'Student'), -- Allen(id 7), W25 CSE section 2 (id 6)
    (7, 8, 'TA'), -- Allen(id 7), W25 WDD section 1 (id 8)
    (7, 10, 'Student'), -- Allen(id 7), W25 MUSIC section 1 (id 10)
    (8, 9, 'Student'), -- Josh(id 8), W25 WDD section 2 (id 9)
    (9, 9, 'Student'), -- Isabel(id 9), W25 WDD section 2 (id 9)
    (10, 6, 'Student'); -- Kerri(id 10), W25 CSE section 2 (id 6)
SELECT * FROM enrollment;

