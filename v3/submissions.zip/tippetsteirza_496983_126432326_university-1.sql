-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema university
-- -----------------------------------------------------
DROP SCHEMA IF EXISTS `university` ;

-- -----------------------------------------------------
-- Schema university
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `university` DEFAULT CHARACTER SET utf8 ;
USE `university` ;

-- -----------------------------------------------------
-- Table `university`.`person`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`person` ;

CREATE TABLE IF NOT EXISTS `university`.`person` (
  `person_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `fname` VARCHAR(15) NOT NULL,
  `lname` VARCHAR(45) NOT NULL,
  `gender` VARCHAR(1) NULL,
  `city` VARCHAR(45) NULL,
  `state` CHAR(2) NULL,
  `birthdate` DATE NULL,
  PRIMARY KEY (`person_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`department`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`department` ;

CREATE TABLE IF NOT EXISTS `university`.`department` (
  `department_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `department_name` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`department_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`degree`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`degree` ;

CREATE TABLE IF NOT EXISTS `university`.`degree` (
  `degree_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `degree_name` VARCHAR(45) NOT NULL,
  `department_id` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`degree_id`),
  INDEX `fk_degree_department_idx` (`department_id` ASC) VISIBLE,
  CONSTRAINT `fk_degree_department`
    FOREIGN KEY (`department_id`)
    REFERENCES `university`.`department` (`department_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`course`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`course` ;

CREATE TABLE IF NOT EXISTS `university`.`course` (
  `course_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `course_code` VARCHAR(5) NOT NULL,
  `course_num` VARCHAR(3) NOT NULL,
  `course_title` VARCHAR(45) NOT NULL,
  `credits` DECIMAL(2,1) NOT NULL,
  `degree_id` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`course_id`),
  INDEX `fk_course_degree1_idx` (`degree_id` ASC) VISIBLE,
  CONSTRAINT `fk_course_degree1`
    FOREIGN KEY (`degree_id`)
    REFERENCES `university`.`degree` (`degree_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`section`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`section` ;

CREATE TABLE IF NOT EXISTS `university`.`section` (
  `section_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `section_num` INT NOT NULL,
  `term` VARCHAR(6) NOT NULL,
  `capacity` INT(2) NOT NULL,
  `year` YEAR NOT NULL,
  `course_id` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`section_id`),
  INDEX `fk_section_course1_idx` (`course_id` ASC) VISIBLE,
  CONSTRAINT `fk_section_course1`
    FOREIGN KEY (`course_id`)
    REFERENCES `university`.`course` (`course_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`role`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`role` ;

CREATE TABLE IF NOT EXISTS `university`.`role` (
  `role_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `role_type` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`role_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`enrollment`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`enrollment` ;

CREATE TABLE IF NOT EXISTS `university`.`enrollment` (
  `person_id` INT UNSIGNED NOT NULL,
  `section_id` INT UNSIGNED NOT NULL,
  `role_id` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`person_id`, `section_id`),
  INDEX `fk_person_section_section1_idx` (`section_id` ASC) VISIBLE,
  INDEX `fk_person_section_person1_idx` (`person_id` ASC) VISIBLE,
  INDEX `fk_person_section_role1_idx` (`role_id` ASC) VISIBLE,
  CONSTRAINT `fk_person_section_person1`
    FOREIGN KEY (`person_id`)
    REFERENCES `university`.`person` (`person_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_person_section_section1`
    FOREIGN KEY (`section_id`)
    REFERENCES `university`.`section` (`section_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_person_section_role1`
    FOREIGN KEY (`role_id`)
    REFERENCES `university`.`role` (`role_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;

USE university;

INSERT INTO department(department_name) VALUE
('Computer Science and Engineering'),
('Mathematics'),
('Music');


INSERT INTO degree(degree_name, department_id) VALUE
('Computer Science', 1),
('Web Design and Development', 1),
('Data Science', 2),
('Organ Performance', 3);


INSERT INTO course(course_code, course_num, course_title, credits, degree_id) VALUE
('CSE','251','Parallelism and Concurrency', 3, 1),
('WDD','231','Web Frontend Development I', 2, 2),
('MATH','113','Calculus II', 3 , 3),
('MUSIC','213','Musicianship 4', 3, 4);


INSERT INTO section(section_num, term, capacity, year, course_id) VALUE
('1', 'Fall', 35 , 2024, 1),
('1', 'Fall', 30 ,2024 , 2),
('2', 'Fall', 30, 2024, 2),
('1', 'Fall', 45, 2024 , 3),
('1', 'Fall', 25, 2024 , 4),
('2', 'Winter', 35, 2025, 1),
('3', 'Winter', 35, 2025, 1),
('1', 'Winter', 30, 2025, 2),
('2', 'Winter', 40, 2025, 2),
('1', 'Winter', 25, 2025, 4);


INSERT INTO person(fname, lname, gender, city, state, birthdate) VALUE
('Marshall','Spence','M','Garland','TX', '2000-06-23'),
('Maria','Clark','F','Akron','OH', '2002-01-25'),
('Tracy','Woodward','F','Newark','NJ', '2002-10-04'),
('Erick','Woodward','M','Newark','NJ', '1998-08-05'),
('Lillie','Summers','F','Reno','NV', '1999-11-05'),
('Nellie','Marquez','F','Atlanta','GA', '2001-06-25'),
('Allen','Stokes','M','Bozeman','MT', '2004-09-16'),
('Josh','Rollins','M','Decatur','TN', '1998-11-28'),
('Isabel','Meyers','F','Rexburg','ID', '2003-05-15'),
('Kerri','Shah','F','Mesa','AZ', '2003-04-05'),
('Brady','Meyer', NULL, NULL, NULL, NULL),
('Andy','Kipner', NULL, NULL, NULL, NULL),
('Lucy','Fuller', NULL, NULL, NULL, NULL),
('Adam','Woods', NULL, NULL, NULL, NULL),
('Bryan','Drew',NULL, NULL, NULL, NULL);


INSERT INTO role(role_type) value
('Teacher'),
('Student'),
('TA');


INSERT INTO enrollment(person_id, section_id, role_id) VALUE
(11 ,1 ,1 ),
(11 ,6 ,1),
(12 ,2 ,1 ),
(12 ,3 ,1 ),
(12 ,8 ,1 ),
(12 ,9 ,1 ),
(13 ,4 ,1 ),
(14 ,5 ,1 ),
(14 ,10 ,1 ),
(15 ,7 ,1 ),
(1 , 1 ,2 ),
(1 , 3,2 ),
(2 , 4,2 ),
(3 , 4,2 ),
(4 , 5,2 ),
(5 , 4,2 ),
(5 , 5,3 ),
(6 , 7,2 ),
(7 , 6,2 ),
(7 , 8,3 ),
(7 , 10,2 ),
(8 , 9,2 ),
(9 , 9,2 ),
(10 , 6 ,2 );
SELECT * FROM  enrollment;
