-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema university
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema university
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `university` DEFAULT CHARACTER SET utf8 ;
USE `university` ;

USE university;
-- -----------------------------------------------------
-- Table `university`.`person`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `university`.`person` (
  `person_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `fname` VARCHAR(45) NOT NULL,
  `lname` VARCHAR(45) NOT NULL,
  `gender` CHAR(1) NULL,
  `city` VARCHAR(45) NULL,
  `state` CHAR(2) NULL,
  `birthdate` DATE NULL,
  PRIMARY KEY (`person_id`))
ENGINE = InnoDB;

SELECT * FROM person;

INSERT INTO person (person_id, fname, lname, gender, city, state, birthdate, department_id)
VALUES (DEFAULT, "Marshall", "Spence", "M", "Garland", "TX", "2000-06-23",NULL),
(DEFAULT, "Maria", "Clark", "F", "Akron", "OH", "2002-01-25",NULL),
(DEFAULT, "Tracy", "Woodward", "F", "Newark", "NJ", "2002-10-04",NULL),
(DEFAULT, "Erick", "Woodward", "M", "Newark", "NJ", "1998-08-05",NULL),
(DEFAULT, "Lillie", "Summers", "F", "Reno", "NV", "1999-11-05", "3"),
(DEFAULT, "Nellie", "Marquez", "F", "Atlanta", "GA", "2001-06-25",NULL),
(DEFAULT, "Allen", "Stokes", "M", "Bozeman", "MT", "2004-09-16", "1"),
(DEFAULT, "Josh", "Rollins", "M", "Decatur", "TN", "1998-11-28",NULL ),
(DEFAULT, "Isabel", "Meyers", "F", "Rexburg", "ID", "2003-05-15", NULL),
(DEFAULT, "Kerri", "Shah", "F", "Mesa", "AZ", "2003-04-05", NULL);

INSERT INTO person (person_id, fname, lname, department_id)
VALUES (DEFAULT, "Brady", "Meyer", "1"),
(DEFAULT, "Andy", "Kipner", "1"),
(DEFAULT, "Lucy", "Fuller", "2"),
(DEFAULT, "Adam", "Woods", "3"),
(DEFAULT, "Bryan", "Drew", "1");

UPDATE person
SET department_id = 1
WHERE fname = "Marshall";

UPDATE person
SET department_id = 2
WHERE fname = "Maria";



-- -----------------------------------------------------
-- Table `university`.`department`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `university`.`department` (
  `department_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `department_name` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`department_id`))
ENGINE = InnoDB;

INSERT INTO department (department_id, department_name)
VALUES (DEFAULT, "Computer Science and Engineering"),
(DEFAULT, "Mathematics"),
(DEFAULT, "Music");


-- -----------------------------------------------------
-- Table `university`.`degree`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `university`.`degree` (
  `degree_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `degree_name` VARCHAR(45) NOT NULL,
  `department_id` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`degree_id`),
  INDEX `fk_degree_department1_idx` (`department_id` ASC) VISIBLE,
  CONSTRAINT `fk_degree_department1`
    FOREIGN KEY (`department_id`)
    REFERENCES `university`.`department` (`department_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;

INSERT INTO degree (degree_id, degree_name, department_id)
VALUES (DEFAULT, "Computer Science", "1"),
(DEFAULT, "Web Design and Development", "1"),
(DEFAULT, "Data Science", "2"),
(DEFAULT, "Organ Performance", "3");


-- -----------------------------------------------------
-- Table `university`.`course`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `university`.`course` (
  `course_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `course_code` CHAR(5) NOT NULL,
  `course_num` TINYINT NOT NULL,
  `course_title` VARCHAR(45) NOT NULL,
  `credits` TINYINT NOT NULL,
  PRIMARY KEY (`course_id`))
ENGINE = InnoDB;

INSERT INTO course (course_id, course_code, course_num, course_title, credits)
VALUES (DEFAULT, "CSE", "251", "Parallelism and Concurrency", "3"),
(DEFAULT, "WDD", "231", "Web Frontend Development 1", "2"),
(DEFAULT, "MATH", "113", "Calculus 2", "3"),
(DEFAULT, "MUSIC", "213", "Musicianship 4", "3");

SELECT course_id
FROM course


-- -----------------------------------------------------
-- Table `university`.`degree_course`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `university`.`degree_course` (
  `degree_course_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `course_id` INT UNSIGNED NOT NULL,
  `degree_id` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`degree_course_id`),
  INDEX `fk_degree_course_course1_idx` (`course_id` ASC) VISIBLE,
  INDEX `fk_degree_course_degree1_idx` (`degree_id` ASC) VISIBLE,
  CONSTRAINT `fk_degree_course_course1`
    FOREIGN KEY (`course_id`)
    REFERENCES `university`.`course` (`course_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_degree_course_degree1`
    FOREIGN KEY (`degree_id`)
    REFERENCES `university`.`degree` (`degree_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;

INSERT INTO degree_course (degree_course_id, course_id, degree_id)
VALUES (DEFAULT, "1", "1"),
(DEFAULT, "2", "2"),
(DEFAULT, "3", "3"),
(DEFAULT, "4", "4");


SELECT person_id, fname, lname
FROM person
WHERE department_id IS NOT NULL;

-- -----------------------------------------------------
-- Table `university`.`section_capacity_teacher`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `university`.`section_capacity_teacher` (
  `section_capacity_id` INT UNSIGNED NOT NULL,
  `teacher_id` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`section_capacity_id`, `teacher_id`))
ENGINE = InnoDB;




-- -----------------------------------------------------
-- Table `university`.`term`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `university`.`term` (
  `term_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `term_name` VARCHAR(10) NOT NULL,
  `term_year` YEAR NOT NULL,
  PRIMARY KEY (`term_id`))
ENGINE = InnoDB;

INSERT INTO term (term_id, term_name, term_year)
VALUES (DEFAULT, "Fall", "2024"),
(DEFAULT, "Winter", "2025");



-- -----------------------------------------------------
-- Table `university`.`section`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `university`.`section` (
  `section_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `section_no` TINYINT NOT NULL,
  `course_id` INT UNSIGNED NOT NULL,
  `term_id` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`section_id`),
  INDEX `fk_section_course1_idx` (`course_id` ASC) VISIBLE,
  INDEX `fk_section_term1_idx` (`term_id` ASC) VISIBLE,
  CONSTRAINT `fk_section_course1`
    FOREIGN KEY (`course_id`)
    REFERENCES `university`.`course` (`course_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_section_term1`
    FOREIGN KEY (`term_id`)
    REFERENCES `university`.`term` (`term_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;

SELECT * FROM section;
INSERT INTO section (section_id, section_no, course_id, term_id)
VALUES (DEFAULT, "1", "1", "1"),
(DEFAULT, "1", "2", "1"),
(DEFAULT, "2", "2", "1"),
(DEFAULT, "1", "3", "1"),
(DEFAULT, "1", "4", "1"),
(DEFAULT, "2", "1", "2"),
(DEFAULT, "3", "1", "2"),
(DEFAULT, "1", "2", "2"),
(DEFAULT, "2", "2", "2"),
(DEFAULT, "1", "4", "2");

-- -----------------------------------------------------
-- Table `university`.`person_type`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `university`.`person_type` (
  `person_type_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `person_type` ENUM("TA", "Student", "Teacher") NOT NULL,
  PRIMARY KEY (`person_type_id`))
ENGINE = InnoDB;

INSERT INTO person_type (person_type_id, person_type)
VALUES (DEFAULT, "TA"),
(DEFAULT, "Student"),
(DEFAULT, "Teacher");



-- -----------------------------------------------------
-- Table `university`.`person_section`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `university`.`person_section` (
  `person_section_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `person_id` INT UNSIGNED NOT NULL,
  `person_type_id` INT UNSIGNED NOT NULL,
  `section_id` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`person_section_id`),
  INDEX `fk_person_section_person1_idx` (`person_id` ASC) VISIBLE,
  INDEX `fk_person_section_person_type1_idx` (`person_type_id` ASC) VISIBLE,
  INDEX `fk_person_section_section1_idx` (`section_id` ASC) VISIBLE,
  CONSTRAINT `fk_person_section_person1`
    FOREIGN KEY (`person_id`)
    REFERENCES `university`.`person` (`person_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_person_section_person_type1`
    FOREIGN KEY (`person_type_id`)
    REFERENCES `university`.`person_type` (`person_type_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_person_section_section1`
    FOREIGN KEY (`section_id`)
    REFERENCES `university`.`section` (`section_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;

---- TA, Student, Teacher

---- 1 - CSE, 2 - WDD, 3 - MATH, 4 - MUSIC

---- 1 - Fall 2024, 2 - Winter 2025

SELECT * FROM section;


INSERT INTO person_section (person_section_id, person_id, person_type_id, section_id)
VALUES (DEFAULT, "1", "2", "1"),
(DEFAULT, "1", "2", "3"),
(DEFAULT, "2", "2", "4"),
(DEFAULT, "3", "2", "4"),
(DEFAULT, "4", "2", "5"),
(DEFAULT, "5", "2", "4"),
(DEFAULT, "5", "1", "5"),
(DEFAULT, "6", "2", "7"),
(DEFAULT, "7", "2", "6"),
(DEFAULT, "7", "1", "8"),
(DEFAULT, "7", "2", "10"),
(DEFAULT, "8", "2", "9"),
(DEFAULT, "9", "2", "9"),
(DEFAULT, "10", "2", "6"),
(DEFAULT, "11", "3", "1"),
(DEFAULT, "11", "3", "6"),
(DEFAULT, "12", "3", "2"),
(DEFAULT, "12", "3", "3"),
(DEFAULT, "12", "3", "8"),
(DEFAULT, "12", "3", "9"),
(DEFAULT, "13", "3", "4"),
(DEFAULT, "14", "3", "5"),
(DEFAULT, "14", "3", "10"),
(DEFAULT, "15", "3", "7");


select * from person_section;




SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
