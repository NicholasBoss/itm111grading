-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema university
-- -----------------------------------------------------
DROP SCHEMA IF EXISTS `university` ;

-- -----------------------------------------------------
-- Schema university
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `university` ;
USE `university` ;

-- -----------------------------------------------------
-- Table `university`.`department`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`department` ;

CREATE TABLE IF NOT EXISTS `university`.`department` (
  `department_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `department_name` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`department_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`degree`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`degree` ;

CREATE TABLE IF NOT EXISTS `university`.`degree` (
  `degree_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `degree_title` VARCHAR(45) NOT NULL,
  `department_id` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`degree_id`),
  INDEX `fk_degree_department1_idx` (`department_id` ASC) VISIBLE,
  CONSTRAINT `fk_degree_department1`
    FOREIGN KEY (`department_id`)
    REFERENCES `university`.`department` (`department_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`course`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`course` ;

CREATE TABLE IF NOT EXISTS `university`.`course` (
  `course_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `credits` INT NOT NULL,
  `course_title` VARCHAR(45) NOT NULL,
  `course_num` INT NOT NULL,
  `course_code` VARCHAR(45) NOT NULL,
  `degree_id` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`course_id`),
  INDEX `fk_course_degree1_idx` (`degree_id` ASC) VISIBLE,
  CONSTRAINT `fk_course_degree1`
    FOREIGN KEY (`degree_id`)
    REFERENCES `university`.`degree` (`degree_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`person`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`person` ;

CREATE TABLE IF NOT EXISTS `university`.`person` (
  `person_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `first_name` VARCHAR(45) NOT NULL,
  `last_name` VARCHAR(45) NOT NULL,
  `gender` CHAR(1) NULL,
  `city` VARCHAR(45) NULL,
  `state` CHAR(2) NULL,
  `birthdate` DATE NULL,
  PRIMARY KEY (`person_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`role`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`role` ;

CREATE TABLE IF NOT EXISTS `university`.`role` (
  `role_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `role_title` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`role_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`term`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`term` ;

CREATE TABLE IF NOT EXISTS `university`.`term` (
  `term_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `year` YEAR NOT NULL,
  `semester` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`term_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`section`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`section` ;

CREATE TABLE IF NOT EXISTS `university`.`section` (
  `section_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `section_number` INT NOT NULL,
  `capacity` INT NOT NULL,
  `course_id` INT UNSIGNED NOT NULL,
  `term_id` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`section_id`),
  INDEX `fk_section_course1_idx` (`course_id` ASC) VISIBLE,
  INDEX `fk_section_term1_idx` (`term_id` ASC) VISIBLE,
  CONSTRAINT `fk_section_course1`
    FOREIGN KEY (`course_id`)
    REFERENCES `university`.`course` (`course_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_section_term1`
    FOREIGN KEY (`term_id`)
    REFERENCES `university`.`term` (`term_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`enrollment`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`enrollment` ;

CREATE TABLE IF NOT EXISTS `university`.`enrollment` (
  `enrollment_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `person_id` INT UNSIGNED NOT NULL,
  `role_id` INT UNSIGNED NOT NULL,
  `section_id` INT UNSIGNED NOT NULL,
  INDEX `fk_people_role_role1_idx` (`role_id` ASC) VISIBLE,
  INDEX `fk_people_role_people_idx` (`person_id` ASC) VISIBLE,
  INDEX `fk_people_role_section1_idx` (`section_id` ASC) VISIBLE,
  PRIMARY KEY (`enrollment_id`),
  CONSTRAINT `fk_people_role_people`
    FOREIGN KEY (`person_id`)
    REFERENCES `university`.`person` (`person_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_people_role_role1`
    FOREIGN KEY (`role_id`)
    REFERENCES `university`.`role` (`role_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_people_role_section1`
    FOREIGN KEY (`section_id`)
    REFERENCES `university`.`section` (`section_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;


USE university;

INSERT INTO person (first_name, last_name, gender, city, state, birthdate) VALUES 
('Marshall', 'Spence', 'M', 'Garland', 'TX', '2000-06-23'),
('Maria', 'Clark', 'F', 'Akron', 'OH', '2002-01-25'),
('Tracy', 'Woodward', 'F', 'Newrdk', 'NJ', '2002-10-04'),
('Erick', 'Woodward', 'M', 'Newark', 'NJ', '1998-08-05'),
('Lillie', 'Summers', 'F', 'Reno', 'NV', '1999-11-05'),
('Nellie', 'Marquez', 'F', 'Atlanta', 'GA', '2001-06-25'),
('Allen', 'Stokes', 'M', 'Bozeman', 'MT', '2004-09-16'),
('Josh', 'Rollins', 'M', 'Decatur', 'TN', '1998-11-28'),
('Isabel', 'Meyers', 'F', 'Rexburg', 'ID', '2003-05-15'),
('Kerri', 'Shah', 'F', 'Mesa', 'AZ', '2003-04-05');

INSERT INTO person (first_name, last_name) VALUES
('Brady', 'Meyer'),
('Andy', 'Kipner'),
('Lucy', 'Fuller'),
('Adam', 'Woods'),
('Bryan', 'Drew');

INSERT INTO role (role_title)
VALUES ('Teacher'),
('Student'),
('TA');

INSERT INTO department (department_name)
VALUES ('Computer Science and Engineering'),
('Mathematics'),
('Music');

INSERT INTO degree (degree_title, department_id)
VALUES ('Computer Science', 1),
('Web Design and Development', 1),
('Data Science', 2),
('Organ Performance', 3);

INSERT INTO course (credits, course_title, course_num, course_code, degree_id)
VALUES ('3', 'Parallelism and Concurrency', '251', 'CSE', 1),
('2', 'Web Frontend Development I', '231', 'WDD', 2),
('3', 'Calculus II', '113', 'MATH', 3),
('3', 'Musicianship 4', '213', 'MUSIC', 4);

INSERT INTO term (year, semester)
VALUES ('2024', 'Fall'),
('2025', 'Winter');

INSERT INTO section (section_number, capacity, course_id, term_id)
VALUES ('1', '35', 1, 1),
('1', '30', 2, 1),
('2', '30', 2, 1),
('1', '45', 3, 1),
('1', '25', 4, 1),
('2', '35', 1, 2),
('3', '35', 1, 2),
('1', '30', 2, 2),
('2', '40', 2, 2),
('1', '25', 4, 2);

INSERT INTO enrollment (person_id, role_id, section_id)
VALUES (11, 1, 1),
(11, 1, 6),
(12, 1, 2),
(12, 1, 3),
(12, 1, 8),
(12, 1, 9),
(13, 1, 4),
(14, 1, 5),
(14, 1, 10),
(15, 1, 7),
(1, 2, 1),
(1, 2, 3),
(2, 2, 4),
(3, 2, 4),
(4, 2, 5),
(5, 2, 4),
(5, 3, 5),
(6, 2, 7),
(7, 2, 6),
(7, 3, 8),
(7, 2, 10),
(8, 2, 9),
(9, 2, 9),
(10, 2, 7);
