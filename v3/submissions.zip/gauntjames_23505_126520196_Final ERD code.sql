-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema university
-- -----------------------------------------------------
DROP SCHEMA IF EXISTS `university` ;

-- -----------------------------------------------------
-- Schema university
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `university` DEFAULT CHARACTER SET utf8 ;
USE `university` ;

-- -----------------------------------------------------
-- Table `university`.`department`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`department` ;

CREATE TABLE IF NOT EXISTS `university`.`department` (
  `department_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `department_name` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`department_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`degree`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`degree` ;

CREATE TABLE IF NOT EXISTS `university`.`degree` (
  `degree_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `degree_name` VARCHAR(45) NOT NULL,
  `department_id` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`degree_id`),
  INDEX `fk_degree_department1_idx` (`department_id` ASC) VISIBLE,
  CONSTRAINT `fk_degree_department1`
    FOREIGN KEY (`department_id`)
    REFERENCES `university`.`department` (`department_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`course`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`course` ;

CREATE TABLE IF NOT EXISTS `university`.`course` (
  `course_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `course_name` VARCHAR(45) NOT NULL,
  `course_code` VARCHAR(7) NOT NULL,
  `course_number` SMALLINT UNSIGNED NOT NULL,
  `credits` INT UNSIGNED NOT NULL,
  `degree_id` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`course_id`),
  INDEX `fk_course_degree1_idx` (`degree_id` ASC) VISIBLE,
  CONSTRAINT `fk_course_degree1`
    FOREIGN KEY (`degree_id`)
    REFERENCES `university`.`degree` (`degree_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`term`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`term` ;

CREATE TABLE IF NOT EXISTS `university`.`term` (
  `term_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `semester` VARCHAR(45) NOT NULL,
  `year` YEAR NOT NULL,
  PRIMARY KEY (`term_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`section`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`section` ;

CREATE TABLE IF NOT EXISTS `university`.`section` (
  `section_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `section_num` TINYINT UNSIGNED NOT NULL,
  `course_id` INT UNSIGNED NOT NULL,
  `term_id` INT UNSIGNED NOT NULL,
  `section_capacity` TINYINT(2) UNSIGNED NOT NULL,
  PRIMARY KEY (`section_id`),
  INDEX `fk_section_course1_idx` (`course_id` ASC) VISIBLE,
  INDEX `fk_section_term1_idx` (`term_id` ASC) VISIBLE,
  CONSTRAINT `fk_section_course1`
    FOREIGN KEY (`course_id`)
    REFERENCES `university`.`course` (`course_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_section_term1`
    FOREIGN KEY (`term_id`)
    REFERENCES `university`.`term` (`term_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`person`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`person` ;

CREATE TABLE IF NOT EXISTS `university`.`person` (
  `person_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `fname` VARCHAR(45) NOT NULL,
  `lname` VARCHAR(45) NOT NULL,
  `birthdate` DATE NULL,
  `gender` VARCHAR(1) NOT NULL,
  `city` VARCHAR(45) NULL,
  `state` VARCHAR(2) NULL,
  PRIMARY KEY (`person_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`role`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`role` ;

CREATE TABLE IF NOT EXISTS `university`.`role` (
  `role_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `role_name` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`role_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`enrollment`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`enrollment` ;

CREATE TABLE IF NOT EXISTS `university`.`enrollment` (
  `enrollment_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `section_id` INT UNSIGNED NOT NULL,
  `person_id` INT UNSIGNED NOT NULL,
  `role_id` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`enrollment_id`),
  INDEX `fk_enrollment_section1_idx` (`section_id` ASC) VISIBLE,
  INDEX `fk_enrollment_person1_idx` (`person_id` ASC) VISIBLE,
  INDEX `fk_enrollment_role1_idx` (`role_id` ASC) VISIBLE,
  CONSTRAINT `fk_enrollment_section1`
    FOREIGN KEY (`section_id`)
    REFERENCES `university`.`section` (`section_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_enrollment_person1`
    FOREIGN KEY (`person_id`)
    REFERENCES `university`.`person` (`person_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_enrollment_role1`
    FOREIGN KEY (`role_id`)
    REFERENCES `university`.`role` (`role_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;

INSERT INTO term (semester, year)
VALUES ('Fall', 2024),
('Winter', 2025);

INSERT INTO role (role_name)
VALUES ('Professor'),
('Student'),
('TA');

INSERT INTO person (fname, lname, birthdate, gender, city, state)
VALUES ('Brady', 'Meyer', NULL, 'M', NULL, NULL),
('Andy', 'Kipner', NULL, 'M', NULL, NULL),
('Lucy', 'Fuller', NULL, 'F', NULL, NULL),
('Adam', 'Woods', NULL, 'M', NULL, NULL),
('Brian', 'Drew', NULL, 'M', NULL, NULL),
('Marshall', 'Spence', '2000-06-23', 'M', 'Garland', 'TX'),
('Maria', 'Clark', '2002-01-25', 'F', 'Akron', 'OH'),
('Tracy', 'Woodward', '2002-10-04', 'F', 'Newark', 'NJ'),
('Erick', 'Woodward', '1998-08-05', 'M', 'Newark', 'NJ'),
('Lillie', 'Summers', '1999-11-05', 'F', 'Reno', 'NV'),
('Nellie', 'Marquez', '2001-06-25', 'F', 'Atlanta', 'GA'),
('Allen', 'Stokes', '2004-09-16', 'M', 'Bozeman', 'MT'),
('Josh', 'Rollins', '1998-11-28', 'M', 'Decatur', 'TN'),
('Isabel', 'Meyers', '2003-05-15', 'F', 'Rexburg', 'ID'),
('Kerri', 'Shah', '2003-04-05', 'F', 'Mesa', 'AZ');

INSERT INTO department (department_name)
VALUES ('Computer Science and Engineering'),
('Mathematics'),
('Music');

INSERT INTO degree (degree_name, department_id)
VALUES ('Computer Science', 1),
('Web Design and Development', 1),
('Data Science', 2),
('Organ Performance', 3);

INSERT INTO course (course_name, course_code, course_number, credits, degree_id)
VALUES ('Parallelism and Concurrency', 'CSE', 251, 3 ,1 ),
('Web Frontend Development I', 'WDD', 231, 2, 2),
('Calculus II', 'MATH', 113, 3, 3),
('Musicianship 4', 'MUSIC', 213, 3, 4);

INSERT INTO section (section_num, section_capacity, course_id, term_id)
VALUES (1, 35, 1, 1), -- 1
(1, 30, 2, 1),-- 2
(2, 30, 2, 1),-- 3
(1, 45, 3, 1),-- 4
(1, 25, 4, 1),-- 5
(2, 35, 1, 2),-- 6
(3, 35, 1, 2),-- 7
(1, 30, 2, 2),-- 1
(2, 40, 2, 2),-- 9
(1, 25, 4, 2);-- 10

INSERT INTO enrollment (person_id, section_id, role_id)
VALUES (1, 1, 1),
(1, 6, 1),
(2, 2, 1),
(2, 3, 1),
(2, 8, 1),
(2, 9, 1),
(3, 4, 1),
(4, 5, 1),
(4, 10, 1),
(5, 7, 1),
(6, 1, 1),
(6, 3, 1),
(7, 4, 1),
(8, 4, 1),
(9, 5, 1),
(10, 4, 1),
(10, 5, 1),
(11, 7, 1),
(12, 6, 1),
(12, 8, 1),
(12, 10, 1),
(13, 9, 1),
(14, 9, 1),
(15, 6, 1);

