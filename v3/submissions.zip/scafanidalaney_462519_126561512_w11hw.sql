-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema university
-- -----------------------------------------------------
DROP SCHEMA IF EXISTS `university` ;

-- -----------------------------------------------------
-- Schema university
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `university` DEFAULT CHARACTER SET utf8 ;
USE `university` ;

-- -----------------------------------------------------
-- Table `university`.`department`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`department` ;

CREATE TABLE IF NOT EXISTS `university`.`department` (
  `department_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `department_name` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`department_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`degree`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`degree` ;

CREATE TABLE IF NOT EXISTS `university`.`degree` (
  `degree_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `degree_name` VARCHAR(45) NOT NULL,
  `department_id` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`degree_id`),
  INDEX `fk_degree_department1_idx` (`department_id` ASC) VISIBLE,
  CONSTRAINT `fk_degree_department1`
    FOREIGN KEY (`department_id`)
    REFERENCES `university`.`department` (`department_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`course`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`course` ;

CREATE TABLE IF NOT EXISTS `university`.`course` (
  `course_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `course_code` VARCHAR(5) NOT NULL,
  `course_num` INT NOT NULL,
  `course_title` VARCHAR(45) NOT NULL,
  `credits` INT NOT NULL,
  `degree_id` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`course_id`),
  INDEX `fk_course_degree_idx` (`degree_id` ASC) VISIBLE,
  CONSTRAINT `fk_course_degree`
    FOREIGN KEY (`degree_id`)
    REFERENCES `university`.`degree` (`degree_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`person`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`person` ;

CREATE TABLE IF NOT EXISTS `university`.`person` (
  `person_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `first_name` VARCHAR(45) NOT NULL,
  `last_name` VARCHAR(45) NOT NULL,
  `gender` CHAR(1) NULL,
  `city` VARCHAR(20) NULL,
  `state` CHAR(2) NULL,
  `birthdate` DATE NULL,
  PRIMARY KEY (`person_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`class_date`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`class_date` ;

CREATE TABLE IF NOT EXISTS `university`.`class_date` (
  `class_date_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `semester` VARCHAR(6) NOT NULL,
  `year` YEAR NOT NULL,
  PRIMARY KEY (`class_date_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`section`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`section` ;

CREATE TABLE IF NOT EXISTS `university`.`section` (
  `section_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `section_capacity` INT NOT NULL,
  `section_num` INT NOT NULL,
  `course_id` INT UNSIGNED NOT NULL,
  `class_date_id` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`section_id`),
  INDEX `fk_section_course1_idx` (`course_id` ASC) VISIBLE,
  INDEX `fk_section_class_date1_idx` (`class_date_id` ASC) VISIBLE,
  CONSTRAINT `fk_section_course1`
    FOREIGN KEY (`course_id`)
    REFERENCES `university`.`course` (`course_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_section_class_date1`
    FOREIGN KEY (`class_date_id`)
    REFERENCES `university`.`class_date` (`class_date_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`person_role`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`person_role` ;

CREATE TABLE IF NOT EXISTS `university`.`person_role` (
  `role_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `role_type` VARCHAR(20) NOT NULL,
  PRIMARY KEY (`role_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`enrollment`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`enrollment` ;

CREATE TABLE IF NOT EXISTS `university`.`enrollment` (
  `enrollment_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `person_id` INT UNSIGNED NOT NULL,
  `section_id` INT UNSIGNED NOT NULL,
  `role_id` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`enrollment_id`),
  INDEX `fk_enrollment_section1_idx` (`section_id` ASC) VISIBLE,
  INDEX `fk_enrollment_person_role1_idx` (`role_id` ASC) VISIBLE,
  INDEX `fk_enrollment_person1_idx` (`person_id` ASC) VISIBLE,
  CONSTRAINT `fk_enrollment_section1`
    FOREIGN KEY (`section_id`)
    REFERENCES `university`.`section` (`section_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_enrollment_person_role1`
    FOREIGN KEY (`role_id`)
    REFERENCES `university`.`person_role` (`role_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_enrollment_person1`
    FOREIGN KEY (`person_id`)
    REFERENCES `university`.`person` (`person_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;


USE university;
INSERT into department (department_name) 
VALUES      ('Computer Science and Engineering')
, 			('Mathematics')
,			('Music');

INSERT INTO degree (degree_name, department_id) 
VALUES		('Computer Science', (SELECT department_id FROM department WHERE department_name = 'Computer Science and Engineering'))
,			('Web Design and Development', (SELECT department_id FROM department WHERE department_name = 'Computer Science and Engineering'))
,			('Data Science', (SELECT department_id FROM department WHERE department_name = 'Mathematics'))
,			('Organ Performance', (SELECT department_id FROM department WHERE department_name = 'Music')); 

INSERT INTO course (course_id, course_title, course_code, course_num, credits, degree_id)
VALUES (1, 'Parellelism and Concurrency' , 'CSE', 251, 3, (SELECT degree_id FROM degree WHERE degree_name = 'Computer Science'))
,	   (2, 'Web Frontend Development I', 'WDD', 231, 2, (SELECT degree_id FROM degree WHERE degree_name = 'Web Design and Development'))
,	   (3, 'Calculus II', 'MATH', 113, 3, (SELECT degree_id FROM degree WHERE degree_name = 'Data Science'))
,	   (4, 'Musicianship 4', 'MUSIC', 213, 3, (SELECT degree_id FROM degree WHERE degree_name = 'Organ Performance')); 

INSERT INTO class_date (semester, year)
VALUES  ('Fall', 2024)
,		('Winter', 2025);

INSERT INTO person (first_name, last_name, gender, city, state, birthdate)
VALUES  ('Marshall', 'Spence', 'M', 'Garland', 'TX', '2000-06-23')
,		('Maria', 'Clark', 'F', 'Arkron', 'OH', '2002-01-25')
,		('Tracy', 'Woodward', 'F', 'Newark', 'NJ', '2002-10-04')
,		('Erick', 'Woodward', 'M', 'Newark', 'NJ', '1998-08-05')
,		('Lillie', 'Summers', 'F', 'Reno', 'NV', '1999-11-05')
,		('Nellie', 'Marquez', 'F', 'Atlanta', 'GA', '2001-06-25')
,		('Allen', 'Stokes', 'M', 'Bozeman', 'MT', '2004-09-16')
,		('Josh', 'Rollins', 'M', 'Decatur', 'TN', '1998-11-28')
,		('Isabel', 'Meyers', 'F', 'Rexburg', 'ID', '2003-05-15')
,		('Kerri', 'Shah', 'F', 'Mesa', 'AZ', '2003-04-05');

INSERT INTO person (first_name, last_name)
VALUES ('Brady', 'Meyer')
,		('Andy', 'Kipner')
,		('Lucy', 'Fuller')
,		('Adam', 'Woods')
,		('Bryan', 'Drew');


INSERT INTO person_role (role_id, role_type)
VALUES  (1, 'Student')
,		(2, 'Teacher')
,		(3, 'TA'); 

INSERT INTO section (section_num, section_capacity, course_id, class_date_id) 
VALUES 	(1, 35, ((SELECT course_id FROM course WHERE CONCAT(course_code, ' ', course_num) = 'CSE 251')),
				(SELECT class_date_id FROM class_date WHERE CONCAT(semester, ' ', year) = 'Fall 2024'))
,		(1, 30, ((SELECT course_id FROM course WHERE CONCAT(course_code, ' ', course_num) = 'WDD 231')),
				(SELECT class_date_id FROM class_date WHERE CONCAT(semester, ' ', year) = 'Fall 2024'))
,		(2, 30, ((SELECT course_id FROM course WHERE CONCAT(course_code, ' ', course_num) = 'WDD 231')),
				(SELECT class_date_id FROM class_date WHERE CONCAT(semester, ' ', year) = 'Fall 2024'))
,		(1, 45, ((SELECT course_id FROM course WHERE CONCAT(course_code, ' ', course_num) = 'MATH 113')),
				(SELECT class_date_id FROM class_date WHERE CONCAT(semester, ' ', year) = 'Fall 2024'))
,		(1, 25, ((SELECT course_id FROM course WHERE CONCAT(course_code, ' ', course_num) = 'MUSIC 213')),
				(SELECT class_date_id FROM class_date WHERE CONCAT(semester, ' ', year) = 'Fall 2024'))
,		(2, 35, ((SELECT course_id FROM course WHERE CONCAT(course_code, ' ', course_num) = 'CSE 251')),
				(SELECT class_date_id FROM class_date WHERE CONCAT(semester, ' ', year) = 'Winter 2025'))
,		(3, 35, ((SELECT course_id FROM course WHERE CONCAT(course_code, ' ', course_num) = 'CSE 251')),
				(SELECT class_date_id FROM class_date WHERE CONCAT(semester, ' ', year) = 'Winter 2025'))
,		(1, 30, ((SELECT course_id FROM course WHERE CONCAT(course_code, ' ', course_num) = 'WDD 231')),
				(SELECT class_date_id FROM class_date WHERE CONCAT(semester, ' ', year) = 'Winter 2025'))
,		(2, 40, ((SELECT course_id FROM course WHERE CONCAT(course_code, ' ', course_num) = 'WDD 231')),
				(SELECT class_date_id FROM class_date WHERE CONCAT(semester, ' ', year) = 'Winter 2025'))
,		(1, 25, ((SELECT course_id FROM course WHERE CONCAT(course_code, ' ', course_num) = 'MUSIC 213')),
				(SELECT class_date_id FROM class_date WHERE CONCAT(semester, ' ', year) = 'Winter 2025')); 

INSERT INTO enrollment (person_id, section_id, role_id)
VALUES
-- Brady Meyer Classes (2)
((SELECT person_id
  FROM person
  WHERE CONCAT(first_name, ' ', last_name) = 'Brady Meyer')
, (SELECT section_id
   FROM section s
   INNER JOIN course c ON s.course_id = c.course_id
   INNER JOIN class_date cd ON s.class_date_id = cd.class_date_id
   WHERE CONCAT(semester, ' ', year) = 'Fall 2024'
   AND   CONCAT(course_code, ' ', course_num) = 'CSE 251'
   AND   section_num = 1)
, (SELECT role_id FROM person_role WHERE role_type = 'Teacher')
),
((SELECT person_id
  FROM person
  WHERE CONCAT(first_name, ' ', last_name) = 'Brady Meyer')
, (SELECT section_id
   FROM section s 
   INNER JOIN course c ON s.course_id = c.course_id
   INNER JOIN class_date cd ON s.class_date_id = cd.class_date_id
   WHERE CONCAT(semester, ' ', year) = 'Winter 2025'
   AND   CONCAT(course_code, ' ', course_num) = 'CSE 251'
   AND   section_num = 2)
, (SELECT role_id FROM person_role WHERE role_type = 'Teacher')
),

-- Andy Kipner Classes (4)
((SELECT person_id
  FROM person
  WHERE CONCAT(first_name, ' ', last_name) = 'Andy Kipner')
, (SELECT section_id
   FROM section s 
   INNER JOIN course c ON s.course_id = c.course_id
   INNER JOIN class_date cd ON s.class_date_id = cd.class_date_id
   WHERE CONCAT(semester, ' ', year) = 'Fall 2024'
   AND   CONCAT(course_code, ' ', course_num) = 'WDD 231'
   AND   section_num = 1)
, (SELECT role_id FROM person_role WHERE role_type = 'Teacher')
),

((SELECT person_id
  FROM person
  WHERE CONCAT(first_name, ' ', last_name) = 'Andy Kipner')
, (SELECT section_id
   FROM section s 
   INNER JOIN course c ON s.course_id = c.course_id
   INNER JOIN class_date cd ON s.class_date_id = cd.class_date_id
   WHERE CONCAT(semester, ' ', year) = 'Fall 2024'
   AND   CONCAT(course_code, ' ', course_num) = 'WDD 231'
   AND   section_num = 2)
, (SELECT role_id FROM person_role WHERE role_type = 'Teacher')
),

((SELECT person_id
  FROM person
  WHERE CONCAT(first_name, ' ', last_name) = 'Andy Kipner')
, (SELECT section_id
   FROM section s 
   INNER JOIN course c ON s.course_id = c.course_id
   INNER JOIN class_date cd ON s.class_date_id = cd.class_date_id
   WHERE CONCAT(semester, ' ', year) = 'Winter 2025'
   AND   CONCAT(course_code, ' ', course_num) = 'WDD 231'
   AND   section_num = 1)
, (SELECT role_id FROM person_role WHERE role_type = 'Teacher')
),

((SELECT person_id
  FROM person
  WHERE CONCAT(first_name, ' ', last_name) = 'Andy Kipner')
, (SELECT section_id
   FROM section s 
   INNER JOIN course c ON s.course_id = c.course_id
   INNER JOIN class_date cd ON s.class_date_id = cd.class_date_id
   WHERE CONCAT(semester, ' ', year) = 'Winter 2025'
   AND   CONCAT(course_code, ' ', course_num) = 'WDD 231'
   AND   section_num = 2)
, (SELECT role_id FROM person_role WHERE role_type = 'Teacher')
),

-- Lucy Fuller classes (1)
((SELECT person_id
  FROM person
  WHERE CONCAT(first_name, ' ', last_name) = 'Lucy Fuller')
, (SELECT section_id
   FROM section s 
   INNER JOIN course c ON s.course_id = c.course_id
   INNER JOIN class_date cd ON s.class_date_id = cd.class_date_id
   WHERE CONCAT(semester, ' ', year) = 'Fall 2024'
   AND   CONCAT(course_code, ' ', course_num) = 'MATH 113'
   AND   section_num = 1)
, (SELECT role_id FROM person_role WHERE role_type = 'Teacher')
),

-- Adam Woods classes (2) 
((SELECT person_id
  FROM person
  WHERE CONCAT(first_name, ' ', last_name) = 'Adam Woods')
, (SELECT section_id
   FROM section s 
   INNER JOIN course c ON s.course_id = c.course_id
   INNER JOIN class_date cd ON s.class_date_id = cd.class_date_id
   WHERE CONCAT(semester, ' ', year) = 'Fall 2024'
   AND   CONCAT(course_code, ' ', course_num) = 'MUSIC 213'
   AND   section_num = 1)
, (SELECT role_id FROM person_role WHERE role_type = 'Teacher')
),

((SELECT person_id
  FROM person
  WHERE CONCAT(first_name, ' ', last_name) = 'Adam Woods')
, (SELECT section_id
   FROM section s 
   INNER JOIN course c ON s.course_id = c.course_id
   INNER JOIN class_date cd ON s.class_date_id = cd.class_date_id
   WHERE CONCAT(semester, ' ', year) = 'WINTER 2025'
   AND   CONCAT(course_code, ' ', course_num) = 'MUSIC 213'
   AND   section_num = 1)
, (SELECT role_id FROM person_role WHERE role_type = 'Teacher')
),

-- Bryan Drew classes (1) 
((SELECT person_id
  FROM person
  WHERE CONCAT(first_name, ' ', last_name) = 'Bryan Drew')
, (SELECT section_id
   FROM section s 
   INNER JOIN course c ON s.course_id = c.course_id
   INNER JOIN class_date cd ON s.class_date_id = cd.class_date_id
   WHERE CONCAT(semester, ' ', year) = 'Winter 2025'
   AND   CONCAT(course_code, ' ', course_num) = 'CSE 251'
   AND   section_num = 3)
, (SELECT role_id FROM person_role WHERE role_type = 'Teacher')
),

-- students 
((SELECT person_id
  FROM person
  WHERE CONCAT(first_name, ' ', last_name) = 'Marshall Spence')
, (SELECT section_id
   FROM section s 
   INNER JOIN course c ON s.course_id = c.course_id
   INNER JOIN class_date cd ON s.class_date_id = cd.class_date_id
   WHERE CONCAT(semester, ' ', year) = 'Fall 2024'
   AND   CONCAT(course_code, ' ', course_num) = 'CSE 251'
   AND   section_num = 1)
, (SELECT role_id FROM person_role WHERE role_type = 'Student')
),

((SELECT person_id
  FROM person
  WHERE CONCAT(first_name, ' ', last_name) = 'Marshall Spence')
, (SELECT section_id
   FROM section s 
   INNER JOIN course c ON s.course_id = c.course_id
   INNER JOIN class_date cd ON s.class_date_id = cd.class_date_id
   WHERE CONCAT(semester, ' ', year) = 'Fall 2024'
   AND   CONCAT(course_code, ' ', course_num) = 'WDD 231'
   AND   section_num = 2)
, (SELECT role_id FROM person_role WHERE role_type = 'Student')
),

((SELECT person_id
  FROM person
  WHERE CONCAT(first_name, ' ', last_name) = 'Maria Clark')
, (SELECT section_id
   FROM section s 
   INNER JOIN course c ON s.course_id = c.course_id
   INNER JOIN class_date cd ON s.class_date_id = cd.class_date_id
   WHERE CONCAT(semester, ' ', year) = 'Fall 2024'
   AND   CONCAT(course_code, ' ', course_num) = 'MATH 113'
   AND   section_num = 1)
, (SELECT role_id FROM person_role WHERE role_type = 'Student')
),

((SELECT person_id
  FROM person
  WHERE CONCAT(first_name, ' ', last_name) = 'Tracy Woodward')
, (SELECT section_id
   FROM section s 
   INNER JOIN course c ON s.course_id = c.course_id
   INNER JOIN class_date cd ON s.class_date_id = cd.class_date_id
   WHERE CONCAT(semester, ' ', year) = 'Fall 2024'
   AND   CONCAT(course_code, ' ', course_num) = 'MATH 113'
   AND   section_num = 1)
, (SELECT role_id FROM person_role WHERE role_type = 'Student')
),

((SELECT person_id
  FROM person
  WHERE CONCAT(first_name, ' ', last_name) = 'Erick Woodward')
, (SELECT section_id
   FROM section s 
   INNER JOIN course c ON s.course_id = c.course_id
   INNER JOIN class_date cd ON s.class_date_id = cd.class_date_id
   WHERE CONCAT(semester, ' ', year) = 'Fall 2024'
   AND   CONCAT(course_code, ' ', course_num) = 'MUSIC 213'
   AND   section_num = 1)
, (SELECT role_id FROM person_role WHERE role_type = 'Student')
),

((SELECT person_id
  FROM person
  WHERE CONCAT(first_name, ' ', last_name) = 'Lillie Summers')
, (SELECT section_id
   FROM section s 
   INNER JOIN course c ON s.course_id = c.course_id
   INNER JOIN class_date cd ON s.class_date_id = cd.class_date_id
   WHERE CONCAT(semester, ' ', year) = 'Fall 2024'
   AND   CONCAT(course_code, ' ', course_num) = 'MATH 113'
   AND   section_num = 1)
, (SELECT role_id FROM person_role WHERE role_type = 'Student')
),

((SELECT person_id
  FROM person
  WHERE CONCAT(first_name, ' ', last_name) = 'Lillie Summers')
, (SELECT section_id
   FROM section s 
   INNER JOIN course c ON s.course_id = c.course_id
   INNER JOIN class_date cd ON s.class_date_id = cd.class_date_id
   WHERE CONCAT(semester, ' ', year) = 'Fall 2024'
   AND   CONCAT(course_code, ' ', course_num) = 'MUSIC 213'
   AND   section_num = 1)
, (SELECT role_id FROM person_role WHERE role_type = 'TA')
),

((SELECT person_id
  FROM person
  WHERE CONCAT(first_name, ' ', last_name) = 'Nellie Marquez')
, (SELECT section_id
   FROM section s 
   INNER JOIN course c ON s.course_id = c.course_id
   INNER JOIN class_date cd ON s.class_date_id = cd.class_date_id
   WHERE CONCAT(semester, ' ', year) = 'Winter 2025'
   AND   CONCAT(course_code, ' ', course_num) = 'CSE 251'
   AND   section_num = 3)
, (SELECT role_id FROM person_role WHERE role_type = 'Student')
),

((SELECT person_id
  FROM person
  WHERE CONCAT(first_name, ' ', last_name) = 'Allen Stokes')
, (SELECT section_id
   FROM section s 
   INNER JOIN course c ON s.course_id = c.course_id
   INNER JOIN class_date cd ON s.class_date_id = cd.class_date_id
   WHERE CONCAT(semester, ' ', year) = 'Winter 2025'
   AND   CONCAT(course_code, ' ', course_num) = 'CSE 251'
   AND   section_num = 2)
, (SELECT role_id FROM person_role WHERE role_type = 'Student')
),

((SELECT person_id
  FROM person
  WHERE CONCAT(first_name, ' ', last_name) = 'Allen Stokes')
, (SELECT section_id
   FROM section s 
   INNER JOIN course c ON s.course_id = c.course_id
   INNER JOIN class_date cd ON s.class_date_id = cd.class_date_id
   WHERE CONCAT(semester, ' ', year) = 'Winter 2025'
   AND   CONCAT(course_code, ' ', course_num) = 'WDD 231'
   AND   section_num = 1)
, (SELECT role_id FROM person_role WHERE role_type = 'TA')
),

((SELECT person_id
  FROM person
  WHERE CONCAT(first_name, ' ', last_name) = 'Allen Stokes')
, (SELECT section_id
   FROM section s 
   INNER JOIN course c ON s.course_id = c.course_id
   INNER JOIN class_date cd ON s.class_date_id = cd.class_date_id
   WHERE CONCAT(semester, ' ', year) = 'Winter 2025'
   AND   CONCAT(course_code, ' ', course_num) = 'MUSIC 213'
   AND   section_num = 1)
, (SELECT role_id FROM person_role WHERE role_type = 'Student')
),

((SELECT person_id
  FROM person
  WHERE CONCAT(first_name, ' ', last_name) = 'Josh Rollins')
, (SELECT section_id
   FROM section s 
   INNER JOIN course c ON s.course_id = c.course_id
   INNER JOIN class_date cd ON s.class_date_id = cd.class_date_id
   WHERE CONCAT(semester, ' ', year) = 'Winter 2025'
   AND   CONCAT(course_code, ' ', course_num) = 'WDD 231'
   AND   section_num = 2)
, (SELECT role_id FROM person_role WHERE role_type = 'Student')
),

((SELECT person_id
  FROM person
  WHERE CONCAT(first_name, ' ', last_name) = 'Isabel Meyers')
, (SELECT section_id
   FROM section s 
   INNER JOIN course c ON s.course_id = c.course_id
   INNER JOIN class_date cd ON s.class_date_id = cd.class_date_id
   WHERE CONCAT(semester, ' ', year) = 'Winter 2025'
   AND   CONCAT(course_code, ' ', course_num) = 'WDD 231'
   AND   section_num = 2)
, (SELECT role_id FROM person_role WHERE role_type = 'Student')
),

((SELECT person_id
  FROM person
  WHERE CONCAT(first_name, ' ', last_name) = 'Kerri Shah')
, (SELECT section_id
   FROM section s 
   INNER JOIN course c ON s.course_id = c.course_id
   INNER JOIN class_date cd ON s.class_date_id = cd.class_date_id
   WHERE CONCAT(semester, ' ', year) = 'Winter 2025'
   AND   CONCAT(course_code, ' ', course_num) = 'CSE 251'
   AND   section_num = 2)
, (SELECT role_id FROM person_role WHERE role_type = 'Student')
);