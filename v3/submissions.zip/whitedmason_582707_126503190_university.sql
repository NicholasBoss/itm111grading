-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema university
-- -----------------------------------------------------
DROP SCHEMA IF EXISTS `university` ;

-- -----------------------------------------------------
-- Schema university
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `university` DEFAULT CHARACTER SET utf8 ;
USE `university` ;

-- -----------------------------------------------------
-- Table `university`.`department`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`department` ;

CREATE TABLE IF NOT EXISTS `university`.`department` (
  `department_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `department_name` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`department_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`degree`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`degree` ;

CREATE TABLE IF NOT EXISTS `university`.`degree` (
  `degree_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `degree_name` VARCHAR(45) NOT NULL,
  `department_id` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`degree_id`),
  INDEX `fk_degree_department1_idx` (`department_id` ASC) VISIBLE,
  CONSTRAINT `fk_degree_department1`
    FOREIGN KEY (`department_id`)
    REFERENCES `university`.`department` (`department_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`course`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`course` ;

CREATE TABLE IF NOT EXISTS `university`.`course` (
  `course_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `course_code` VARCHAR(45) NOT NULL,
  `course_num` INT UNSIGNED NOT NULL,
  `course_title` VARCHAR(45) NOT NULL,
  `credits` TINYINT UNSIGNED NOT NULL,
  `degree_id` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`course_id`),
  INDEX `fk_course_degree1_idx` (`degree_id` ASC) VISIBLE,
  CONSTRAINT `fk_course_degree1`
    FOREIGN KEY (`degree_id`)
    REFERENCES `university`.`degree` (`degree_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`term`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`term` ;

CREATE TABLE IF NOT EXISTS `university`.`term` (
  `term_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `term_name` VARCHAR(6) NOT NULL,
  `term_year` YEAR NOT NULL,
  PRIMARY KEY (`term_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`section`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`section` ;

CREATE TABLE IF NOT EXISTS `university`.`section` (
  `section_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `section_num` TINYINT UNSIGNED NOT NULL,
  `capacity` TINYINT UNSIGNED NOT NULL,
  `course_id` INT UNSIGNED NOT NULL,
  `term_id` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`section_id`),
  INDEX `fk_section_course1_idx` (`course_id` ASC) VISIBLE,
  INDEX `fk_section_term1_idx` (`term_id` ASC) VISIBLE,
  CONSTRAINT `fk_section_course1`
    FOREIGN KEY (`course_id`)
    REFERENCES `university`.`course` (`course_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_section_term1`
    FOREIGN KEY (`term_id`)
    REFERENCES `university`.`term` (`term_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`person`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`person` ;

CREATE TABLE IF NOT EXISTS `university`.`person` (
  `person_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `first_name` VARCHAR(20) NOT NULL,
  `last_name` VARCHAR(20) NOT NULL,
  `gender` ENUM('M', 'F') NULL,
  `city` VARCHAR(20) NULL,
  `state` VARCHAR(2) NULL,
  `birthdate` DATE NULL,
  PRIMARY KEY (`person_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`enrollment`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`enrollment` ;

CREATE TABLE IF NOT EXISTS `university`.`enrollment` (
  `person_id` INT UNSIGNED NOT NULL,
  `section_id` INT UNSIGNED NOT NULL,
  `role` ENUM('Teacher', 'Student', 'TA') NOT NULL,
  PRIMARY KEY (`person_id`, `section_id`),
  INDEX `fk_person_section_section1_idx` (`section_id` ASC) VISIBLE,
  INDEX `fk_person_section_person1_idx` (`person_id` ASC) VISIBLE,
  CONSTRAINT `fk_person_section_person1`
    FOREIGN KEY (`person_id`)
    REFERENCES `university`.`person` (`person_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_person_section_section1`
    FOREIGN KEY (`section_id`)
    REFERENCES `university`.`section` (`section_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;

USE university;

-- Department
INSERT INTO department (department_name) VALUES
('Computer Science and Engineering'),
('Mathematics'),
('Music');

-- Term
INSERT INTO term (term_name, term_year) VALUES
('Fall', 2024),
('Winter', 2025);

-- Person
INSERT INTO person (first_name, last_name, gender, city, state, birthdate) VALUES
('Brady', 'Meyer', null, null, null, null),
('Andy', 'Kipner', null, null, null, null),
('Lucy', 'Fuller', null, null, null, null),
('Adam', 'Woods', null, null, null, null),
('Bryan', 'Drew', null, null, null, null),
('Marshall', 'Spence', 'M', 'Garland', 'TX', '2000-06-23'),
('Maria', 'Clark', 'F', 'Akron', 'OH', '2002-01-25'),
('Tracy', 'Woodward', 'F', 'Newark', 'NJ', '2002-10-04'),
('Erick', 'Woodward', 'M', 'Newark', 'NJ', '1998-08-05'),
('Lillie', 'Summers', 'F', 'Reno', 'NV', '1999-11-05'),
('Nellie', 'Marquez', 'F', 'Atlanta', 'GA', '2001-06-25'),
('Allen', 'Stokes', 'M', 'Bozeman', 'MT', '2004-09-16'),
('Josh', 'Rollins', 'M', 'Decatur', 'TN', '1998-11-28'),
('Isabel', 'Meyers', 'F', 'Rexburg', 'ID', '2003-05-15'),
('Kerri', 'Shaw', 'F', 'Mesa', 'AZ', '2003-04-05');

-- Degree
INSERT INTO degree (degree_name, department_id) VALUES
('Computer Science', 1),
('Web Design and Development', 1),
('Data Science', 2),
('Organ Performance', 3);

-- Course
INSERT INTO course (course_code, course_num, course_title, credits, degree_id) VALUES
('CSE', 251, 'Parallelism and Concurrency', 3, 1),
('WDD', 231, 'Web Frontend Development I', 2, 2),
('MATH', 113, 'Calculus II', 3, 3),
('MUSIC', 213, 'Musicianship 4', 3, 4);

-- Section
INSERT INTO section (section_num, capacity, course_id, term_id) VALUES
(1, 35, 1, 1),
(1, 30, 2, 1),
(2, 30, 2, 1),
(1, 45, 3, 1),
(1, 25, 4, 1),
(2, 35, 1, 2),
(3, 35, 1, 2),
(1, 30, 2, 2),
(2, 40, 2, 2),
(1, 25, 4, 2);

-- Enrollment
INSERT INTO enrollment (person_id, section_id, role) VALUES
((SELECT person_id FROM person WHERE CONCAT(first_name,' ', last_name) = 'Brady Meyer'), 1, 'Teacher'),
((SELECT person_id FROM person WHERE CONCAT(first_name,' ', last_name) = 'Brady Meyer'), 6, 'Teacher'),
((SELECT person_id FROM person WHERE CONCAT(first_name,' ', last_name) = 'Andy Kipner'), 2, 'Teacher'),
((SELECT person_id FROM person WHERE CONCAT(first_name,' ', last_name) = 'Andy Kipner'), 3, 'Teacher'),
((SELECT person_id FROM person WHERE CONCAT(first_name,' ', last_name) = 'Andy Kipner'), 8, 'Teacher'),
((SELECT person_id FROM person WHERE CONCAT(first_name,' ', last_name) = 'Andy Kipner'), 9, 'Teacher'),
((SELECT person_id FROM person WHERE CONCAT(first_name,' ', last_name) = 'Lucy Fuller'), 4, 'Teacher'),
((SELECT person_id FROM person WHERE CONCAT(first_name,' ', last_name) = 'Adam Woods'), 5, 'Teacher'),
((SELECT person_id FROM person WHERE CONCAT(first_name,' ', last_name) = 'Adam Woods'), 10, 'Teacher'),
((SELECT person_id FROM person WHERE CONCAT(first_name,' ', last_name) = 'Bryan Drew'), 7, 'Teacher'),
((SELECT person_id FROM person WHERE CONCAT(first_name,' ', last_name) = 'Marshall Spence'), 1, 'Student'),
((SELECT person_id FROM person WHERE CONCAT(first_name,' ', last_name) = 'Marshall Spence'), 3, 'Student'),
((SELECT person_id FROM person WHERE CONCAT(first_name,' ', last_name) = 'Maria Clark'), 4, 'Student'),
((SELECT person_id FROM person WHERE CONCAT(first_name,' ', last_name) = 'Tracy Woodward'), 4, 'Student'),
((SELECT person_id FROM person WHERE CONCAT(first_name,' ', last_name) = 'Erick Woodward'), 5, 'Student'),
((SELECT person_id FROM person WHERE CONCAT(first_name,' ', last_name) = 'Lillie Summers'), 4, 'Student'),
((SELECT person_id FROM person WHERE CONCAT(first_name,' ', last_name) = 'Lillie Summers'), 5, 'TA'),
((SELECT person_id FROM person WHERE CONCAT(first_name,' ', last_name) = 'Nellie Marquez'), 7, 'Student'),
((SELECT person_id FROM person WHERE CONCAT(first_name,' ', last_name) = 'Allen Stokes'), 6, 'Student'),
((SELECT person_id FROM person WHERE CONCAT(first_name,' ', last_name) = 'Allen Stokes'), 8, 'TA'),
((SELECT person_id FROM person WHERE CONCAT(first_name,' ', last_name) = 'Allen Stokes'), 10, 'Student'),
((SELECT person_id FROM person WHERE CONCAT(first_name,' ', last_name) = 'Josh Rollins'), 9, 'Student'),
((SELECT person_id FROM person WHERE CONCAT(first_name,' ', last_name) = 'Isabel Meyers'), 9, 'Student'),
((SELECT person_id FROM person WHERE CONCAT(first_name,' ', last_name) = 'Kerri Shaw'), 6, 'Student');