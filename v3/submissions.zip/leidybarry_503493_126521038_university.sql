-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema University
-- -----------------------------------------------------
DROP SCHEMA IF EXISTS `University` ;

-- -----------------------------------------------------
-- Schema University
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `University` DEFAULT CHARACTER SET utf8 ;
USE `University` ;

-- -----------------------------------------------------
-- Table `University`.`dept`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `University`.`dept` ;

CREATE TABLE IF NOT EXISTS `University`.`dept` (
  `department_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `department_name` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`department_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `University`.`degree`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `University`.`degree` ;

CREATE TABLE IF NOT EXISTS `University`.`degree` (
  `degree_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `degree_name` VARCHAR(45) NOT NULL,
  `dept_department_id` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`degree_id`),
  INDEX `fk_degree_dept1_idx` (`dept_department_id` ASC) VISIBLE,
  CONSTRAINT `fk_degree_dept1`
    FOREIGN KEY (`dept_department_id`)
    REFERENCES `University`.`dept` (`department_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `University`.`year_term`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `University`.`year_term` ;

CREATE TABLE IF NOT EXISTS `University`.`year_term` (
  `year_term_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `year` YEAR NOT NULL,
  `term` VARCHAR(10) NOT NULL,
  `section` TINYINT NOT NULL,
  `capacity` INT NOT NULL,
  PRIMARY KEY (`year_term_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `University`.`course`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `University`.`course` ;

CREATE TABLE IF NOT EXISTS `University`.`course` (
  `course_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `course_num` INT NOT NULL,
  `couse_code` VARCHAR(10) NOT NULL,
  `course_title` VARCHAR(45) NOT NULL,
  `credit` TINYINT NOT NULL,
  `degree_degree_id` INT UNSIGNED NOT NULL,
  `year_term_year_term_id` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`course_id`),
  INDEX `fk_course_degree1_idx` (`degree_degree_id` ASC) VISIBLE,
  INDEX `fk_course_year_term1_idx` (`year_term_year_term_id` ASC) VISIBLE,
  CONSTRAINT `fk_course_degree1`
    FOREIGN KEY (`degree_degree_id`)
    REFERENCES `University`.`degree` (`degree_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_course_year_term1`
    FOREIGN KEY (`year_term_year_term_id`)
    REFERENCES `University`.`year_term` (`year_term_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `University`.`location`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `University`.`location` ;

CREATE TABLE IF NOT EXISTS `University`.`location` (
  `location_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `city` VARCHAR(45) NULL,
  `state` VARCHAR(2) NULL,
  PRIMARY KEY (`location_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `University`.`person`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `University`.`person` ;

CREATE TABLE IF NOT EXISTS `University`.`person` (
  `person_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `f_name` VARCHAR(45) NOT NULL,
  `l_name` VARCHAR(45) NOT NULL,
  `gender` VARCHAR(1) NULL,
  `birthdate` DATE NULL,
  `location_location_id` INT UNSIGNED NULL,
  PRIMARY KEY (`person_id`),
  INDEX `fk_person_location1_idx` (`location_location_id` ASC) VISIBLE,
  CONSTRAINT `fk_person_location1`
    FOREIGN KEY (`location_location_id`)
    REFERENCES `University`.`location` (`location_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `University`.`role`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `University`.`role` ;

CREATE TABLE IF NOT EXISTS `University`.`role` (
  `role_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `role_name` VARCHAR(45) NULL,
  PRIMARY KEY (`role_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `University`.`course_has_person`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `University`.`course_has_person` ;

CREATE TABLE IF NOT EXISTS `University`.`course_has_person` (
  `course_course_id` INT UNSIGNED NOT NULL,
  `person_person_id` INT UNSIGNED NOT NULL,
  `role_role_id` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`course_course_id`, `person_person_id`),
  INDEX `fk_course_has_person_person1_idx` (`person_person_id` ASC) VISIBLE,
  INDEX `fk_course_has_person_course1_idx` (`course_course_id` ASC) VISIBLE,
  INDEX `fk_course_has_person_role1_idx` (`role_role_id` ASC) VISIBLE,
  CONSTRAINT `fk_course_has_person_course1`
    FOREIGN KEY (`course_course_id`)
    REFERENCES `University`.`course` (`course_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_course_has_person_person1`
    FOREIGN KEY (`person_person_id`)
    REFERENCES `University`.`person` (`person_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_course_has_person_role1`
    FOREIGN KEY (`role_role_id`)
    REFERENCES `University`.`role` (`role_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;


USE university;

insert into dept (department_id, department_name)
values 
(DEFAULT, 'Computer Science and Engineering'),
(DEFAULT, 'Mathematics'),
(DEFAULT, 'Music');

insert into degree (degree_id, degree_name, dept_department_id)
values
(DEFAULT, 'Computer Science', '1'),
(DEFAULT, 'Web Design and Development', '1'),
(DEFAULT, 'Data Science', '2'),
(DEFAULT, 'Organ Performance', '3');

insert into year_term (year_term_id, year, term, section, capacity)
values
(DEFAULT, '2024', 'Fall', '1', '35'),
(DEFAULT, '2024', 'Fall', '1', '30'),
(DEFAULT, '2024', 'Fall', '2', '30'),
(DEFAULT, '2024', 'Fall', '1', '45'),
(DEFAULT, '2024', 'Fall', '1', '25'),
(DEFAULT, '2025', 'Winter', '2', '35'),
(DEFAULT, '2025', 'Winter', '3', '35'),
(DEFAULT, '2025', 'Winter', '1', '30'),
(DEFAULT, '2025', 'Winter', '2', '40'),
(DEFAULT, '2025', 'Winter', '1', '25');

select * from year_term;

insert into course (course_id, course_num, couse_code, course_title, credit, degree_degree_id, year_term_year_term_id)
values
(DEFAULT, '251', 'CSE', 'Parallelism and Concurrency', '3', '1', '1'),
(DEFAULT, '231', 'WDD', 'Web Design and Development', '2', '2', '2'),
(DEFAULT, '231', 'WDD', 'Web Design and Development', '2', '2', '3'),
(DEFAULT, '113', 'MATH', 'Data Science', '3', '3', '4'),
(DEFAULT, '213', 'MUSIC', 'Organ Performance', '3', '4', '5'),
(DEFAULT, '251', 'CSE', 'Parallelism and Concurrency', '3', '1', '6'),
(DEFAULT, '251', 'CSE', 'Parallelism and Concurrency', '3', '1', '7'),
(DEFAULT, '231', 'WDD', 'Web Design and Development', '2', '2', '8'),
(DEFAULT, '231', 'WDD', 'Web Design and Development', '2', '2', '9'),
(DEFAULT, '213', 'MUSIC', 'Organ Performance', '3', '4', '10');

insert into role (role_id, role_name)
values
(DEFAULT, 'Teacher'),
(DEFAULT, 'Student'),
(DEFAULT, 'TA');

insert into location (location_id, city, state)
values
(DEFAULT, 'Garland', 'TX'),
(DEFAULT, 'Akron', 'OH'),
(DEFAULT, 'Newark', 'NJ'),
(DEFAULT, 'Reno', 'NV'),
(DEFAULT, 'Atlanta', 'GA'),
(DEFAULT, 'Bozeman', 'MT'),
(DEFAULT, 'Decatur', 'TN'),
(DEFAULT, 'Rexburg', 'ID'),
(DEFAULT, 'Mesa', 'AZ');

insert into person (person_id, f_name, l_name, gender, birthdate, location_location_id)
values
(DEFAULT, 'Brady', 'Meyer', null, null, null),
(DEFAULT, 'Andy', 'Kipner', null, null, null),
(DEFAULT, 'Lucy', 'Fuller', null, null, null),
(DEFAULT, 'Adam ', 'Woods', null, null, null),
(DEFAULT, 'Bryan', 'Drew', null, null, null),
(DEFAULT, 'Marshall', 'Spence', 'M', '2000-06-23', '1'),
(DEFAULT, 'Maria', 'Clark', 'F', '2002-01-25', '2'),
(DEFAULT, 'Tracy', 'Woodward', 'F', '2002-10-04', '3'),
(DEFAULT, 'Erick', 'Woodward', 'M', '1998-08-05', '3'),
(DEFAULT, 'Lillie', 'Summers', 'F', '1999-11-05', '4'),
(DEFAULT, 'Nellie', 'Marquez', 'F', '2001-06-25', '5'),
(DEFAULT, 'Allen', 'Stokes ', 'M', '2004-09-16', '6'),
(DEFAULT, 'Josh', 'Rollins', 'M', '1998-11-28', '7'),
(DEFAULT, 'Isabel', 'Meyers', 'F', '2003-05-15', '8'),
(DEFAULT, 'Kerri', 'Shah', 'F', '2003-04-05', '9');

select * from role;
select * from person;

insert into course_has_person (course_course_id, person_person_id, role_role_id)
values
('1', '1', '1'),
('6', '1', '1'),
('2', '2', '1'),
('3', '2', '1'),
('8', '2', '1'),
('9', '2', '1'),
('4', '3', '1'),
('5', '4', '1'),
('10', '4', '1'),
('7', '5', '1'),
('1', '6', '2'),
('3', '6', '2'),
('4', '7', '2'),
('4', '8', '2'),
('5', '9', '2'),
('4', '10', '2'),
('5', '10', '3'),
('7', '11', '2'),
('6', '12', '2'),
('8', '12', '3'),
('10', '12', '2'),
('9', '13', '2'),
('9', '14', '2'),
('6', '15', '2');