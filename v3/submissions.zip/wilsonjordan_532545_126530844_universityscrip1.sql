-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema university
-- -----------------------------------------------------
DROP SCHEMA IF EXISTS `university` ;

-- -----------------------------------------------------
-- Schema university
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `university` DEFAULT CHARACTER SET utf8 ;
USE `university` ;

-- -----------------------------------------------------
-- Table `university`.`department`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`department` ;

CREATE TABLE IF NOT EXISTS `university`.`department` (
  `department_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `department_name` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`department_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`degree`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`degree` ;

CREATE TABLE IF NOT EXISTS `university`.`degree` (
  `degree_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `degree_name` VARCHAR(45) NOT NULL,
  `department_id` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`degree_id`),
  INDEX `fk_degree_department1_idx` (`department_id` ASC) VISIBLE,
  CONSTRAINT `fk_degree_department1`
    FOREIGN KEY (`department_id`)
    REFERENCES `university`.`department` (`department_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;

-- -----------------------------------------------------
-- Table `university`.`course`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`course` ;

CREATE TABLE IF NOT EXISTS `university`.`course` (
  `course_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `course_credit` INT NOT NULL,
  `course_code` CHAR(5) NOT NULL,
  `course_num` INT NOT NULL,
  `course_title` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`course_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`person`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`person` ;

CREATE TABLE IF NOT EXISTS `university`.`person` (
  `person_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `fname` VARCHAR(45) NOT NULL,
  `lname` VARCHAR(45) NOT NULL,
  `city` VARCHAR(45) NULL,
  `state` VARCHAR(45) NULL,
  `gender` ENUM("M", "F") NULL,
  `birthdate` DATE NULL,
  PRIMARY KEY (`person_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`term`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`term` ;

CREATE TABLE IF NOT EXISTS `university`.`term` (
  `term_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `semester` VARCHAR(45) NOT NULL,
  `year` YEAR NOT NULL,
  PRIMARY KEY (`term_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`section`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`section` ;

CREATE TABLE IF NOT EXISTS `university`.`section` (
  `section_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `section_num` INT NOT NULL,
  `section_capacity` INT NOT NULL,
  `term_id` INT UNSIGNED NOT NULL,
  `course_id` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`section_id`, `term_id`),
  INDEX `fk_section_term1_idx` (`term_id` ASC) VISIBLE,
  INDEX `fk_section_course1_idx` (`course_id` ASC) VISIBLE,
  CONSTRAINT `fk_section_term1`
    FOREIGN KEY (`term_id`)
    REFERENCES `university`.`term` (`term_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_section_course1`
    FOREIGN KEY (`course_id`)
    REFERENCES `university`.`course` (`course_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`degree_course`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`degree_course` ;

CREATE TABLE IF NOT EXISTS `university`.`degree_course` (
  `degree_course_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `degree_id` INT UNSIGNED NOT NULL,
  `course_id` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`degree_course_id`),
  INDEX `fk_degree_has_course_degree1_idx` (`degree_id` ASC) VISIBLE,
  INDEX `fk_degree_has_course_course1_idx` (`course_id` ASC) VISIBLE,
  CONSTRAINT `fk_degree_has_course_degree1`
    FOREIGN KEY (`degree_id`)
    REFERENCES `university`.`degree` (`degree_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_degree_has_course_course1`
    FOREIGN KEY (`course_id`)
    REFERENCES `university`.`course` (`course_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`person_type`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`person_type` ;

CREATE TABLE IF NOT EXISTS `university`.`person_type` (
  `person_type_id` INT NOT NULL,
  `person_type` ENUM("TA", "Student", "Teacher") NOT NULL,
  PRIMARY KEY (`person_type_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`person_has_section`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`person_has_section` ;

CREATE TABLE IF NOT EXISTS `university`.`person_has_section` (
  `person_has_section_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `person_id` INT UNSIGNED NOT NULL,
  `section_id` INT UNSIGNED NOT NULL,
  `person_type_id` INT NOT NULL,
  INDEX `fk_person_has_section_person1_idx` (`person_id` ASC) VISIBLE,
  INDEX `fk_person_has_section_section1_idx` (`section_id` ASC) VISIBLE,
  INDEX `fk_person_has_section_person_type1_idx` (`person_type_id` ASC) VISIBLE,
  PRIMARY KEY (`person_has_section_id`),
  CONSTRAINT `fk_person_has_section_person1`
    FOREIGN KEY (`person_id`)
    REFERENCES `university`.`person` (`person_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_person_has_section_section1`
    FOREIGN KEY (`section_id`)
    REFERENCES `university`.`section` (`section_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_person_has_section_person_type1`
    FOREIGN KEY (`person_type_id`)
    REFERENCES `university`.`person_type` (`person_type_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;

USE university;


INSERT INTO department (department_id, department_name) VALUES
	('1','Computer Science and Engineering'),
    ('2', 'Mathematics'),
    ('3','Music');
 
INSERT INTO term (semester, year) VALUES
	('Fall', '2024'),
    ('Winter','2025');

INSERT INTO person (person_id, fname, lname, gender, city, state, birthdate) VALUES
	('1',"Marshal","Spence","M","Garland","TX","2000-06-23"),
    ('2',"Maria","Clark","F","Akron","OH","2002-01-25"),
    ('3',"Tracy","Woodward", "F", "Newark","NJ","2002-10-04"),
    ('4',"Erick","Woodward","M","Newark","NJ","1998-08-05"),
    ('5',"Lillie","Summers","F","Reno","NV","1999-11-05"),
    ('6',"Nellie","Marquez","F","Atlanta","GA","2001-06-25"),
    ('7',"Allen","Stokes","M","Bozeman","MT","2004-09-16"),
    ('8',"Josh","Rollins","M","Decatur","TN","1998-11-28"),
    ('9',"Isabe","Meyers","F","Rexburg","ID","2003-05-15"),
    ('10',"Kerri","Shah","F","Mesa","AZ","2003-04-05"),
    ('11',"Brady","Meyer", NULL, NULL, NULL, NULL),
    ('12',"Andy","Kipner", NULL, NULL, NULL, NULL),
    ('13',"Lucy","Fuller", NULL, NULL, NULL, NULL),
    ('14',"Adam","Woods", NULL, NULL, NULL, NULL),
    ('15',"Bryan","Drew", NULL, NULL, NULL, NULL);
SELECT * FROM degree;
INSERT INTO degree (department_id, degree_name) VALUES
	(1, 'Computer Science'),
    (1, 'Web Design and Development'),
    (2, 'Data Science'),
    (3, 'Organ Performance');
    
INSERT INTO course (course_id, course_code, course_num, course_title, course_credit) VALUES
	('1','CSE','251', 'Paralleslism and Concorrecy','3'), 
    ('2','WDD','231', 'Web Fronted Development 1','2'),
    ('3','MATH','113','Calulus 2', '3'),
    ('4','MUSIC','213', 'Musicianship 4', '3');

INSERT INTO section (section_id, section_num, section_capacity,term_id, course_id) VALUES
	('1','1','35', 1, 1), 
    ('2','1','30', 1, 2),
    ('3','2','30', 1, 2),
    ('4','1','45','1','3'),
    ('5','1','25','1','4'),
    ('6','2','35','2','1'),
    ('7','3','35','2','1'),
    ('8','1','30','2','2'),
    ('9','2','40','2','2'),
    ('10','1','25','2','4');

INSERT INTO person_type (person_type_id, person_type) VALUES
	('1','TA'),
    ('2','Teacher'),
    ('3','Student');
SELECT * FROM person_has_section;
INSERT INTO person_has_section (person_has_section_id, person_type_id, section_id, person_id) VALUES
	('1',2,1,11),
    ('2',2,6,11),               
    ('3',2,2,12),		        
    ('4',2,3,12),
    ('5',2,8,12),
    ('6',2,9,12),
    ('7',2,4,13),
    ('8',2,5,14),
    ('9',2,10,14),
    ('10',2,7,15),
    ('11',3,1,1),
    ('12',3,3,1),
    ('13',3,4,2),
    ('14',3,4,3),
    ('15',3,5,4),
    ('16',3,4,5),
    ('17',1,5,5),
    ('18',3,7,6),
    ('19',3,6,7),
    ('20',1,8,7),
    ('21',3,10,7),
    ('22',3,9,9),
    ('23',3,9,9),
    ('24',3,6,10);

INSERT INTO degree_course (degree_course_id, degree_id, course_id) VALUES
	('1',1,1),
    ('2',2,2),
    ('3',3,3),
    ('4',4,4);
	


    
