-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema university
-- -----------------------------------------------------
DROP SCHEMA IF EXISTS `university` ;

-- -----------------------------------------------------
-- Schema university
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `university` DEFAULT CHARACTER SET utf8 ;
USE `university` ;

-- -----------------------------------------------------
-- Table `university`.`department`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`department` ;

CREATE TABLE IF NOT EXISTS `university`.`department` (
  `department_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `department_name` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`department_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`degree`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`degree` ;

CREATE TABLE IF NOT EXISTS `university`.`degree` (
  `degree_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `degree_name` VARCHAR(45) NOT NULL,
  `department_id` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`degree_id`),
  INDEX `fk_degree_department1_idx` (`department_id` ASC) VISIBLE,
  CONSTRAINT `fk_degree_department1`
    FOREIGN KEY (`department_id`)
    REFERENCES `university`.`department` (`department_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`course`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`course` ;

CREATE TABLE IF NOT EXISTS `university`.`course` (
  `course_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `course_title` VARCHAR(45) NOT NULL,
  `course_num` INT NOT NULL,
  `course_code` VARCHAR(10) NOT NULL,
  `credits` INT NOT NULL,
  `degree_id` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`course_id`),
  INDEX `fk_course_degree1_idx` (`degree_id` ASC) VISIBLE,
  CONSTRAINT `fk_course_degree1`
    FOREIGN KEY (`degree_id`)
    REFERENCES `university`.`degree` (`degree_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`person`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`person` ;

CREATE TABLE IF NOT EXISTS `university`.`person` (
  `person_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `first_name` VARCHAR(45) NOT NULL,
  `last_name` VARCHAR(45) NOT NULL,
  `gender` VARCHAR(1) NULL,
  `birthday` DATE NULL,
  `role` VARCHAR(45) NOT NULL,
  `city_name` VARCHAR(45) NULL,
  `state_name` VARCHAR(45) NULL,
  PRIMARY KEY (`person_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`semester`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`semester` ;

CREATE TABLE IF NOT EXISTS `university`.`semester` (
  `semester_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `year` YEAR NOT NULL,
  `term` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`semester_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`section`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`section` ;

CREATE TABLE IF NOT EXISTS `university`.`section` (
  `section_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `section_num` VARCHAR(45) NOT NULL,
  `capacity` VARCHAR(45) NOT NULL,
  `semester_id` INT UNSIGNED NOT NULL,
  `course_id` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`section_id`),
  INDEX `fk_section_semester1_idx` (`semester_id` ASC) VISIBLE,
  INDEX `fk_section_course1_idx` (`course_id` ASC) VISIBLE,
  CONSTRAINT `fk_section_semester1`
    FOREIGN KEY (`semester_id`)
    REFERENCES `university`.`semester` (`semester_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_section_course1`
    FOREIGN KEY (`course_id`)
    REFERENCES `university`.`course` (`course_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`person_section`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`person_section` ;

CREATE TABLE IF NOT EXISTS `university`.`person_section` (
  `person_id` INT UNSIGNED NOT NULL,
  `section_id` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`person_id`, `section_id`),
  INDEX `fk_person_section_section1_idx` (`section_id` ASC) VISIBLE,
  INDEX `fk_person_section_person1_idx` (`person_id` ASC) VISIBLE,
  CONSTRAINT `fk_person_section_person1`
    FOREIGN KEY (`person_id`)
    REFERENCES `university`.`person` (`person_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_person_section_section1`
    FOREIGN KEY (`section_id`)
    REFERENCES `university`.`section` (`section_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;



USE university;

-- Inserting department data
INSERT INTO department (department_name)
VALUES ('Computer Science and Engineering'),
('Mathematics'),
('Music');


-- Inserting degree data
INSERT INTO degree (degree_name, department_id) 
VALUES 
('Computer Science', 1),
('Data Science', 2),
('Organ Performance', 3);


-- Inserting course data
INSERT INTO course (course_title, course_num, course_code, credits, degree_id)
VALUES 
('Parallelism and Concurrency', 251, 'CSE', 3, 1),
('Web Frontend Development I', 231, 'WDD', 2, 1),
('Calculus II', 113, 'MATH', 3, 2),
('Musicianship 4', 213, 'MUSIC', 3, 3);


-- Insert semester data
INSERT INTO semester (year, term)
VALUES 
('2024', 'Fall'),
('2025', 'Winter');

-- Inserting section data
INSERT INTO section (semester_id, course_id, section_num, capacity)
VALUES 
-- Fall 2024
(1, 1, '1', 35), -- CSE 251 Section 1
(1, 2, '1', 30), -- WDD 231 Section 1
(1, 2, '2', 30), -- WDD 231 Section 2
(1, 3, '1', 45), -- MATH 113 Section 1
(1, 4, '1', 25), -- MUSIC 213 Section 1
-- Winter 2025
(2, 1, '2', 35), -- CSE 251 Section 2
(2, 1, '3', 35), -- CSE 251 Section 3
(2, 2, '1', 30), -- WDD 231 Section 1
(2, 2, '2', 40), -- WDD 231 Section 2
(2, 4, '1', 25); -- MUSIC 213 Section 1



-- Inserting person data
INSERT INTO person (first_name, last_name, gender, birthday, role, city_name, state_name)
VALUES
('Marshall', 'Spence', 'M', '2000-06-23', 'Student', 'Garland', 'TX'),
('Maria', 'Clark', 'F', '2002-01-25', 'Student', 'Akron', 'OH'),
('Tracy', 'Woodward', 'F', '2002-10-04', 'Student', 'Newark', 'NJ'),
('Erick', 'Woodward', 'M', '1998-08-05', 'Student', 'Newark', 'NJ'),
('Lillie', 'Summers', 'F', '1999-11-05', 'Student', 'Reno', 'NV'),
('Nellie', 'Marquez', 'F', '2001-06-25', 'Student', 'Atlanta', 'GA'),
('Allen', 'Stokes', 'M', '2004-09-16', 'Student', 'Bozeman', 'MT'),
('Josh', 'Rollins', 'M', '1998-11-28', 'Student', 'Decatur', 'TN'),
('Isabel', 'Meyers', 'F', '2003-05-15', 'Student', 'Rexburg', 'ID'),
('Kerri', 'Shah', 'F', '2003-04-05', 'Student', 'Mesa', 'AZ'),
('Lucy', 'Fuller', NULL, NULL, 'Teacher', NULL, NULL),
('Brady', 'Meyer', NULL, NULL, 'Teacher', NULL, NULL),
('Adam', 'Woods', NULL, NULL, 'Teacher', NULL, NULL),
('Bryan', 'Drew', NULL, NULL, 'Teacher', NULL, NULL),
('Andy', 'Kipner', NULL, NULL, 'Teacher', NULL, NULL),
('Allen', 'Stokes', 'M', '2004-09-16', 'TA', 'Bozeman', 'MT'),
('Lillie', 'Summers', 'F', '1999-11-05', 'TA', 'Reno', 'NV');


SELECT * FROM person;
SELECT * FROM section;
-- Insert person_section data
INSERT INTO person_section (person_id, section_id)
VALUES
-- Teachers
(12, 1), -- Brady, Teacher of CSE 251 Fall 2024 Section 1
(12, 6), -- Brady, Teacher of CSE 251 Winter 2025 Section 2
(15, 2), -- Andy, Teacher of WDD 231 Fall 2024 Section 1
(15, 3), -- Andy, Teacher of WDD 231 Fall 2024 Section 2
(15, 8), -- Andy, Teacher of WDD 231 Winter 2025 Section 1
(15, 9), -- Andy, Teacher of WDD 231 Winter 2025 Section 2
(11, 4), -- Lucy, Teacher of MATH 113 Fall 2024 Section 1
(13, 5), -- Adam, Teacher of MUSIC 213 Fall 2024 Section 1
(13, 10), -- Adam, Teacher of MUSIC 213 Winter 2025 Section 1
(14, 7), -- Bryan, Teacher of CSE 251 Winter 2025 Section 3
-- Students
(1, 1), -- Marshall, Student of CSE 251 Fall 2024 Section 1
(2, 4), -- Maria, Student of MATH 113 Fall 2024 Section 1
(3, 4), -- Tracy, Student of MATH 113 Fall 2024 Section 1
(4, 5), -- Erick, Student of MUSIC 213 Fall 2024 Section 1
(5, 4), -- Lillie, Student of MATH 113 Fall 2024 Section 1
(17, 5), -- Lillie, TA of MUSIC 213 Fall 2024 Section 1
(6, 7), -- Nellie, Student of CSE 251 Winter 2025 Section 3
(7, 6), -- Allen, Student of CSE 251 Winter 2025 Section 2
(16, 8), -- Allen, TA of WDD 231 Winter 2025 Section 1
(7, 10), -- Allen, Student of MUSIC 213 Winter 2025 Section 1
(8, 8), -- Josh, Student of WDD 231 Winter 2025 Section 1
(9, 8), -- Isabel, Student of WDD 231 Winter 2025 Section 1
(10, 6); -- Kerri, Student of CSE 251 Winter 2025 Section 2

SELECT * FROM person_section; 

SELECT 
    CONCAT(p.first_name, ' ', p.last_name) AS full_name,
    p.role,
    c.course_title AS course_name,
    CONCAT(c.course_code, ' ', c.course_num) AS course_code,
    s.section_num AS section,
    se.term AS semester_name,
    se.year
FROM 
    person p
JOIN 
    person_section ps ON p.person_id = ps.person_id
JOIN 
    section s ON ps.section_id = s.section_id
JOIN 
    course c ON s.course_id = c.course_id
JOIN 
    semester se ON s.semester_id = se.semester_id
WHERE 
    p.first_name = 'Allen' AND p.last_name = 'Stokes';


SELECT 
    CONCAT(p.first_name, ' ', p.last_name) AS full_name,
    c.course_title AS course_name,
    s.section_num AS section,
    se.term AS term_name,
    se.year
FROM 
    person p
JOIN 
    person_section ps ON p.person_id = ps.person_id
JOIN 
    section s ON ps.section_id = s.section_id
JOIN 
    course c ON s.course_id = c.course_id
JOIN 
    semester se ON s.semester_id = se.semester_id
WHERE 
    c.course_code = 'CSE' AND c.course_num = 251 AND p.role = 'student';





