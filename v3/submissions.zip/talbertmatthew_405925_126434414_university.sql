-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema university
-- -----------------------------------------------------
DROP SCHEMA IF EXISTS `university` ;

-- -----------------------------------------------------
-- Schema university
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `university` DEFAULT CHARACTER SET utf8 ;
USE `university` ;

-- -----------------------------------------------------
-- Table `university`.`person`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`person` ;

CREATE TABLE IF NOT EXISTS `university`.`person` (
  `person_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `first_name` VARCHAR(45) NOT NULL,
  `last_name` VARCHAR(45) NOT NULL,
  `gender` CHAR(1) NULL,
  `city` VARCHAR(45) NULL,
  `state` CHAR(2) NULL,
  `birthdate` DATE NULL,
  PRIMARY KEY (`person_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`department`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`department` ;

CREATE TABLE IF NOT EXISTS `university`.`department` (
  `department_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `department_name` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`department_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`degree`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`degree` ;

CREATE TABLE IF NOT EXISTS `university`.`degree` (
  `degree_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `degree_name` VARCHAR(45) NOT NULL,
  `department_id` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`degree_id`),
  INDEX `fk_degree_department1_idx` (`department_id` ASC) VISIBLE,
  CONSTRAINT `fk_degree_department1`
    FOREIGN KEY (`department_id`)
    REFERENCES `university`.`department` (`department_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`course`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`course` ;

CREATE TABLE IF NOT EXISTS `university`.`course` (
  `course_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `course_code` VARCHAR(7) NOT NULL,
  `course_num` INT NOT NULL,
  `course_title` VARCHAR(45) NOT NULL,
  `course_credits` INT NOT NULL,
  `degree_id` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`course_id`),
  INDEX `fk_course_degree1_idx` (`degree_id` ASC) VISIBLE,
  CONSTRAINT `fk_course_degree1`
    FOREIGN KEY (`degree_id`)
    REFERENCES `university`.`degree` (`degree_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`term`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`term` ;

CREATE TABLE IF NOT EXISTS `university`.`term` (
  `term_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `term` VARCHAR(7) NOT NULL,
  `year` INT NOT NULL,
  PRIMARY KEY (`term_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`class`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`class` ;

CREATE TABLE IF NOT EXISTS `university`.`class` (
  `class_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `section` INT NOT NULL,
  `capacity` INT NOT NULL,
  `course_id` INT UNSIGNED NOT NULL,
  `term_id` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`class_id`),
  INDEX `fk_class_course1_idx` (`course_id` ASC) VISIBLE,
  INDEX `fk_class_term1_idx` (`term_id` ASC) VISIBLE,
  CONSTRAINT `fk_class_course1`
    FOREIGN KEY (`course_id`)
    REFERENCES `university`.`course` (`course_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_class_term1`
    FOREIGN KEY (`term_id`)
    REFERENCES `university`.`term` (`term_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`role`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`role` ;

CREATE TABLE IF NOT EXISTS `university`.`role` (
  `role_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `role` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`role_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`enrollment`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`enrollment` ;

CREATE TABLE IF NOT EXISTS `university`.`enrollment` (
  `enrollment_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `class_id` INT UNSIGNED NOT NULL,
  `person_id` INT UNSIGNED NOT NULL,
  `role_id` INT UNSIGNED NOT NULL,
  INDEX `fk_class_person_person1_idx` (`person_id` ASC) VISIBLE,
  INDEX `fk_class_person_class1_idx` (`class_id` ASC) VISIBLE,
  INDEX `fk_class_person_role1_idx` (`role_id` ASC) VISIBLE,
  PRIMARY KEY (`enrollment_id`),
  CONSTRAINT `fk_class_person_class1`
    FOREIGN KEY (`class_id`)
    REFERENCES `university`.`class` (`class_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_class_person_person1`
    FOREIGN KEY (`person_id`)
    REFERENCES `university`.`person` (`person_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_class_person_role1`
    FOREIGN KEY (`role_id`)
    REFERENCES `university`.`role` (`role_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;

USE university;

INSERT INTO department (department_name) VALUES 
	('Computer Science and Engineering'),
    ('Mathematics'),
    ('Music');
SELECT * from department;

INSERT INTO degree (degree_name, department_id) VALUES
	('Computer Science', 1),
    ('Web Design and Development', 1),
    ('Data Science', 2),
    ('Organ Performance', 3);
SELECT * from degree;

INSERT INTO course (course_code, course_num, course_title, course_credits, degree_id) VALUES
('CSE', 251,'Parallelism and Concurrency', 3, 1),
('WDD', 231,'Web Frontend Development I', 2, 2),
('MATH', 113,'Calculus II', 3, 3),
('MUSIC', 213,'Musicianship 4', 3, 4);
SELECT * from course;

INSERT INTO term (term, year) VALUES
	('Fall',2024),
    ('Winter', 2025);
SELECT * from term;

INSERT INTO class (term_id, course_id, section, capacity) VALUES
	(1,1,1,35),
	(1,2,1,30),
	(1,2,2,30),
	(1,3,1,45),
	(1,4,1,25),
	(2,1,2,35),
	(2,1,3,35),
	(2,2,1,30),
	(2,2,2,40),
	(2,4,1,25);
SELECT * from class;

INSERT INTO role (role) VALUES
	('Teacher'),
	('Student'),	
    ('TA');
SELECT * from role;

-- Teacher Inserts
INSERT INTO person (first_name, last_name) VALUES
('Brady','Meyer'),
('Andy','Kipner'),
('Lucy','Fuller'),
('Adam','Woods'),
('Bryan','Drew');
-- Student Inserts
INSERT INTO person (first_name, last_name, gender, city, state, birthdate) VALUES
("Marshall","Spence","M","Garland","TX",'2000-06-23'),
("Maria","Clark","F","Akron","OH",'2002-01-25'),
("Tracy","Woodward","F","Newark","NJ",'2002-10-04'),
("Erick","Woodward","M","Newark","NJ",'1998-08-05'),
("Lillie","Summers","F","Reno","NV",'1999-11-05'),
("Nellie","Marquez","F","Atlanta","GA",'2001-06-25'),
("Allen","Stokes","M","Bozeman","MT",'2004-09-16'),
("Josh","Rollins","M","Decatur","TN",'1998-11-28'),
("Isabel","Meyers","F","Rexburg","ID",'2003-05-15'),
("Kerri","Shah","F","Mesa","AZ",'2003-04-05');
SELECT * from person;

INSERT INTO enrollment (person_id, class_id, role_id) VALUES 
( 1, 1, 1),
( 1, 6, 1),
( 2, 2, 1),
( 2, 3, 1),
( 2, 8, 1),

( 2, 9, 1),
( 3, 4, 1),
( 4, 5, 1),
( 4, 10, 1),
( 5, 7, 1),

( 6, 1, 2),
( 6, 3, 2),
( 7, 4, 2),
( 8, 4, 2),
( 9, 5, 2),

( 10, 4, 2),
( 10, 5, 3),
( 11, 7, 2),
( 12, 6, 2),
( 12, 8, 3),

( 12, 10, 2),
( 13, 9, 2),
( 14, 9, 2),
( 15, 6, 2);
SELECT * from enrollment;

-- 
-- SELECT last_name, first_name, course_code, role , section, term, year
-- FROM enrollment e
-- INNER JOIN person p ON e.person_id=p.person_id
-- INNER JOIN role r ON e.role_id=r.role_id
-- INNER JOIN class c ON c.class_id=e.class_id
-- INNER JOIN course co ON c.course_id=co.course_id
-- INNER JOIN term t ON t.term_id=c.term_id
-- INNER JOIN degree d ON d.degree_id=co.degree_id
-- INNER JOIN department dt ON dt.department_id=d.department_id