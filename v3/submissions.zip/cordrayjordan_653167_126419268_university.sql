-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema university
-- -----------------------------------------------------
DROP SCHEMA IF EXISTS `university` ;

-- -----------------------------------------------------
-- Schema university
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `university` DEFAULT CHARACTER SET utf8 ;
USE `university` ;

-- -----------------------------------------------------
-- Table `university`.`department`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`department` ;

CREATE TABLE IF NOT EXISTS `university`.`department` (
  `department_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `department_name` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`department_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`degree`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`degree` ;

CREATE TABLE IF NOT EXISTS `university`.`degree` (
  `degree_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `degree_name` VARCHAR(45) NOT NULL,
  `course_code` VARCHAR(45) NOT NULL,
  `department_id` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`degree_id`),
  INDEX `fk_degree_department1_idx` (`department_id` ASC) VISIBLE,
  CONSTRAINT `fk_degree_department1`
    FOREIGN KEY (`department_id`)
    REFERENCES `university`.`department` (`department_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`course`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`course` ;

CREATE TABLE IF NOT EXISTS `university`.`course` (
  `course_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `course_num` INT NOT NULL,
  `course_title` VARCHAR(45) NOT NULL,
  `credits` INT NOT NULL,
  `degree_id` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`course_id`),
  INDEX `fk_course_degree1_idx` (`degree_id` ASC) VISIBLE,
  CONSTRAINT `fk_course_degree1`
    FOREIGN KEY (`degree_id`)
    REFERENCES `university`.`degree` (`degree_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`semester`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`semester` ;

CREATE TABLE IF NOT EXISTS `university`.`semester` (
  `semester_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `year` YEAR NOT NULL,
  `term` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`semester_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`section`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`section` ;

CREATE TABLE IF NOT EXISTS `university`.`section` (
  `section_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `section_num` INT NOT NULL,
  `capacity` INT NOT NULL,
  `course_id` INT UNSIGNED NOT NULL,
  `semester_id` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`section_id`),
  INDEX `fk_section_course_idx` (`course_id` ASC) VISIBLE,
  INDEX `fk_section_semester1_idx` (`semester_id` ASC) VISIBLE,
  CONSTRAINT `fk_section_course`
    FOREIGN KEY (`course_id`)
    REFERENCES `university`.`course` (`course_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_section_semester1`
    FOREIGN KEY (`semester_id`)
    REFERENCES `university`.`semester` (`semester_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`person`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`person` ;

CREATE TABLE IF NOT EXISTS `university`.`person` (
  `person_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `first_name` VARCHAR(45) NOT NULL,
  `last_name` VARCHAR(45) NOT NULL,
  `gender` ENUM('M', 'F') NOT NULL,
  `city` VARCHAR(45) NULL,
  `state` VARCHAR(45) NULL,
  `birthdate` DATE NULL,
  PRIMARY KEY (`person_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`person_role`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`person_role` ;

CREATE TABLE IF NOT EXISTS `university`.`person_role` (
  `person_role_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `role` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`person_role_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`enrollment`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`enrollment` ;

CREATE TABLE IF NOT EXISTS `university`.`enrollment` (
  `section_id` INT UNSIGNED NOT NULL,
  `person_id` INT UNSIGNED NOT NULL,
  `person_role_id` INT UNSIGNED NOT NULL,
  INDEX `fk_person_section_section1_idx` (`section_id` ASC) VISIBLE,
  PRIMARY KEY (`section_id`, `person_id`),
  INDEX `fk_enrollment_person_role1_idx` (`person_role_id` ASC) VISIBLE,
  INDEX `fk_enrollment_person1_idx` (`person_id` ASC) VISIBLE,
  CONSTRAINT `fk_person_section_section1`
    FOREIGN KEY (`section_id`)
    REFERENCES `university`.`section` (`section_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_enrollment_person_role1`
    FOREIGN KEY (`person_role_id`)
    REFERENCES `university`.`person_role` (`person_role_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_enrollment_person1`
    FOREIGN KEY (`person_id`)
    REFERENCES `university`.`person` (`person_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;


USE university;

INSERT INTO person (first_name, last_name, gender, city, state, birthdate) VALUES
('Marshall', 'Spence', 'M', 'Garland', 'TX', '2000-06-23'),
('Maria', 'Clark', 'F', 'Akron', 'OH', '2002-01-25'),
('Tracy', 'Woodward', 'F', 'Newark', 'NJ', '2002-10-04'),
('Erick', 'Woodward', 'M', 'Newark', 'NJ', '1998-08-05'),
('Lillie', 'Summers', 'F', 'Reno', 'NV', '1999-11-05'),
('Nellie', 'Marquez', 'F', 'Atlanta', 'GA', '2001-06-25'),
('Allen', 'Stokes', 'M', 'Bozeman', 'MT', '2004-09-16'),
('Josh', 'Rollins', 'M', 'Decatur', 'TN', '1998-11-28'),
('Isabel', 'Meyers', 'F', 'Rexburg', 'ID', '2003-05-15'),
('Kerri', 'Shah', 'F', 'Mesa', 'AZ', '2003-04-05'),
('Brady', 'Meyer', 'M', NULL, NULL, NULL),
('Andy', 'Kipner', 'M', NULL, NULL, NULL),
('Lucy', 'Fuller', 'F', NULL, NULL, NULL),
('Adam', 'Woods', 'M', NULL, NULL, NULL),
('Bryan', 'Drew', 'M', NULL, NULL, NULL);

INSERT INTO person_role (role) VALUES
('Student'),
('Teacher'),
('TA');

INSERT INTO semester (year, term) VALUES
('2024','Fall'),
('2025','Winter');

INSERT INTO department (department_name) VALUES
('Computer Science and Engineering'),
('Mathematics'),
('Music');

INSERT INTO degree (degree_name, course_code, department_id) VALUES
('Computer Science', 'CSE', 1),
('Web Design and Development', 'WDD', 1),
('Data Science', 'MATH', 2),
('Organ Performance', 'MUSIC', 3);

INSERT INTO course (course_num, course_title, credits, degree_id) VALUES
( 251, 'Parallelism and Concurrency', 3, 1),
( 231, 'Web Frontend Development I', 2, 2),
( 113, 'Calculus II ', 3, 3),
( 213, 'Musicianship 4', 3, 4);

INSERT INTO SECTION (section_num, capacity, course_id, semester_id) VALUES
( 1, 35, 1, 1),
( 1, 30, 2, 1),
( 2, 30, 2, 1),
( 1, 45, 3, 1),
( 1, 25, 4, 1),
( 2, 35, 1, 2),
( 3, 35, 1, 2),
( 1, 30, 2, 2),
( 2, 40, 2, 2),
( 1, 25, 4, 2);

INSERT INTO enrollment (person_id, section_id, person_role_id) VALUES
(11, 1, 2),
(11, 6, 2),
( 12, 2, 2),
( 12, 3, 2),
( 12, 8, 2),
( 12, 9, 2),
( 13, 4, 2),
( 14, 5, 2),
( 14, 10, 2),
( 15, 7, 2),
( 1, 1, 1),
( 1, 3, 1),
( 2, 4, 1),
( 3, 4, 1),
( 4, 5, 1),
( 5, 4, 1),
( 5, 5, 3),
( 6, 7, 1),
( 7, 6, 1),
( 7, 8, 3),
( 7, 10, 1),
( 8, 9, 1),
( 9, 9, 1),
( 10, 6, 1);


