-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema university
-- -----------------------------------------------------
DROP SCHEMA IF EXISTS `university` ;

-- -----------------------------------------------------
-- Schema university
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `university` DEFAULT CHARACTER SET utf8 ;
USE `university` ;

-- -----------------------------------------------------
-- Table `university`.`department`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`department` ;

CREATE TABLE IF NOT EXISTS `university`.`department` (
  `department_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `department_name` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`department_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`degree`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`degree` ;

CREATE TABLE IF NOT EXISTS `university`.`degree` (
  `degree_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `degree_name` VARCHAR(45) NOT NULL,
  `department_id` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`degree_id`),
  INDEX `fk_degree_department1_idx` (`department_id` ASC) VISIBLE,
  CONSTRAINT `fk_degree_department1`
    FOREIGN KEY (`department_id`)
    REFERENCES `university`.`department` (`department_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`course`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`course` ;

CREATE TABLE IF NOT EXISTS `university`.`course` (
  `course_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `course_code` VARCHAR(7) NOT NULL,
  `course_num` INT(7) NOT NULL,
  `course_title` VARCHAR(35) NOT NULL,
  `credits` VARCHAR(7) NOT NULL,
  `degree_id` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`course_id`),
  INDEX `fk_course_degree1_idx` (`degree_id` ASC) VISIBLE,
  CONSTRAINT `fk_course_degree1`
    FOREIGN KEY (`degree_id`)
    REFERENCES `university`.`degree` (`degree_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`person`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`person` ;

CREATE TABLE IF NOT EXISTS `university`.`person` (
  `person_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `first_name` VARCHAR(45) NOT NULL,
  `last_name` VARCHAR(45) NOT NULL,
  `gender` VARCHAR(45) NULL,
  `city` VARCHAR(45) NULL,
  `state` VARCHAR(45) NULL,
  `birthdate` VARCHAR(45) NULL,
  PRIMARY KEY (`person_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`semester`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`semester` ;

CREATE TABLE IF NOT EXISTS `university`.`semester` (
  `semester_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `term_name` VARCHAR(45) NOT NULL,
  `year_name` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`semester_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`section`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`section` ;

CREATE TABLE IF NOT EXISTS `university`.`section` (
  `section_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `section` VARCHAR(10) NOT NULL,
  `capacity` VARCHAR(45) NOT NULL,
  `semester_id` INT UNSIGNED NOT NULL,
  `course_id` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`section_id`),
  INDEX `fk_section_semester1_idx` (`semester_id` ASC) VISIBLE,
  INDEX `fk_section_course1_idx` (`course_id` ASC) VISIBLE,
  CONSTRAINT `fk_section_semester1`
    FOREIGN KEY (`semester_id`)
    REFERENCES `university`.`semester` (`semester_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_section_course1`
    FOREIGN KEY (`course_id`)
    REFERENCES `university`.`course` (`course_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`role`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`role` ;

CREATE TABLE IF NOT EXISTS `university`.`role` (
  `role_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `role_type` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`role_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`enrollment`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`enrollment` ;

CREATE TABLE IF NOT EXISTS `university`.`enrollment` (
  `enrollment_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `person_id` INT UNSIGNED NOT NULL,
  `section_id` INT UNSIGNED NOT NULL,
  `role_id` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`enrollment_id`),
  INDEX `fk_enrollment_person1_idx` (`person_id` ASC) VISIBLE,
  INDEX `fk_enrollment_section1_idx` (`section_id` ASC) VISIBLE,
  INDEX `fk_enrollment_role1_idx` (`role_id` ASC) VISIBLE,
  CONSTRAINT `fk_enrollment_person1`
    FOREIGN KEY (`person_id`)
    REFERENCES `university`.`person` (`person_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_enrollment_section1`
    FOREIGN KEY (`section_id`)
    REFERENCES `university`.`section` (`section_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_enrollment_role1`
    FOREIGN KEY (`role_id`)
    REFERENCES `university`.`role` (`role_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;

USE university;

-- department
INSERT INTO department
(department_name)
VALUES
('Computer Science and Engineering'),
('Mathematics'),
('Music');


INSERT INTO degree
(degree_name, department_id)
VALUES
('Computer Science', 1),
('Web Design and Development', 1),
('Data Science', 2),
('Organ Performance', 3);


INSERT INTO course
(course_code, course_num, course_title, credits, degree_id)
VALUES 
('CSE', '251', 'Parallelism and Concurrency', 3, 1),
('WDD', '231', 'Web Frontend Development 1', 2, 2),
('MATH', '113', 'Calculus 11', 3, 3),
('MUSIC', '213', 'Musicianship 4', 3, 4);


INSERT INTO semester (term_name, year_name)
VALUES
('Fall', 2024),
('Winter', 2025);


INSERT INTO section
(section, capacity, semester_id, course_id)
VALUES
(1, 35, 1, 1), -- CSE 251 Brady Meyer Teacher section 1  (1
(1, 30, 1, 2), -- WDD231 Andy Kipner Teacher (2
(2, 30, 1, 2), -- WDD 231 Andy Kipner (3
(1, 45, 1, 3), -- MATH 113 Lucy Fuller (4
(1, 25, 1, 4), -- MUSIC 213 Adam Woods (5
(2, 35, 2, 1), -- CSE 251 Brady Meyer 6
(3, 35, 2, 1), -- CSE 251 Bryan Drew  7
(1, 30, 2, 2), -- WDD 231 Andy Kipner 8
(2, 30, 2, 2), -- WDD 231 Andy Kipner 9
(1, 25, 2, 4); -- MUSIC 213 Adam Woods 10


INSERT INTO person
(first_name, last_name, gender, city, state, birthdate)
VALUES
('Marshall', 'Spence', 'M', 'Garland', 'TX', '2000-06-23'), -- 1
('Maria', 'Clark', 'F', 'Arkon', 'OH', '2002-01-25'), -- 2
('Tracy', 'Woodward', 'F', 'Newark', 'NJ', '2002-10-04'), -- 3
('Erick', 'Woodward', 'M', 'Newark', 'NJ', '1998-08-05'), -- 4
('Lillie', 'Summers', 'F', 'Reno', 'NV', '1999-11-05'), -- 5
('Nellie', 'Marquez', 'F', 'Atlanta', 'GA', '2001-06-25'), -- 6
('Allen', 'Stokes', 'M', 'Bozeman', 'MT', '2004-09-16'), -- 7
('Josh', 'Rollins', 'M', 'Decatur', 'TN', '1998-11-28'), -- 8
('Isabel', 'Meyers', 'F', 'Rexburg', 'ID', '2003-05-15'), -- 9
('Kerri', 'Shah', 'F', 'Mesa', 'AZ', '2003-04-05'),-- 10
('Brady', 'Meyer', NULL, NULL, NULL, NULL), -- 11
('Andy', 'Kipner', NULL, NULL, NULL, NULL), -- 12
('Lucy', 'Fuller', NULL, NULL, NULL, NULL),-- 13
('Adam', 'Woods', NULL, NULL, NULL, NULL), -- 14
('Bryan', 'Drew', NULL, NULL, NULL, NULL); -- 15


INSERT INTO role
(role_type)
VALUES
('Teacher'), -- 1
('Student'), -- 2
('TA'); -- 3


INSERT INTO enrollment
(person_id, section_id, role_id)
VALUES 
(15, 1, 1), -- Brady CSE 251
(15, 2, 1), -- Brady
(12, 3, 1), -- Andy 
(12, 4, 1), -- Andy
(12, 8, 1), -- Andy 2025 (1)
(12, 9, 1), -- Andy 2025 (2)
(13, 4, 1), -- Lucy 
(14, 5, 1), -- Adam WI SEC 1
(14, 10, 1), -- ADARM WI SEC 2
(15, 7, 1), -- Bryan 
(1, 1, 2), -- Marshall CSE 251 STU
(1, 3, 2), -- Marshall
(2, 4, 2), -- MARIA
(3, 4, 2), -- TRACY
(4, 5, 2),-- ERICK (4) done
(5,	4, 2),-- Lillie
(5, 5, 3),-- Lillie (5)
(6, 7, 2),-- Nellie
(7,	6, 2),-- Allen
(7, 8, 3),-- Allen
(7, 10, 2),-- Allen
(8, 9, 2), -- Josh
(9, 9, 2), -- Isabel
(10, 6, 2); -- Kerri


