-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema university
-- -----------------------------------------------------
DROP SCHEMA IF EXISTS `university` ;

-- -----------------------------------------------------
-- Schema university
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `university` DEFAULT CHARACTER SET utf8 ;
USE `university` ;

-- -----------------------------------------------------
-- Table `university`.`person`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`person` ;

CREATE TABLE IF NOT EXISTS `university`.`person` (
  `person_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `first_name` VARCHAR(30) NOT NULL,
  `last_name` VARCHAR(30) NOT NULL,
  `gender` VARCHAR(1) NULL,
  `birthdate` DATE NULL,
  `state` VARCHAR(2) NULL,
  `city` VARCHAR(45) NULL,
  PRIMARY KEY (`person_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`department`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`department` ;

CREATE TABLE IF NOT EXISTS `university`.`department` (
  `department_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `dept_name` VARCHAR(50) NOT NULL,
  PRIMARY KEY (`department_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`degree`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`degree` ;

CREATE TABLE IF NOT EXISTS `university`.`degree` (
  `degree_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `degree_name` VARCHAR(45) NOT NULL,
  `department_id` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`degree_id`),
  INDEX `fk_degree_department1_idx` (`department_id` ASC) VISIBLE,
  CONSTRAINT `fk_degree_department1`
    FOREIGN KEY (`department_id`)
    REFERENCES `university`.`department` (`department_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`course`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`course` ;

CREATE TABLE IF NOT EXISTS `university`.`course` (
  `course_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `course_num` INT UNSIGNED NOT NULL,
  `course_name` VARCHAR(45) NOT NULL,
  `course_credit` TINYINT UNSIGNED NOT NULL,
  `course_code` VARCHAR(10) NOT NULL,
  `degree_id` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`course_id`),
  INDEX `fk_course_degree1_idx` (`degree_id` ASC) VISIBLE,
  CONSTRAINT `fk_course_degree1`
    FOREIGN KEY (`degree_id`)
    REFERENCES `university`.`degree` (`degree_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`term`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`term` ;

CREATE TABLE IF NOT EXISTS `university`.`term` (
  `term_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `term_name` VARCHAR(20) NOT NULL,
  `term_year` SMALLINT UNSIGNED NOT NULL,
  PRIMARY KEY (`term_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`section`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`section` ;

CREATE TABLE IF NOT EXISTS `university`.`section` (
  `section_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `section_num` INT UNSIGNED NOT NULL,
  `capacity` SMALLINT UNSIGNED NOT NULL,
  `term_id` INT UNSIGNED NOT NULL,
  `course_id` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`section_id`),
  INDEX `fk_section_term1_idx` (`term_id` ASC) VISIBLE,
  INDEX `fk_section_course1_idx` (`course_id` ASC) VISIBLE,
  CONSTRAINT `fk_section_term1`
    FOREIGN KEY (`term_id`)
    REFERENCES `university`.`term` (`term_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_section_course1`
    FOREIGN KEY (`course_id`)
    REFERENCES `university`.`course` (`course_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`role`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`role` ;

CREATE TABLE IF NOT EXISTS `university`.`role` (
  `role_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `person_type` VARCHAR(30) NOT NULL,
  PRIMARY KEY (`role_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`enrollment`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`enrollment` ;

CREATE TABLE IF NOT EXISTS `university`.`enrollment` (
  `enrollment_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `person_id` INT UNSIGNED NOT NULL,
  `section_id` INT UNSIGNED NOT NULL,
  `role_id` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`enrollment_id`),
  INDEX `fk_enrollment_person1_idx` (`person_id` ASC) VISIBLE,
  INDEX `fk_enrollment_section1_idx` (`section_id` ASC) VISIBLE,
  INDEX `fk_enrollment_role1_idx` (`role_id` ASC) VISIBLE,
  CONSTRAINT `fk_enrollment_person1`
    FOREIGN KEY (`person_id`)
    REFERENCES `university`.`person` (`person_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_enrollment_section1`
    FOREIGN KEY (`section_id`)
    REFERENCES `university`.`section` (`section_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_enrollment_role1`
    FOREIGN KEY (`role_id`)
    REFERENCES `university`.`role` (`role_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
-- -------------------------------------------------------------------------------------------------------------------------------------

USE university;
-- -----------------
INSERT INTO department
(dept_name)
VALUES
('Computer Science and Engineering'),
('Mathematics'),
('Music');
-- -----------------

INSERT INTO degree
(degree_name, department_id)
VALUES
('Computer Science',(SELECT department_id FROM department WHERE dept_name = 'Computer Science and Engineering')),
('Web Design and Development',(SELECT department_id FROM department WHERE dept_name = 'Computer Science and Engineering')),
('Data Science',(SELECT department_id FROM department WHERE dept_name = 'Mathematics')),
('Organ Performance',(SELECT department_id FROM department WHERE dept_name = 'Music'));
-- -----------------

INSERT INTO term 
(term_name, term_year)
VALUES 
('Fall', 2024),
('Winter', 2025);
-- -----------------

INSERT INTO role 
(person_type)
VALUES
('Teacher'),
('Student'),
('TA');
-- -----------------

INSERT INTO course
(course_num, course_name, course_credit, course_code, degree_id)
VALUES
( 251, 'Parallelism and Concurrency', 3,'CSE', (SELECT degree_id FROM degree WHERE degree_name ='Computer Science')), 
( 231, 'Web Frontend Development I', 2,'WDD', (SELECT degree_id FROM degree WHERE degree_name ='Web Design and Development')), 
( 113, 'Calculus II', 3,'MATH', (SELECT degree_id FROM degree WHERE degree_name ='Data Science')), 
( 213, 'Musicianship 4', 3,'MUSIC', (SELECT degree_id FROM degree WHERE degree_name ='Organ Performance'));
-- -----------------

INSERT INTO section
(term_id, course_id, section_num, capacity)
VALUES
((SELECT term_id FROM term WHERE CONCAT(term_name, ' ', term_year) = 'Fall 2024'), (SELECT course_id FROM course WHERE CONCAT(course_code, ' ', course_num) ='CSE 251'), 1, 35),
((SELECT term_id FROM term WHERE CONCAT(term_name, ' ', term_year) = 'Fall 2024'), (SELECT course_id FROM course WHERE CONCAT(course_code, ' ', course_num) ='WDD 231'), 1, 30),
((SELECT term_id FROM term WHERE CONCAT(term_name, ' ', term_year) = 'Fall 2024'), (SELECT course_id FROM course WHERE CONCAT(course_code, ' ', course_num) ='WDD 231'), 2, 30),
((SELECT term_id FROM term WHERE CONCAT(term_name, ' ', term_year) = 'Fall 2024'), (SELECT course_id FROM course WHERE CONCAT(course_code, ' ', course_num) ='MATH 113'), 1, 45),
((SELECT term_id FROM term WHERE CONCAT(term_name, ' ', term_year) = 'Fall 2024'), (SELECT course_id FROM course WHERE CONCAT(course_code, ' ', course_num) ='MUSIC 213'), 1, 25),
((SELECT term_id FROM term WHERE CONCAT(term_name, ' ', term_year) = 'Winter 2025'), (SELECT course_id FROM course WHERE CONCAT(course_code, ' ', course_num) ='CSE 251'), 2, 35),
((SELECT term_id FROM term WHERE CONCAT(term_name, ' ', term_year) = 'Winter 2025'), (SELECT course_id FROM course WHERE CONCAT(course_code, ' ', course_num) ='CSE 251'), 3, 35),
((SELECT term_id FROM term WHERE CONCAT(term_name, ' ', term_year) = 'Winter 2025'), (SELECT course_id FROM course WHERE CONCAT(course_code, ' ', course_num) ='WDD 231'), 1, 30),
((SELECT term_id FROM term WHERE CONCAT(term_name, ' ', term_year) = 'Winter 2025'), (SELECT course_id FROM course WHERE CONCAT(course_code, ' ', course_num) ='WDD 231'), 2, 40),
((SELECT term_id FROM term WHERE CONCAT(term_name, ' ', term_year) = 'Winter 2025'), (SELECT course_id FROM course WHERE CONCAT(course_code, ' ', course_num) ='MUSIC 213'), 1, 25);
-- -----------------

INSERT INTO person
(first_name, last_name, gender, city, state, birthdate) 
VALUES
('Brady','Meyer',NULL ,NULL ,NULL , NULL),
('Andy','Kipner',NULL ,NULL ,NULL , NULL),
('Lucy','Fuller',NULL ,NULL ,NULL , NULL),
('Adam','Woods',NULL ,NULL ,NULL , NULL),
('Bryan','Drew',NULL ,NULL ,NULL , NULL),
('Marshall','Spence','M','Garland','TX', '2000-06-23'),
('Maria','Clark','F','Akron','OH', '2002-01-25'),
('Tracy', 'Woodward', 'F', 'Newark', 'NJ', '2002-10-04'),
('Erick', 'Woodward', 'M', 'Newark', 'NJ', '1998-08-05'),
('Lillie', 'Summers', 'F', 'Reno', 'NV', '1999-11-05'),
('Nellie', 'Marquez', 'F', 'Atlanta', 'GA', '2001-06-25'),
('Allen', 'Stokes', 'M', 'Bozeman', 'MT', '2004-09-16'),
('Josh', 'Rollins', 'M', 'Decatur', 'TN', '1998-11-28'),
('Isabel', 'Meyers', 'F', 'Rexburg', 'ID', '2003-05-15'),
('Kerri', 'Shah', 'F', 'Mesa', 'AZ', '2003-04-05');
-- -----------------

INSERT INTO enrollment
(person_id, section_id, role_id)
VALUES
-- 1
((SELECT person_id FROM person
  WHERE first_name = 'Brady'),
(SELECT section_id FROM section s
   INNER JOIN term t ON s.term_id = t.term_id
   INNER JOIN course c ON s.course_id = c.course_id
   WHERE CONCAT(term_name, ' ', term_year) = 'Fall 2024'
   AND   CONCAT(course_code, ' ', course_num) = 'CSE 251'
   AND   section_num = 1),
(SELECT role_id FROM role WHERE person_type = 'Teacher')),
-- 2
((SELECT person_id FROM person
  WHERE first_name = 'Brady'),
(SELECT section_id FROM section s
   INNER JOIN term t ON s.term_id = t.term_id
   INNER JOIN course c ON s.course_id = c.course_id
   WHERE CONCAT(term_name, ' ', term_year) = 'Winter 2025'
   AND   CONCAT(course_code, ' ', course_num) = 'CSE 251'
   AND   section_num = 2),
(SELECT role_id FROM role WHERE person_type = 'Teacher')),
-- 3
((SELECT person_id FROM person
  WHERE first_name = 'Andy'),
(SELECT section_id FROM section s
   INNER JOIN term t ON s.term_id = t.term_id
   INNER JOIN course c ON s.course_id = c.course_id
   WHERE CONCAT(term_name, ' ', term_year) = 'Fall 2024'
   AND   CONCAT(course_code, ' ', course_num) = 'WDD 231'
   AND   section_num = 1),
(SELECT role_id FROM role WHERE person_type = 'Teacher')),
-- 4
((SELECT person_id FROM person
  WHERE first_name = 'Andy'),
(SELECT section_id FROM section s
   INNER JOIN term t ON s.term_id = t.term_id
   INNER JOIN course c ON s.course_id = c.course_id
   WHERE CONCAT(term_name, ' ', term_year) = 'Fall 2024'
   AND   CONCAT(course_code, ' ', course_num) = 'WDD 231'
   AND   section_num = 2),
(SELECT role_id FROM role WHERE person_type = 'Teacher')),
-- 5
((SELECT person_id FROM person
  WHERE first_name = 'Andy'),
(SELECT section_id FROM section s
   INNER JOIN term t ON s.term_id = t.term_id
   INNER JOIN course c ON s.course_id = c.course_id
   WHERE CONCAT(term_name, ' ', term_year) = 'Winter 2025'
   AND   CONCAT(course_code, ' ', course_num) = 'WDD 231'
   AND   section_num = 1),
(SELECT role_id FROM role WHERE person_type = 'Teacher')),
-- 6
((SELECT person_id FROM person
  WHERE first_name = 'Andy'),
(SELECT section_id FROM section s
   INNER JOIN term t ON s.term_id = t.term_id
   INNER JOIN course c ON s.course_id = c.course_id
   WHERE CONCAT(term_name, ' ', term_year) = 'Winter 2025'
   AND   CONCAT(course_code, ' ', course_num) = 'WDD 231'
   AND   section_num = 2),
(SELECT role_id FROM role WHERE person_type = 'Teacher')),
-- 7
((SELECT person_id FROM person
  WHERE first_name = 'Lucy'),
(SELECT section_id FROM section s
   INNER JOIN term t ON s.term_id = t.term_id
   INNER JOIN course c ON s.course_id = c.course_id
   WHERE CONCAT(term_name, ' ', term_year) = 'Fall 2024'
   AND   CONCAT(course_code, ' ', course_num) = 'MATH 113'
   AND   section_num = 1),
(SELECT role_id FROM role WHERE person_type = 'Teacher')),
-- 8
((SELECT person_id FROM person
  WHERE first_name = 'Adam'),
(SELECT section_id FROM section s
   INNER JOIN term t ON s.term_id = t.term_id
   INNER JOIN course c ON s.course_id = c.course_id
   WHERE CONCAT(term_name, ' ', term_year) = 'Fall 2024'
   AND   CONCAT(course_code, ' ', course_num) = 'MUSIC 213'
   AND   section_num = 1),
(SELECT role_id FROM role WHERE person_type = 'Teacher')),
-- 9
((SELECT person_id FROM person
  WHERE first_name = 'Adam'),
(SELECT section_id FROM section s
   INNER JOIN term t ON s.term_id = t.term_id
   INNER JOIN course c ON s.course_id = c.course_id
   WHERE CONCAT(term_name, ' ', term_year) = 'Winter 2025'
   AND   CONCAT(course_code, ' ', course_num) = 'MUSIC 213'
   AND   section_num = 1),
(SELECT role_id FROM role WHERE person_type = 'Teacher')),
-- 10 
((SELECT person_id FROM person
  WHERE first_name = 'Bryan'),
(SELECT section_id FROM section s
   INNER JOIN term t ON s.term_id = t.term_id
   INNER JOIN course c ON s.course_id = c.course_id
   WHERE CONCAT(term_name, ' ', term_year) = 'Winter 2025'
   AND   CONCAT(course_code, ' ', course_num) = 'CSE 251'
   AND   section_num = 3),
(SELECT role_id FROM role WHERE person_type = 'Teacher')),
-- Students/ TA's
-- 11
((SELECT person_id FROM person
  WHERE first_name = 'Marshall'),
(SELECT section_id FROM section s
   INNER JOIN term t ON s.term_id = t.term_id
   INNER JOIN course c ON s.course_id = c.course_id
   WHERE CONCAT(term_name, ' ', term_year) = 'Fall 2024'
   AND   CONCAT(course_code, ' ', course_num) = 'CSE 251'
   AND   section_num = 1),
(SELECT role_id FROM role WHERE person_type = 'Student')),
-- 12
((SELECT person_id FROM person
  WHERE first_name = 'Marshall'),
(SELECT section_id FROM section s
   INNER JOIN term t ON s.term_id = t.term_id
   INNER JOIN course c ON s.course_id = c.course_id
   WHERE CONCAT(term_name, ' ', term_year) = 'Fall 2024'
   AND   CONCAT(course_code, ' ', course_num) = 'WDD 231'
   AND   section_num = 2),
(SELECT role_id FROM role WHERE person_type = 'Student')),
-- 13
((SELECT person_id FROM person
  WHERE first_name = 'Maria'),
(SELECT section_id FROM section s
   INNER JOIN term t ON s.term_id = t.term_id
   INNER JOIN course c ON s.course_id = c.course_id
   WHERE CONCAT(term_name, ' ', term_year) = 'Fall 2024'
   AND   CONCAT(course_code, ' ', course_num) = 'MATH 113'
   AND   section_num = 1),
(SELECT role_id FROM role WHERE person_type = 'Student')),
-- 14
((SELECT person_id FROM person
  WHERE first_name = 'Tracy'),
(SELECT section_id FROM section s
   INNER JOIN term t ON s.term_id = t.term_id
   INNER JOIN course c ON s.course_id = c.course_id
   WHERE CONCAT(term_name, ' ', term_year) = 'Fall 2024'
   AND   CONCAT(course_code, ' ', course_num) = 'MATH 113'
   AND   section_num = 1),
(SELECT role_id FROM role WHERE person_type = 'Student')),
-- 15
((SELECT person_id FROM person
  WHERE first_name = 'Erick'),
(SELECT section_id FROM section s
   INNER JOIN term t ON s.term_id = t.term_id
   INNER JOIN course c ON s.course_id = c.course_id
   WHERE CONCAT(term_name, ' ', term_year) = 'Fall 2024'
   AND   CONCAT(course_code, ' ', course_num) = 'MUSIC 213'
   AND   section_num = 1),
(SELECT role_id FROM role WHERE person_type = 'Student')),
-- 16
((SELECT person_id FROM person
  WHERE first_name = 'Lillie'),
(SELECT section_id FROM section s
   INNER JOIN term t ON s.term_id = t.term_id
   INNER JOIN course c ON s.course_id = c.course_id
   WHERE CONCAT(term_name, ' ', term_year) = 'Fall 2024'
   AND   CONCAT(course_code, ' ', course_num) = 'MATH 113'
   AND   section_num = 1),
(SELECT role_id FROM role WHERE person_type = 'Student')),
-- 17
((SELECT person_id FROM person
  WHERE first_name = 'Lillie'),
(SELECT section_id FROM section s
   INNER JOIN term t ON s.term_id = t.term_id
   INNER JOIN course c ON s.course_id = c.course_id
   WHERE CONCAT(term_name, ' ', term_year) = 'Fall 2024'
   AND   CONCAT(course_code, ' ', course_num) = 'MUSIC 213'
   AND   section_num = 1),
(SELECT role_id FROM role WHERE person_type = 'TA')),
-- 18
((SELECT person_id FROM person
  WHERE first_name = 'Nellie'),
(SELECT section_id FROM section s
   INNER JOIN term t ON s.term_id = t.term_id
   INNER JOIN course c ON s.course_id = c.course_id
   WHERE CONCAT(term_name, ' ', term_year) = 'Winter 2025'
   AND   CONCAT(course_code, ' ', course_num) = 'CSE 251'
   AND   section_num = 3),
(SELECT role_id FROM role WHERE person_type = 'Student')),
-- 19
((SELECT person_id FROM person
  WHERE first_name = 'Allen'),
(SELECT section_id FROM section s
   INNER JOIN term t ON s.term_id = t.term_id
   INNER JOIN course c ON s.course_id = c.course_id
   WHERE CONCAT(term_name, ' ', term_year) = 'Winter 2025'
   AND   CONCAT(course_code, ' ', course_num) = 'CSE 251'
   AND   section_num = 2),
(SELECT role_id FROM role WHERE person_type = 'Student')),
-- 20
((SELECT person_id FROM person
  WHERE first_name = 'Allen'),
(SELECT section_id FROM section s
   INNER JOIN term t ON s.term_id = t.term_id
   INNER JOIN course c ON s.course_id = c.course_id
   WHERE CONCAT(term_name, ' ', term_year) = 'Winter 2025'
   AND   CONCAT(course_code, ' ', course_num) = 'WDD 231'
   AND   section_num = 1),
(SELECT role_id FROM role WHERE person_type = 'TA')),
-- 21
((SELECT person_id FROM person
  WHERE first_name = 'Allen'),
(SELECT section_id FROM section s
   INNER JOIN term t ON s.term_id = t.term_id
   INNER JOIN course c ON s.course_id = c.course_id
   WHERE CONCAT(term_name, ' ', term_year) = 'Winter 2025'
   AND   CONCAT(course_code, ' ', course_num) = 'MUSIC 213'
   AND   section_num = 1),
(SELECT role_id FROM role WHERE person_type = 'Student')),
-- 22
((SELECT person_id FROM person
  WHERE first_name = 'Josh'),
(SELECT section_id FROM section s
   INNER JOIN term t ON s.term_id = t.term_id
   INNER JOIN course c ON s.course_id = c.course_id
   WHERE CONCAT(term_name, ' ', term_year) = 'Winter 2025'
   AND   CONCAT(course_code, ' ', course_num) = 'WDD 231'
   AND   section_num = 2),
(SELECT role_id FROM role WHERE person_type = 'Student')),
-- 23
((SELECT person_id FROM person
  WHERE first_name = 'Isabel'),
(SELECT section_id FROM section s
   INNER JOIN term t ON s.term_id = t.term_id
   INNER JOIN course c ON s.course_id = c.course_id
   WHERE CONCAT(term_name, ' ', term_year) = 'Winter 2025'
   AND   CONCAT(course_code, ' ', course_num) = 'WDD 231'
   AND   section_num = 2),
(SELECT role_id FROM role WHERE person_type = 'Student')),
-- 24
((SELECT person_id FROM person
  WHERE first_name = 'Kerri'),
(SELECT section_id FROM section s
   INNER JOIN term t ON s.term_id = t.term_id
   INNER JOIN course c ON s.course_id = c.course_id
   WHERE CONCAT(term_name, ' ', term_year) = 'Winter 2025'
   AND   CONCAT(course_code, ' ', course_num) = 'CSE 251'
   AND   section_num = 2),
(SELECT role_id FROM role WHERE person_type = 'Student'));

-- ------------------------------------------------------------------------------------------------------------

SELECT first_name, last_name, person_type, CONCAT(course_code, ' ', course_num) AS course, section_num, term_name, term_year
FROM person p
	INNER JOIN enrollment ent ON p.person_id = ent.person_id
    INNER JOIN role r ON r.role_id = ent.role_id
    INNER JOIN section s ON s.section_id = ent.section_id
    INNER JOIN term t ON t.term_id = s.term_id
    INNER JOIN course c ON c.course_id = s.course_id
WHERE p.first_name = 'Allen' AND p.last_name = 'Stokes';

SELECT DISTINCT last_name, first_name, course_name, section_num, term_name, term_year
FROM person p
	INNER JOIN enrollment ent ON p.person_id = ent.person_id
    INNER JOIN role r ON r.role_id = ent.role_id
    INNER JOIN section s ON s.section_id = ent.section_id
    INNER JOIN term t ON t.term_id = s.term_id
    INNER JOIN course c ON c.course_id = s.course_id
WHERE CONCAT(c.course_code, ' ', c.course_num) = 'CSE 251' 
	AND r.role_id = 2;