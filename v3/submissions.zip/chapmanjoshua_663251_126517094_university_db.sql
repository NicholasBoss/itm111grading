-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema university
-- -----------------------------------------------------
DROP SCHEMA IF EXISTS `university` ;

-- -----------------------------------------------------
-- Schema university
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `university` DEFAULT CHARACTER SET utf8 ;
USE `university` ;

-- -----------------------------------------------------
-- Table `university`.`department`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`department` ;

CREATE TABLE IF NOT EXISTS `university`.`department` (
  `department_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `department_name` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`department_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`degree`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`degree` ;

CREATE TABLE IF NOT EXISTS `university`.`degree` (
  `degree_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `degree` VARCHAR(45) NOT NULL,
  `department_id` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`degree_id`),
  INDEX `fk_degree_department_idx` (`department_id` ASC) VISIBLE,
  CONSTRAINT `fk_degree_department`
    FOREIGN KEY (`department_id`)
    REFERENCES `university`.`department` (`department_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`course`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`course` ;

CREATE TABLE IF NOT EXISTS `university`.`course` (
  `course_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `course_title` VARCHAR(45) NOT NULL,
  `course_code` VARCHAR(5) NOT NULL,
  `course_num` INT UNSIGNED NOT NULL,
  `credit_count` INT UNSIGNED NOT NULL,
  `degree_id` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`course_id`),
  UNIQUE INDEX `course_code_UNIQUE` (`course_code` ASC) VISIBLE,
  UNIQUE INDEX `course_title_UNIQUE` (`course_title` ASC) VISIBLE,
  INDEX `fk_course_degree1_idx` (`degree_id` ASC) VISIBLE,
  CONSTRAINT `fk_course_degree1`
    FOREIGN KEY (`degree_id`)
    REFERENCES `university`.`degree` (`degree_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`term`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`term` ;

CREATE TABLE IF NOT EXISTS `university`.`term` (
  `term_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `term_name` VARCHAR(10) NOT NULL,
  `year` YEAR NOT NULL,
  PRIMARY KEY (`term_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`section`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`section` ;

CREATE TABLE IF NOT EXISTS `university`.`section` (
  `section_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `section` VARCHAR(45) NOT NULL,
  `capacity` INT UNSIGNED NOT NULL,
  `course_id` INT UNSIGNED NOT NULL,
  `term_id` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`section_id`),
  INDEX `fk_section_course1_idx` (`course_id` ASC) VISIBLE,
  INDEX `fk_section_term1_idx` (`term_id` ASC) VISIBLE,
  CONSTRAINT `fk_section_course1`
    FOREIGN KEY (`course_id`)
    REFERENCES `university`.`course` (`course_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_section_term1`
    FOREIGN KEY (`term_id`)
    REFERENCES `university`.`term` (`term_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`person`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`person` ;

CREATE TABLE IF NOT EXISTS `university`.`person` (
  `person_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `first_name` VARCHAR(45) NOT NULL,
  `last_name` VARCHAR(45) NOT NULL,
  `gender` ENUM('M', 'F') NULL,
  `city` VARCHAR(25) NULL,
  `state_code` VARCHAR(2) NULL,
  `birthday` DATE NULL,
  PRIMARY KEY (`person_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`role`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`role` ;

CREATE TABLE IF NOT EXISTS `university`.`role` (
  `role_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `role_name` VARCHAR(20) NOT NULL,
  PRIMARY KEY (`role_id`),
  UNIQUE INDEX `role_name_UNIQUE` (`role_name` ASC) VISIBLE)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `university`.`enrollment`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `university`.`enrollment` ;

CREATE TABLE IF NOT EXISTS `university`.`enrollment` (
  `enrollment_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `person_id` INT UNSIGNED NOT NULL,
  `role_id` INT UNSIGNED NOT NULL,
  `section_id` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`enrollment_id`),
  INDEX `fk_enrollment_person1_idx` (`person_id` ASC) VISIBLE,
  INDEX `fk_enrollment_role1_idx` (`role_id` ASC) VISIBLE,
  INDEX `fk_enrollment_section1_idx` (`section_id` ASC) VISIBLE,
  CONSTRAINT `fk_enrollment_person1`
    FOREIGN KEY (`person_id`)
    REFERENCES `university`.`person` (`person_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_enrollment_role1`
    FOREIGN KEY (`role_id`)
    REFERENCES `university`.`role` (`role_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_enrollment_section1`
    FOREIGN KEY (`section_id`)
    REFERENCES `university`.`section` (`section_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;




INSERT INTO university.person
(first_name, last_name, gender, city, state_code, birthday)
VALUES
('Marshall','Spence','M','Garland','TX','2000-06-23'),
('Maria','Clark','F','Akron','OH','2002-01-25'),
('Tracy','Woodward','F','Newark','NJ','2002-10-04'),
('Erick','Woodward','M','Newark','NJ','1998-08-05'),
('Lillie','Summers','F','Reno','NV','1999-11-05'),
('Nellie','Marquez','F','Atlanta','GA','2001-06-25'),
('Allen','Stokes','M','Bozeman','MT','2004-09-16'),
('Josh','Rollins','M','Decatur','TN','1998-11-28'),
('Isabel','Meyers','F','Rexburg','ID','2003-05-15'),
('Kerri','Shah','F','Mesa','AZ','2003-04-05'),
('Brady','Meyer',NULL,NULL,NULL,NULL),
('Andy','Kipner',NULL,NULL,NULL,NULL),
('Lucy','Fuller',NULL,NULL,NULL,NULL),
('Adam','Woods',NULL,NULL,NULL,NULL),
('Bryan','Drew',NULL,NULL,NULL,NULL)
;

INSERT INTO university.role
(role_name)
VALUES
('Teacher'),
('Student'),
('TA')
;

INSERT INTO university.term
(term_name, year)
VALUES
('Fall','2024'),
('Winter','2025');

INSERT INTO university.department
(department_name)
VALUES
('Computer Science and Engineering'),
('Mathematics'),
('Music')
;

INSERT INTO university.degree
(degree, department_id)
VALUES
('Computer Science','1'),
('Web Design and Development','1'),
('Data Science','2'),
('Organ Performance','3')
;

INSERT INTO university.course
(course_title,course_code,course_num,credit_count,degree_id)
VALUES
('Parallelism and Concurrency','CSE','251','3','1'),
('Web Frontend Development I','WDD','231','2','2'),
('Calculus II','MATH','113','3','3'),
('Musicianship 4','MUSIC','213','3','4')
;

INSERT INTO university.section
(section,capacity,course_id,term_id)
VALUES
('1','35','1','1'),
('1','30','2','1'),
('2','30','2','1'),
('1','45','3','1'),
('1','25','4','1'),
('2','35','1','2'),
('3','35','1','2'),
('1','30','2','2'),
('2','40','2','2'),
('1','25','4','2')
;

INSERT INTO university.enrollment
(person_id,role_id,section_id)
VALUES
('11','1','1'),
('11','1','6'),
('12','1','2'),
('12','1','3'),
('12','1','8'),
('12','1','9'),
('13','1','4'),
('14','1','5'),
('14','1','10'),
('15','1','7'),
('1','2','1'),
('1','2','3'),
('2','2','4'),
('3','2','4'),
('4','2','5'),
('5','2','4'),
('5','3','5'),
('6','2','7'),
('7','2','6'),
('7','3','8'),
('7','2','10'),
('8','2','9'),
('9','2','9'),
('10','2','6')
;



-- Examples from assignment

-- USE university;

-- 1.
-- SELECT CONCAT(first_name, ' ', last_name) AS 'Name', role_name, CONCAT(course_code, ' ', course_num) AS 'Course', section.section AS 'Section', CONCAT(term_name, ' ', year) AS 'Term'
-- FROM person
-- LEFT JOIN enrollment ON person.person_id = enrollment.person_id
-- LEFT JOIN role ON enrollment.role_id = role.role_id
-- LEFT JOIN section ON enrollment.section_id = section.section_id
-- LEFT JOIN term ON section.term_id = term.term_id
-- LEFT JOIN course ON section.course_id = course.course_id
-- WHERE first_name LIKE 'Allen' AND last_name LIKE 'Stokes'
-- ;


-- 3.
-- SELECT course_title, COUNT(course_title) AS 'Students Taking Musicianship 4'
-- FROM university.course
-- LEFT JOIN section ON course.course_id = section.course_id
-- LEFT JOIN enrollment ON section.section_id = enrollment.section_id
-- LEFT JOIN role ON enrollment.role_id = role.role_id
-- LEFT JOIN person ON enrollment.person_id = person.person_id
-- WHERE course_title LIKE 'Musicianship 4' AND role_name LIKE 'Student'
-- GROUP BY course_title
-- ;